import Vue from 'vue'
import vuex from 'vuex'

/* 引入各部分组件 */
import question from './modules/question'
import user from './modules/user'
import source from './modules/source'
import searchResult from '@/store/modules/searchResult'
import compose from '@/store/modules/compose'
/* End 引入各部分组件 */

Vue.use(vuex)


export default new vuex.Store({
    state: {
        authrozition: 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoyLCJ1c2VybmFtZSI6IjEzMzEyMzQxMjM0IiwiZXhwIjoxNTY0NDU0MDU2LCJlbWFpbCI6bnVsbCwicGhvbmVfbnVtYmVyIjoiMTMzMTIzNDEyMzQiLCJvcmlnX2lhdCI6MTUzMjkxODA1Nn0.w1qtjs29Upp02qoYjfnNCBdj_HFCah-4DPK5elZo0dk',
        qiniuToken: '',
    },
	modules: {
        question,
        user,
        searchResult,
        source,
        compose
    }
})
