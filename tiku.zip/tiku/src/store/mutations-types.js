
export const SET_SUBJECT = 'SET_SUBJECT'    // 设置学科
export const SET_LEVEL = 'SET_LEVEL'    // 设置年部
export const SET_MATERIALS = 'SET_MATERIALS'    // 设置教材版本
export const SET_QUESTIONS = 'SET_QUESTIONS'    // 设置所选题目
