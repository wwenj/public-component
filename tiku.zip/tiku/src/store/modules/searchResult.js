import request from '@/common/request'

const NAMESPACE = 'RESULT_'

export const GET_SEARCH_RESULT = `${NAMESPACE}get_search_result`


export const SET_SEARCH_RESULT = `${NAMESPACE}set_search_result`

export const SEARCH_RESULT_ACTIONS_FETCH_RESULT = `${NAMESPACE}fetch_search_result`
export const SEARCH_RESULT_ACTIONS_GET_SEARCH_RESULT_BY_INDEX = `${NAMESPACE}get_search_result_by_index`
export const SEARCH_RESULT_ACTIONS_SET_QUESTION = `${NAMESPACE}set_question`

import { SET_QUESTION, SET_QUESTION_IS_COPY } from '@/store/modules/question'
// import { USER_MUTATIONS_SET_USER, USER_GETTERS_GET_USER } from '@/store/modules/user';

export default {
    namespace: true,

    state: {
        result_list: []
    },

    getters: {
        [GET_SEARCH_RESULT] (state) {
            return state.result_list
        }
    },

    mutations: {
        [SET_SEARCH_RESULT] (state, data) {
            state.result_list = data
        }
    },

    actions:  {
        [SEARCH_RESULT_ACTIONS_FETCH_RESULT] (store, obj) {
            return request.searchQuestion(obj)
            .then( res => {
                console.log('search: ', res)
                if (res.data.code == 200) {
                    store.commit(SET_SEARCH_RESULT, res.data.data)
                }
            })
        },

        [SEARCH_RESULT_ACTIONS_GET_SEARCH_RESULT_BY_INDEX] (store, index) {
            return store.state.result_list[index]
        },

        [SEARCH_RESULT_ACTIONS_SET_QUESTION] (store, index) {
            let question = store.state.result_list[index]
            let data = {
                id: question.id,
                type: question.type,
                body: {
                    stem: question.body.stem,
                    answer: question.body.answer,
                    analysis: question.body.analysis
                }
            }
            store.commit(SET_QUESTION, data)
            store.commit(SET_QUESTION_IS_COPY, true)
        }
    }
}