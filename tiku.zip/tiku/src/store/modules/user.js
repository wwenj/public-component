const NAMESPACE = 'USER_'
// import {request} from '@/common/request'
export const USER_GETTERS_GET_USER = `${NAMESPACE}user_getters_get_user`;
export const USER_GETTERS_GET_TOKEN = `${NAMESPACE}user_getters_get_token`
export const USER_MUTATIONS_SET_USER = `${NAMESPACE}user_mutations_set_user`;
export const USER_MUTATIONS_SET_TOKEN = `${NAMESPACE}user_mutations_set_token`

// import login from './login'

export default {
    namespace: true,

    state: {
        user: {
            active: 1,
            created_at: '',
            mobile: '',
            uid: '',
            username: ''
        },

        auth_token: ''
    },
    getters: {
        [USER_GETTERS_GET_USER](state) {
            return state.user;
        },

        [USER_GETTERS_GET_TOKEN](state) {
            return state.auth_token;
        }
    },

    mutations: {
        [USER_MUTATIONS_SET_USER](state, data) {
            //题型目前还没有存储
            state.user = data;
        },

        [USER_MUTATIONS_SET_TOKEN](state, data) {
            //题型目前还没有存储
            state.auth_token = data;
        }
    },
    actions: {

    }



}
