import * as types from '../mutations-types'

export default {
    state: {
        currentSubject: '', // 学科
        currentLevel: '', // 年部
        materials: [], // 教材版本&&年级
        composeQuestions: []
    },
    getters: {
        currentSubject: state => state.currentSubject,
        currentLevel: state => state.currentLevel,
        materials: state => state.materials,
        composeQuestions: state => state.composeQuestions
    },
    mutations: {
        [ types.SET_SUBJECT ]( state, data ) {
            state.currentSubject = data;
        },
        [ types.SET_LEVEL ]( state, data ) {
            state.currentLevel = data;
        },
        [ types.SET_MATERIALS ]( state, data ) {
            state.materials = data;
        },
        [ types.SET_QUESTIONS ]( state, data ) {
            state.composeQuestions = data;
        }
    },
    actions: {
        // 设置年部学科
        setSubjectLevel( store, data ) {
            store.commit( types.SET_SUBJECT, data.subject )
            store.commit( types.SET_LEVEL, data.level )
        },
        // 设置教材版本&&年级
        setMaterials( store, data ) {
            store.commit( types.SET_MATERIALS, data )
        },
        // 设置组卷选中所有试题
        setQuestions( store, data ) {
            store.commit( types.SET_QUESTIONS, data )
        }
    }

}
