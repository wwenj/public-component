

/*

1. 横向划分|纵向划分
1.1. 数据中心
2. 获取数据
3. 使用getters
4. 使用actions
5. 使用mutations
6. vue的双向绑定，单选题题干完成，其他的需要再行思考
7. fetch、get、set


extra:
model
@util
network

*/

import request from '../../common/request'
import { SOURCE_GETTERS_SOURCE } from './source'
import { root } from '../../../node_modules/postcss';

const NAMESPACE = 'QUESTION_'


export const INIT_QUESIONT = `${NAMESPACE}init_question`
export const SET_QUESTION = `${NAMESPACE}set_question`
export const SET_QUESTION_BODY = `${NAMESPACE}set_question_body`
export const SET_QUESTION_STEM = `${NAMESPACE}set_question_stem`
export const SET_QUESTION_ANSWER = `${NAMESPACE}set_question_answer`
export const SET_QUESTION_ANALYSIS = `${NAMESPACE}set_question_analysis`
export const SET_QUESTION_IS_COPY = `${NAMESPACE}set_question_is_copy`



export const GET_QUESTION = `${NAMESPACE}get_question`;

export const FETCH_QUESTION =`${NAMESPACE}fetch_question`;

export const QUESTION_ACTIONS_ADD_QUESTION = `${NAMESPACE}add_question`;

export const QUESTION_ACTIONS_CURRENT_USER_INFO = `${NAMESPACE}current_user_info`

export const QUESTION_MUTATIONS_SET_CURRENT_SUBJECT = `${NAMESPACE}set_current_subject`
export const QUESTION_MUTATUIONS_SET_CURRENT_GRADE = `${NAMESPACE}set_current_grade`

export default {

    state: {
        question: {
            id: 0,
            type: 1,
            body: {
                stem: {
                    body: "",
                    options: {}
                },
                answer: {
                    type: 1,
                    items: {}
                },
                analysis: {
                    enabled: 1,
                    type: 2,
                    detail: {}
                }
            }
        },

        isCopy: false,         // 是否复制

        currentSubject: '',
        currentGradeLevel: ''        // 学部
    },


    getters: {
        [GET_QUESTION](state) {
            return state.question;
        }
    },

    mutations: {

        [QUESTION_MUTATIONS_SET_CURRENT_SUBJECT] (state, subjectId) {
            state.currentSubject = subjectId
        },

        [QUESTION_MUTATUIONS_SET_CURRENT_GRADE] (state, gradeId) {
            state.currentGrade = gradeId
        },

        [SET_QUESTION_BODY](state, data) {
            state.question.body = data
            state.question.type = data.questionType
        },

        [SET_QUESTION_STEM](state, data) {
            console.log('vuex: ', data)
            state.question.body.stem = data
        },

        [SET_QUESTION_ANSWER](state, data) {
            console.log('vuex: ', data)
            state.question.body.answer = data
        },

        [SET_QUESTION_ANALYSIS](state, data) {
            console.log('vuex: ', data)
            state.question.body.analysis = data
        },

        [SET_QUESTION](state, data){
            state.question = data
        },

        [SET_QUESTION_IS_COPY] (state, data) {
            state.isCopy = data
        }
    },
    actions: {
        [QUESTION_ACTIONS_ADD_QUESTION](store){
            var question = store.state.question
            var source = store.getters[SOURCE_GETTERS_SOURCE]
            source.forEach((item, index) => {
                item['subject_id'] = store.state.currentSubject
                item['level_id'] = store.state.currentGrade
            })
            var obj = {
                "type_id": question.type,
                "level_id": store.state.currentGrade,
                "subject_id": store.state.currentSubject,
                "source": source,
                "body": question.body
            }
            request.addQuestion(obj)
            .then(res => {
                console.log(res)
            })
            .catch(err => {
                console.log(err)
            })
        },
        [QUESTION_ACTIONS_CURRENT_USER_INFO](store, obj){
            return request.currentUserInfo(obj)
        }
    }


}
