// TODO待删除

// import request from '@/common/request'
// import { NetworkCode } from '@/common/constant'
// const NAMESPACE = 'SOURCE_'

// export const SOURCE_GETTERS_SOURCE = `${NAMESPACE}source_getter_source`
// export const SOURCE_GETTERS_PROVINCE = `${NAMESPACE}source_getter_province`
// export const SOURCE_GETTERS_SOURCE_TYPE = `${NAMESPACE}source_getter_source_type`
// export const SOURCE_GETTERS_CITYS = `${NAMESPACE}source_getter_citys`
// export const SOURCE_GETTERS_YEAR = `${NAMESPACE}source_getter_year`
// export const SOURCE_GETTERS_GRADE = `${NAMESPACE}source_getter_grade`
// export const SOURCE_GETTERS_SOURCE_NAME = `${NAMESPACE}source_getters_source_name`

// export const SOURCE_MUTATIONS_SET_SOURCE = `${NAMESPACE}source_mutations_set_source`
// export const SOURCE_MUTATIONS_SET_SOURCE_TYPES = `${NAMESPACE}source_mutations_set_examination_types`
// export const SOURCE_MUTATIONS_SET_PROVINCES = `${NAMESPACE}source_mutations_set_provinces`
// export const SOURCE_MUTATIONS_SET_CITYS = `${NAMESPACE}source_mutations_set_citys`
// export const SOURCE_MUTATIONS_SET_CURRENT_PROVINCE = `${NAMESPACE}source_mutations_set_current_province`
// export const SOURCE_MUTATIONS_SET_YEAR = `${NAMESPACE}source_mutations_set_year`
// export const SOURCE_MUTATIONS_SET_GRADE = `${NAMESPACE}source_mutations_set_grade`

// export const SOURCE_ACTIONS_REQUEST_SOURCE_TYPES = `${NAMESPACE}source_actions_request_examination_type`
// export const SOURCE_ACTIONS_REQUEST_PROVINCES = `${NAMESPACE}source_actions_request_provinces`
// export const SOURCE_ACTIONS_REQUEST_CITYS = `${NAMESPACE}source_actions_request_city`
// export const SOURCE_ACTIONS_REQUEST_GRADE = `${NAMESPACE}source_actions_request_grade`
// export default {
//     namespace: true,

//     state: {
//         // 来源
//         source: [],
//         // 来源类型
//         source_types: [],
//         // 省份
//         provinces: [],
//         // 当前省份
//         // current_province: 0,
//         // 市
//         citys: [],
//         // 年级
//         grade: [],
//         // 学年
//         year: [],
//         // 来源中的名字
//         source_name: []
//     },

//     getters: {
//         [SOURCE_GETTERS_SOURCE] (state) {
//             return state.source
//         },
//         [SOURCE_GETTERS_SOURCE_NAME] (state) {
//             return state.source_name
//         },
//         [SOURCE_GETTERS_PROVINCE] (state) {
//             return state.provinces
//         },
//         [SOURCE_GETTERS_SOURCE_TYPE] (state) {
//             return state.source_types
//         },
//         [SOURCE_GETTERS_CITYS] (state) {
//             return state.citys
//         },
//         [SOURCE_GETTERS_YEAR] (state) {
//             return state.year
//         },
//         [SOURCE_GETTERS_GRADE] (state) {
//             return state.grade
//         }
//     },

//     mutations: {
//         [SOURCE_MUTATIONS_SET_SOURCE] (state, data) {
//             state.source = data.sources
//             state.source_name = data.sources_name
//         },
//         [SOURCE_MUTATIONS_SET_SOURCE_TYPES] (state, data) {
//             state.source_types = data
//         },
//         [SOURCE_MUTATIONS_SET_PROVINCES] (state, data) {
//             state.provinces = data
//         },
//         [SOURCE_MUTATIONS_SET_CITYS] (state, data) {
//             state.citys = data
//         },
//         [SOURCE_MUTATIONS_SET_YEAR] (state) {
//             var today = new Date()
//             var year = today.getFullYear()
//             state.year = []
//             for(var i = 0; i < 10; i++) {
//                 state.year.push(year--)
//             }
//         },
//         [SOURCE_MUTATIONS_SET_GRADE] (state, data) {
//             state.grade = data
//         }
//     },
//     actions: {
//         [SOURCE_ACTIONS_REQUEST_SOURCE_TYPES] (state) {
//             // 请求 考试类型接口
//             return request.getSourceType()
//             .then((res) => {
//                 console.log(res)
//                 if(res.status == NetworkCode.Success) {
//                     state.commit(SOURCE_MUTATIONS_SET_SOURCE_TYPES, res.data.data)
//                 }
//             })
//             .catch((err => {
//                 console.log(err)
//             }))
//         },
//         [SOURCE_ACTIONS_REQUEST_PROVINCES] (state) {
//             // 请求 省份的接口
//             return request.getProvince()
//             .then((res) => {
//                 if(res.status == NetworkCode.Success) {
//                     state.commit(SOURCE_MUTATIONS_SET_PROVINCES, res.data.data)
//                 }
//             })
//             .catch((err => {
//                 console.log(err)
//             }))
//         },
//         [SOURCE_ACTIONS_REQUEST_CITYS] (state, obj) {
//             // 请求 城市的接口
//             return request.getCitys(obj)
//             .then((res) => {
//                 console.log(res)
//                 if(res.status == NetworkCode.Success) {
//                     state.commit(SOURCE_MUTATIONS_SET_CITYS, res.data.data.city)
//                 }
//             })
//             .catch((err) =>{
//                 console.log(err)
//             })
//         },
//         [SOURCE_ACTIONS_REQUEST_GRADE] ({state, commit, rootState}) {
//             return request.getGrade(rootState.question.currentGrade)
//             .then((res) => {
//                 console.log(res)
//                 if(res.status == NetworkCode.Success) {
//                     commit(SOURCE_MUTATIONS_SET_GRADE, res.data.data.grade)
//                 }
//             })
//             .catch((err) => {
//                 console.log(err)
//             })
//         }
//     }
// }
