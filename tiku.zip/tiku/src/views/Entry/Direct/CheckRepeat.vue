<template>
    <div class="checkrepeat-wrapper">

        <div class="checkrepeat-header">
            <span>相似题</span>
        </div>

        <div class="checkrepeat-content">
            <ul class="search-result-list">
                <li class="search-result-item" v-for="(item, index) in repeatQuestionArray">
                    <div class="qs" v-if="item.source == 'qs'">
                         <!-- <div class="source">
                            <ul>
                                <li v-for="source in item.source">{{source}}</li>
                            </ul>
                        </div> -->

                        <div class="stem" v-if="item.question && item.question.stem">
                            <div class="question-stem" v-html="item.question.stem"></div>
                        </div>

                        <div class="answer" v-if="item.question.answer">
                            <div class="label-container">
                                <div class="label">答案 :</div>
                            </div>
                            <div class="content-container" v-html="item.question.answer">
                                <!-- {{item.question.answer}} -->
                            </div>
                        </div>

                        <div class="analysis" v-if="item.question.analysis">
                            <div class="label-container">
                                <div class="label">解析 :</div>
                            </div>
                            <div class="content-container" v-html="item.question.analysis">
                                <!-- {{item.question.analysis}} -->
                            </div>
                        </div>

                        <div class="operation">
                            <!-- <button class="btn-repeat-confirm" :data-id="item.uuid" :data-index="index" @click="onClickRepeatConfirm">确定与该题重复</button> -->
                        </div>
                    </div>

                    <div class="tl" v-if="item.source == 'tl'">
                        <div class="stem" v-if="item.question && item.question.stem">
                            <div class="question-stem" v-html='item.question.stem.body'></div>
                            <div class="options" v-if="item.question.stem.options">
                                <ul>
                                    <li v-for="(option, index) in item.question.stem.options">
                                        <span v-html="index" v-if='Question.WordStosen.type !== item.question.type'></span>
                                        <span v-html="option"></span>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="answer" v-if="item.question.answer">
                            <div class="label-container">
                                <div class="label">答案 :</div>
                            </div>
                            <div v-if="item.question.answer.type == AnswerType.Letters || item.question.answer.type == AnswerType.Content " v-html="item.question.answer.items"></div>
                            <ul v-if="item.question.answer.type == AnswerType.Judge || item.question.answer.type == AnswerType.Pair ">
                                <li v-for="(answer, index) in item.question.answer.items">
                                    <span v-html="index"></span>
                                    <span v-html="answer"></span>
                                </li>
                            </ul>
                        </div>

                        <div class="analysis" v-if="item.question.analysis">
                            <div class="label-container">
                                <div class="label">解析 :</div>
                            </div>
                            <ul>
                                <li v-for="(analysis, index) in item.question.analysis.detail">
                                    <span v-html="index"></span>
                                    <span v-html="analysis"></span>
                                </li>
                            </ul>
                        </div>

                        <div class="operation">
                            <button class="btn-repeat-confirm" :data-id="item.uuid" :data-index="index" @click="onClickRepeatConfirm">确定与该题重复</button>
                            <button class="btn-copy" :data-index="index" @click="onClickCopy">一键复制</button>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
import { Question, AnswerType } from '@/common/constant'
export default {
    props: {
        questionType: {
            type: Number,
            default: 1
        },

        repeatQuestionArray: {
            type: Array,
            default: () => {
                return []
            }
        },

        inputSource: {
            type: Array,
            default: () => {
                return []
            }
        },
        inputCurrentSubject: {
            type: Number,
            default: 0
        }
    },
    data() {
        return {
            Question,
            AnswerType
        }
    },
    methods: {
        onClickRepeatConfirm: function (e) {
            var that = this
            // console.log(e)
            let id = e.target.dataset['id']
            that.$modalMessage({
                offset: ['400px', '400px'],
                title: '确认与该题重复吗',
                msg: '确认后会将新的试题来源同步到该题目上，如新题目来源不详细，请修改后确认',
                confirm: (res) => {
                    that.$api['recording/repeatSource']({
                        qid: id,
                        source: that.inputSource,
                        subject_id: that.inputCurrentSubject
                    }).then(data => {
                        that.$emit('determineRepeatQuestionEmit')
                    })
                    that.$modalMessageClose()
                }
            })
        },

        onClickCopy: function (e) {
            var self = this
            let index = e.target.dataset['index']
            // console.log('当前题型: ', this.questionType)
            // console.log('所选题型: ', this.repeatQuestionArray[index].question.type)
            if (this.questionType != this.repeatQuestionArray[index].question.type) {
                self.$modalMessage({
                    msg: '当前题型和所选题型不符',
                    confirm: (res) => {
                        self.$modalMessageClose()
                    }
                })
            }
            else {
                this.$emit('emitCopyQuestion', this.repeatQuestionArray[index].question)
            }
        }
    },
    watch: {
        repeatQuestionArray: function (newVal, oldVal) {
            this.$nextTick(() => {
                MathJax.Hub.Queue(["Typeset",MathJax.Hub])
            })
        },

        questionType: function (newVal, oldVal) {
            // console.log("查重题当前题目类型: ", newVal)
        }
    }
}
</script>

<style lang="scss" scoped>
@import '@/assets/css/recording/CheckRepeat.scss';
</style>


