<template>
    <div class="source">
        <div class="title">
            <span>试题来源</span>
        </div>
        <div :class="index>0?'add-source':''" v-for="(item,index) in sourceNumArray" :key="item">
            <div :class="index>0?'del-source':'del-source2'">
                <img src="@/assets/img/recording/del.png" title="删除" @click="delSourceOnClick(index)">
            </div>
            <source-content @clearSourceDataEmit="clearSourceData" @sourceDataArrayEmit="sourceDataArray" ref="sourceContent"></source-content>
        </div>
        <button class="add-btn" @click="addSourceOnClick">
            <img src="@/assets/img/recording/add.png" alt="">
            <span>增加来源</span>
        </button>
    </div>
</template>
<script>
import { mapState } from 'vuex'
import SourceContent from '@/views/Entry/Direct/Source/SourceContent'
export default {
    components: {
        SourceContent
    },
    data() {
        return {
            sourceNumArray: [1]
        }
    },
    computed: {
        ...mapState({
            currentGrade: state => state.question.currentGradeLevel, // 获取vuex年级
            currentSubject: state => state.question.currentSubject // 获取vuex学科
        })
    },
    watch: {
        // 改变年级时重新请求题型类型
        currentSubject: function(newval, oldval) {
            this.sourceNumArray = [Math.random()]
        },
        currentGrade: function(newval, oldval) {
            this.sourceNumArray = [Math.random()]
        }
    },
    methods: {
        /* action */
        addSourceOnClick: function() {
            this.sourceNumArray.push(Math.random())
        },
        delSourceOnClick: function(index) {
            this.sourceNumArray.splice(index, 1)
            let tepSourceData = this.sourceDataObject()
            this.$emit('sourceDataEmit', tepSourceData)
        },
        /* emit */
        // 来源内容变化时返回父组件数据
        sourceDataArray: function(data) {
            let tepSourceData = this.sourceDataObject()
            console.log('watch来源数据')
            console.log(tepSourceData)
            this.$emit('sourceDataEmit', tepSourceData)
        },
        /* public */
        // 重置来源函数
        clearSourceData: function() {
            this.sourceNumArray = [Math.random()]
        },
        /* output */
        // DE组件获取来源数据访问接口，
        sourceDataObject: function() {
            var source = []
            this.$nextTick(() => {
                let sourceRef = this.$refs.sourceContent
                for (let i = 0; i < sourceRef.length; i++) {  // 未选择题型不保存数据
                    if(sourceRef[i].sourceContentSaveData().source_type_id){
                        source.push(sourceRef[i].sourceContentSaveData())
                    }
                }
            })
            return source
        }
    }
}
</script>

<style lang="scss" scoped>
.source {
    padding: 38px 38px;
    box-sizing: border-box;
    .add-source {
        margin-top: 30px;
        padding-top: 30px;
        border-top: solid 1px #dcdcdc;
        position: relative;
    }
    .del-source2 {
        display: none;
    }
    .del-source {
        position: absolute;
        cursor: pointer;
        top: 30px;
        right: 0;
    }
    .title {
        margin-bottom: 20px;
    }
    .add-btn {
        margin-top: 30px;
    }
}
</style>

