<template>
    <div class="source-wrapper">
        <div class="source-content">
            <el-select style="width:160px;float:left;margin: 0 22px 12px 0;" size="medium" v-model="sourceTypeValue.source_type_id" placeholder="请选择" @change="examinationTypeOnChange">
                <el-option v-for="(item) in SourceTypeArray" :key="item.id" :label="item.name" :value="item.id">
                </el-option>
            </el-select>
            <div class="select-content" v-if="sourceDataArray" v-for="(item, index) in sourceDataArray" :key="index">
                <el-select style="width:160px;" size="medium" v-model="SourceSaveData[item.name]" @change="selectContentOnChange(item.name,item.data)">
                    <el-option v-for="(item1) in item.data" :key="item1.id" :label="item1.name" :value="item1.id">
                    </el-option>
                </el-select>
            </div>
        </div>
        <!-- 学校 -->
        <div class="remarks" v-if="computedSchoolShow" @click="findSchoolOnClick">
            <button>
                {{schoolName}}
                <img src="@/assets/img/recording/add.png" alt="" v-if="computedDelShow">
                <img src="@/assets/img/recording/delData.png" v-else title="删除学校" @click.stop="delSchoolOnClick">
            </button>
        </div>
        <!-- 所选章节 -->
        <div class="remarks" v-if="computedShapterShow">
            <button v-if="SourceChaperNameDataArray.length===0" @click="findChapterOnClick">
                所属章节
                <img src="@/assets/img/recording/add.png">
            </button>
            <button v-else v-for="(item,index) in SourceChaperNameDataArray" :key="index" @click="findChapterOnClick">
                {{item}}
                <img src="@/assets/img/recording/delData.png" @click.stop="delChapterOnClick(index,item.tid)">
            </button>
        </div>
        <!-- 备注 -->
        <div class="remarks" v-if="sourceDataArray">
            <input v-model="SourceSaveData.note" type="text" placeholder="备注">
        </div>

        <source-content-choice-chapter v-if="isChapterShow" ref="chapter" @chapterCloseEmit="chapterCloseEmit" @chapterDataEmit="chapterDataEmit">
        </source-content-choice-chapter>
        <div v-if="sourceDataArray">
            <ChoiceSchool v-if="sourceDataArray.province_id" @schoolIdEmit="schoolIdEmit" :inputProvinceDataArray="sourceDataArray.province_id.data" ref="choiceSchool"></ChoiceSchool>
        </div>
    </div>
</template>
<script>
// import request from '@/common/request'
// import { toCityAjax, toAreaAjax } from '@/common/commonAjax'
// import { NetworkCode } from '@/common/constant'
import { mapState } from 'vuex'
import SourceContentChoiceChapter from '@/views/Entry/Direct/Source/SourceContentChoiceChapter'
export default {
    components: {
        SourceContentChoiceChapter
    },
    data() {
        return {
            // 首字母尽量小写开头
            SourceTypeArray: [], // 所有题型
            sourceDataArray: null, // 所有显示列表
            SourceTypeFormatArray: [], // 所选题型下的所有显示列表数组
            isChapterShow: false, // 控制所属章节的组件显示
            sourceTypeValue: {
                // 当前选择的题型
                source_type_id: '',
                subject_id: '',
                level_id: ''
            },
            SourceSaveData: {
                start_school_year_name: '',
                year_name_name: '',
                source_type_id: '',
                year: '', //年份
                start_school_year: '', //学年
                month: '', //月份
                term_id: '', //学期
                science_id: '', //文理
                subject_id: '', //科目
                ab_exam_id: '', //AB卷
                grade_id: '', //年级
                page_tag_id: '', //卷标
                level_id: '', //年部
                province_id: '', // 省
                city_id: '', // 市
                area_id: '', // 区
                school_id: '', //学校
                section_node_ids: '', //所属章节id列表
                source_type_id_name: '',
                note_name: '',
                month_name: '',
                term_id_name: '',
                science_id_name: '',
                subject_id_name: '',
                ab_exam_id_name: '',
                grade_id_name: '',
                page_tag_id_name: '',
                level_id_name: '',
                province_id_name: '',
                city_id_name: '',
                area_id_name: '',
                school_id_name: '',
                section_node_ids_name: '',
                note: '' // 备注
            }, // 保存时提交的数据
            inputSchoolAddresData: {}, // 向学校组件传递省市区数据
            schoolName: '学校', // 显示的学校名
            SourceChaperNameDataArray: [] // 选中章节结果展示
        }
    },
    mounted() {
        // 首次加载请求所有题型
        this.sourceTypeValue.subject_id = this.currentSubject
        this.sourceTypeValue.level_id = this.currentGrade
        this.getSourceTypeAjax()
    },
    methods: {
        /* action */
        // 删除已选学校
        delSchoolOnClick: function() {
            this.schoolName = '学校'
            this.SourceSaveData.school_id = ''
            this.SourceSaveData.school_id_name = ''
        },
        // 删除已选章节
        delChapterOnClick: function(index, tid) {
            var tepIndex = tid + ','
            if (this.SourceChaperNameDataArray.length === 1) {
                tepIndex = tid
            }
            var reg = new RegExp(tepIndex, 'g')
            this.SourceSaveData.section_node_ids = this.SourceSaveData.section_node_ids.replace(
                reg,
                ''
            )
            this.SourceChaperNameDataArray.splice(index, 1)
        },
        // 选中题型后二次请求
        examinationTypeOnChange: function(aa) {
            // 选择别的题型是清除以前保存的数据,并清除vue缓存dom
            this.sourceDataArray = null
            this.schoolName = '学校'
            for (let item in this.SourceSaveData) {
                this.SourceSaveData[item] = ''
            }
            // this.SourceSaveData = Object.assign(this.SourceSaveData,this.sourceTypeValue)
            this.SourceSaveData.subject_id = this.currentSubject
            this.SourceSaveData.level_id = this.currentGrade
            this.SourceSaveData.source_type_id = this.sourceTypeValue.source_type_id
            this.SourceTypeArray.forEach(item=>{
                if(item.id === this.sourceTypeValue.source_type_id){
                    this.SourceSaveData.source_type_id_name = item.name
                }
            })
            // 下拉框修改后的选项
            let tmpValue = this.sourceTypeValue.source_type_id
            if (tmpValue) {
                // 保存题目类型
                this.setSourceTypeDataArray(tmpValue)
                // var obj = {
                //     source_type_id: tmpValue
                // }
                this.$api['recording/sourceParams']({
                    source_type_id: tmpValue
                }).then(data => {
                    this.sourceDataArray = data
                })
                // request
                //     .getSourceParams(obj)
                //     .then(response => {
                //         if (response.data.code !== NetworkCode.Success) {
                //             console.log(
                //                 '题型内容请求错误' + response.data.message
                //             )
                //         } else {
                //             console.log('题型内容请求成功')
                //             this.sourceDataArray = response.data.data
                //             console.log(this.sourceDataArray)
                //         }
                //     })
                //     .catch(error => {
                //         console.log(error)
                //         alert('题型内容请求过程出错')
                //     })
            } else {
                this.$emit('clearSourceDataEmit')
            }
        },
        // 当点击内容下拉框，保存选择选项数据
        selectContentOnChange: function(item, itemData) {
            var that = this
            var tmpCityDefault = [{ id: '', name: '市' }]
            var tmpAreaDefault = [{ id: '', name: '区' }]

            var tmpValue = this.SourceSaveData[item] // 保存id
            var itemDataName // 保存name

            itemData.forEach(function(item) {
                // 后台id类型不统一暂时用 ==
                if (item.id == tmpValue) {
                    itemDataName = item.name
                }
            })
            let tmpKey = item + '_name'
            if (Boolean(tmpValue)) {
                // 保存数据
                this.SourceSaveData[item] = tmpValue
                this.SourceSaveData[tmpKey] = itemDataName
            } else {
                // 初始数据
                this.SourceSaveData[item] = ''
                this.SourceSaveData[tmpKey] = ''
            }
            // 当选择省时查询市,或根据市查询区
            if (item === 'province_id') {
                this.delSchoolOnClick() // 清空学校
                if (Boolean(tmpValue)) {

                    this.$api['recording/getCities']({
                        province_id: tmpValue
                    }).then(data => {
                        that.sourceDataArray.city_id.data = data
                        that.sourceDataArray.area_id.data = tmpAreaDefault
                        that.SourceSaveData.city_id = ''
                        that.SourceSaveData.city_id_name = ''
                        that.SourceSaveData.area_id = ''
                        that.SourceSaveData.area_id_name = ''
                    })
                    // toCityAjax(tmpValue, function(data) {
                    //     that.sourceDataArray.city_id.data = data
                    //     that.sourceDataArray.area_id.data = tmpAreaDefault
                    //     that.SourceSaveData.city_id = ''
                    //     that.SourceSaveData.city_id_name = ''
                    //     that.SourceSaveData.area_id = ''
                    //     that.SourceSaveData.area_id_name = ''
                    // })
                } else {
                    that.sourceDataArray.city_id.data = tmpCityDefault
                    that.sourceDataArray.area_id.data = tmpAreaDefault
                    that.SourceSaveData.city_id = ''
                    that.SourceSaveData.city_id_name = ''
                    that.SourceSaveData.area_id = ''
                    that.SourceSaveData.area_id_name = ''
                }
            } else if (item === 'city_id') {
                this.delSchoolOnClick() // 清空学校
                if (tmpValue) {
                    this.$api['recording/getAreas']({
                        city_id: tmpValue
                    }).then(data => {
                        that.sourceDataArray.area_id.data = data
                        that.SourceSaveData.area_id = ''
                        that.SourceSaveData.area_id_name = ''
                    })
                    // toAreaAjax(tmpValue, function(data) {
                    //     that.sourceDataArray.area_id.data = data
                    //     that.SourceSaveData.area_id = ''
                    //     that.SourceSaveData.area_id_name = ''
                    // })
                } else {
                    that.sourceDataArray.area_id.data = tmpAreaDefault
                    that.SourceSaveData.area_id = ''
                    that.SourceSaveData.area_id_name = ''
                }
            } else if (item === 'area_id') {
                this.delSchoolOnClick() // 清空学校
            }
        },
        // 显示查找学校组件
        findSchoolOnClick: function() {
            // 把省市区数据传进去
            // this.inputSchoolAddresData = {}
            let tmpSchoolData = {}
            if (this.sourceDataArray.province_id) {
                tmpSchoolData.province = this.SourceSaveData.province_id
                tmpSchoolData.city = this.SourceSaveData.city_id
                tmpSchoolData.area = this.SourceSaveData.area_id
            }
            this.$refs.choiceSchool.show(
                tmpSchoolData,
                this.sourceDataArray.city_id.data,
                this.sourceDataArray.area_id.data
            )
        },
        // 显示所属章节组件
        findChapterOnClick: function() {
            this.isChapterShow = true
        },
        /* emit */
        // 选择学校，获取学校id
        schoolIdEmit: function(cityDataArray, areaDataArray, schoolItem) {
            // 增加学校数据，更新地址数据
            this.SourceSaveData.province_id = schoolItem.province_id
            this.SourceSaveData.city_id = schoolItem.city_id
            this.SourceSaveData.area_id = schoolItem.area_id
            // 更新地址name数据
            this.SourceSaveData.province_id_name = schoolItem.province_name
            this.SourceSaveData.city_id_name = schoolItem.city_name
            this.SourceSaveData.area_id_name = schoolItem.area_name
            // 更新市区数组赎金
            this.sourceDataArray.city_id.data = cityDataArray
            this.sourceDataArray.area_id.data = areaDataArray
            // 更新学校信息
            this.SourceSaveData.school_id = schoolItem.school_id
            this.SourceSaveData.school_id_name = schoolItem.school_name
            // 显示学校信息
            this.schoolName = schoolItem.school_name
        },
        // 关闭搜索学校组件
        schoolCloseEmit: function() {},
        // 关闭所属章节组件
        chapterCloseEmit: function() {
            this.isChapterShow = false
        },
        // 保存章节信息
        chapterDataEmit: function(chapterId, chapterPath) {
            this.SourceSaveData.section_node_ids = chapterId
            this.SourceChaperNameDataArray = chapterPath
        },
        /* private */
        // 获取所有当前题型下的下拉框
        setSourceTypeDataArray: function(value) {
            // let tmpIndex = value - 300
            var that = this
            // 对固定题型传固定学期年级
            if (
                value === 301 ||
                value === 302 ||
                value === 303 ||
                value === 304 ||
                value === 305
            ) {
                this.SourceSaveData.grade_id = 12
                this.SourceSaveData.grade_id_name = '高三'
                this.SourceSaveData.term_id = 2
                this.SourceSaveData.term_id_name = '下学期'
            }
            this.SourceTypeArray.forEach(function(item) {
                if (item.id == value) {
                    that.SourceTypeFormatArray = item.show
                }
            })
        },
        /* output */
        // 获取所有来源数据对外接口
        sourceContentSaveData: function() {
            return this.SourceSaveData
        },
        /* Ajax */
        // 首次进入所有题型请求
        getSourceTypeAjax: function() {
            // var obj = {
            //     level_id: this.currentGrade
            // }
            this.$api['recording/sourceType']({
                level_id: this.currentGrade
            }).then(data => {
                this.SourceTypeArray = data
            })
            // request
            //     .getSourceType(obj)
            //     .then(response => {
            //         if (response.data.code !== NetworkCode.Success) {
            //             console.log('来源类型请求错误' + response.data.message)
            //         } else {
            //             console.log('来源类型请求成功')
            //             console.log(response.data)
            //             this.SourceTypeArray = response.data.data
            //         }
            //     })
            //     .catch(error => {
            //         console.log(error)
            //         alert('来源类型请求过程出错catc')
            //     })
        }
    },
    computed: {
        // 学校是否显示
        computedSchoolShow: function() {
            return this.SourceTypeFormatArray.some(function(item) {
                return item === 'school_id'
            })
        },
        // 所属章节是否显示
        computedShapterShow: function() {
            return this.SourceTypeFormatArray.some(function(item) {
                return item === 'section_node_ids'
            })
        },
        // 控制选择学校按钮加好/删除号的显示
        computedDelShow: function() {
            if (this.schoolName === '学校') {
                return true
            } else {
                return false
            }
        },
        ...mapState({
            currentGrade: state => state.question.currentGradeLevel, // 获取vuex年部
            currentSubject: state => state.question.currentSubject // 获取vuex学科
        })
    },
    watch: {
        SourceSaveData: {
            handler: function(newval, oldval) {
                this.$emit('sourceDataArrayEmit', newval)
            },
            deep: true
        },
        // 改变年级时重新请求题型类型
        currentSubject: function(newval, oldval) {
            this.SourceSaveData.subject_id = newval
        },
        currentGrade: function(newval, oldval) {
            this.SourceSaveData.level_id = newval
        }
    }
}
</script>

<style lang="scss" scoped>
.source-wrapper {
    select {
        width: 160px;
        height: 36px;
        margin: 0 22px 12px 0;
        background-color: #ffffff;
        border-radius: 4px;
        color: #b1b8c9;
        float: left;
        border: solid 1px rgba(160, 171, 188, 0.22);
    }
    .source-content {
        width: 100%;
        overflow: auto;
    }
    .remarks {
        width: 100%;
        button,
        input {
            width: 100%;
            height: 36px;
            background-color: #ffffff;
            color: #b1b8c9;
            border-radius: 4px;
            border: solid 1px rgba(160, 171, 188, 0.22);
            text-indent: 15px;
            text-align: left;
            margin-bottom: 12px;
            outline: none;
            cursor: pointer;
            padding-right: 30px;
            position: relative;
            overflow: hidden;
            line-height: 36px;
            img {
                position: absolute;
                right: 10px;
                top: 50%;
                transform: translateY(-50%);
            }
        }
    }
    .select-content {
        width: 160px;
        height: 36px;
        margin: 0 22px 12px 0;
        background-color: #ffffff;
        color: #b1b8c9;
        float: left;
    }
}
</style>

