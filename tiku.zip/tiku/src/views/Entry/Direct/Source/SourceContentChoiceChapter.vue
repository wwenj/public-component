<template>
    <transition name="chapter-fade">
        <div class="chapter" @click.stop>
            <div class="chapter-wrapper">
                <div class="chapter-header">
                    <h3>所属章节</h3>
                    <span class="close" @click="chapterCloseOnClick">X</span>
                </div>
                <div class="chapter-content">
                    <div class="select-top">
                        <span class="select-title">教材版本：</span>
                        <div class="select-content">
                            <select @change="sectionTypeOnChange($event)">
                                <option v-for="(item,index) in sectionArray" :value="index" :key="index">{{item.name}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="select-top">
                        <span class="select-title">教材：</span>
                        <div class="select-content" v-if="sectionArray.length">
                            <select @change="getChaptersDataOnChange($event)">
                                <option value="">请选择</option>
                                <option v-for="(item1,index) in sectionArray[sectionTypeIndex].materials" :value="item1.section_node_id" :key="index">{{item1.name}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="el-tree">
                        <!-- check-strictly父子完全分离 -->
                        <el-tree ref="tree" :data="sectionChapterDataArray" :props="defaultProps" show-checkbox></el-tree>
                    </div>
                </div>
                <div class="chapter-footer">
                    <button class="rightBtn" @click="chapterCloseOnClick">取消</button>
                    <button @click="chapterConfirmOnClick">确定</button>
                </div>
            </div>
        </div>
    </transition>
</template>

<script type="text/ecmascript-6">
// import request from '@/common/request'
// import { NetworkCode } from '@/common/constant'
import { mapState } from 'vuex'
export default {
    data() {
        return {
            sectionArray: [], // 教材数据
            sectionTypeIndex: '0', // 教材版本索引
            sectionChapterDataArray: [], // 所属章节树数据
            sectionChapterSaveDataArray: [], // 所属章节保存
            defaultProps: {
                children: 'childs',
                label: 'name'
            }
        }
    },
    computed: {
        ...mapState({
            currentSubject: state => state.question.currentSubject, // 获取vuex学科
            currentGrade: state => state.question.currentGradeLevel // 获取vuex年级
        })
    },
    mounted() {
        this.getSourceSectionAjax()
    },
    methods: {
        /* action */
        // 取消
        chapterCloseOnClick: function() {
            this.$emit('chapterCloseEmit')
        },
        // 确认
        chapterConfirmOnClick: function() {
            var that = this
            this.sectionChapterSaveDataArray = []
            let tmpChapterData = this.$refs.tree.getCheckedNodes()
            console.log('-----')
            console.log(tmpChapterData)
            var ChapterDataIdArray = [] // 所选章节id集合
            var ChapterDataPathArray = [] // 所选章节路径集合

            tmpChapterData.forEach(function(item) {
                if(item.is_leaf === 1){
                    ChapterDataIdArray.push(item.section_node_id)
                    ChapterDataPathArray.push(item.word_path)
                }
            })

            let ChapterDataId = ChapterDataIdArray.join(',')
            // 返回两个参数，id字符串，路径集合
            this.$emit('chapterDataEmit', ChapterDataId, ChapterDataPathArray)
            this.$emit('chapterCloseEmit')
        },
        // 教材版本改变
        sectionTypeOnChange: function($event) {
            this.sectionTypeIndex = $event.target.value
        },
        // 选择教材获取章节数据
        getChaptersDataOnChange: function($event) {
            let temSectionNodeId = $event.target.value
            if (temSectionNodeId) {
                // let obj = {
                //     subject_id: this.currentSubject,
                //     section_node_id: temSectionNodeId
                // }
                this.$api['recording/sourceChapter']({
                    subject_id: this.currentSubject,
                    section_node_id: temSectionNodeId
                }).then(data => {
                    this.sectionChapterDataArray = data.childs
                })
                // request
                //     .getSourceChapter(obj)
                //     .then(response => {
                //         if (response.data.code !== NetworkCode.Success) {
                //             console.log(
                //                 '章节教材请求错误' + response.data.message
                //             )
                //         } else {
                //             console.log('章节教材请求成功')
                //             console.log(response.data)
                //             this.sectionChapterDataArray =
                //                 response.data.data.childs
                //         }
                //     })
                //     .catch(error => {
                //         console.log(error)
                //         alert('章节教材请求过程出错')
                //     })
            } else {
                this.sectionChapterDataArray = []
            }
        },
        /* private */
        // 返回所属章节信息
        chapterDataEmit: function(nameData) {
            this.$emit('chapterDataEmit', this.chapterSaveData(), nameData)
        },
        // Ajax
        // 首次进入所有题型请求
        getSourceSectionAjax: function() {
            // var obj = {
            //     subject_id: this.currentSubject,
            //     grade_level_id: this.currentGrade
            // }
            this.$api['recording/sourceMaterials']({
                subject_id: this.currentSubject,
                grade_level_id: this.currentGrade
            }).then(data => {
                this.sectionArray = data
            })
            // request
            //     .getSourceMaterials(obj)
            //     .then(response => {
            //         if (response.data.code !== NetworkCode.Success) {
            //             console.log('章节请求错误' + response.data.message)
            //         } else {
            //             console.log('章节请求成功')
            //             console.log(response.data)
            //             this.sectionArray = response.data.data
            //         }
            //     })
            //     .catch(error => {
            //         console.log(error)
            //         alert('章节请求过程出错catc')
            //     })
        },
        // 封装章节数据结构
        chapterSaveData: function() {
            let chapterData = this.sectionChapterSaveDataArray.join(',')
            return chapterData
        }
    },
    watch: {
        // 改变年级个学科时重新请求章节教材
        currentSubject: function(newval, oldval) {
            this.getSourceSectionAjax()
        },
        currentGrade: function() {
            this.getSourceSectionAjax()
        }
    }
}
</script>

<style scoped lang="scss">
.chapter {
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    z-index: 19980;
    color: #4d4d4d;
    background-color: rgba(0, 0, 0, 0.5);
    .chapter-wrapper {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        overflow: hidden;
        width: 600px;
        height: 700px;
        background-color: #ffffff;
        border-radius: 12px;
        select {
            width: 160px;
            height: 36px;
            background-color: #ffffff;
            border-radius: 4px;
            border: solid 1px rgba(160, 171, 188, 0.22);
            margin: 0 22px 12px 0;
            color: #b1b8c9;
        }
        .chapter-header {
            width: 100%;
            height: 50px;
            background-image: linear-gradient(90deg, #5f7aff 0%, #6bc1fe 100%);
            padding: 0 30px;
            box-sizing: border-box;
            h3 {
                height: 100%;
                line-height: 50px;
                float: left;
                font-size: 18px;
                letter-spacing: 1px;
                color: #ffffff;
            }
            .close {
                height: 100%;
                font-size: 18px;
                color: #ffffff;
                line-height: 50px;
                float: right;
                cursor: pointer;
            }
        }
        .chapter-footer {
            width: 100%;
            height: 65px;
            background-color: #ffffff;
            border-radius: 0px 0px 12px 12px;
            box-shadow: 0px -1px 20px #8888887e;
            z-index: 1000;
            position: absolute;
            bottom: 0px;
            button {
                width: 110px;
                height: 30px;
                color: #ffffff;
                background-image: linear-gradient(
                    90deg,
                    #5f7aff 0%,
                    #6bc1fe 100%
                );
                border-radius: 15px;
                margin-right: 30px;
                float: right;
                margin-top: 17px;
                cursor: pointer;
                outline: none;
            }
            .rightBtn {
                border-radius: 15px;
                border: solid 1px #6e86fd;
                background: #ffffff;
                color: #6e86fd;
            }
        }
        .chapter-content {
            padding: 30px 25px 0 20px;
            box-sizing: border-box;
            .select-top {
                height: 36px;
                font-size: 14px;
                color: #2f2f2f;
                margin-bottom: 20px;
                .select-content {
                    display: inline-block;
                    margin-left: 10px;
                }
                .select-title {
                    display: inline-block;
                    width: 70px;
                    margin-left: 30px;
                }
            }
            .el-tree {
                width: 100%;
                height: 442px;
                overflow: auto;
            }
        }
    }
}

.chapter-fade-enter-active {
    animation: chapter-fadein 0.3s;
}

.chapter-content {
    animation: chapter-zoom 0.3s;
}

@keyframes chapter-fadein {
    0% {
        opacity: 0;
    }

    100% {
        opacity: 1;
    }
}

@keyframes chapter-zoom {
    0% {
        transform: scale(0);
    }

    50% {
        transform: scale(1.1);
    }

    100% {
        transform: scale(1);
    }
}
</style>
