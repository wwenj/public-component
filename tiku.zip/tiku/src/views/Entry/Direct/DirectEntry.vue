<template>
    <div class="wrapper-direct-entry" v-loading="loading" element-loading-background="rgba(0, 0, 0, 0.8)" :style="{'min-height': wrapperHeight}">
        <div class="header">
            <div class="header-left">
                <select name='grade-level' v-model="currentGradeLevel">
                    <option value="">请选择年部</option>
                    <option v-for="(item, index) in gradeLevelArray" :value="item.id" :data-index="index" :key="item.id">{{item.name}}</option>
                </select>
                <select name='subject' v-model="currentSubject">
                    <option value="">请选择科目</option>
                    <option v-for="item in subjectArray" :value="item.id" :key="item.id">{{item.name}}</option>
                </select>
            </div>
            <div class="header-right">
                <button v-if="currentGradeLevel != '' && currentSubject != ''" @click="onClickGiveUp">放弃处理</button>
                <button class="btn btn-save" v-if="showCheckRepeat" @click="onClickSaveQuestion">保存</button>
            </div>
        </div>

        <div class="main-direct-entry" v-if="currentGradeLevel != '' && currentSubject != ''">
            <div class="nav nav-level1">
                <span @click="onClickShowEntry" :class="[!showCheckRepeat?'nav-level1-span-active':'']">
                    <span>录入</span>
                </span>
                <span @click="onClickShowCheckRepeat" :class="[showCheckRepeat?'nav-level1-span-active':'']">
                    <span>查重题</span>
                </span>
            </div>
            <div class="preview-entry">
                <div class="preview" style="overflow-x: scroll">
                    <!-- 预览组件 -->
                    <tal-preview-item
                    :inputQuestion="TalOutputQuestion"
                    :inputSourceDataArray="sourceDataArray">
                    </tal-preview-item>
                </div>
                <div class="entry" v-show="!showCheckRepeat">
                    <div class="nav nav-level2">
                        <span @click="onClickShowEdit" :class="[showEdit?'span-active':'']">
                            试题编辑
                            <img src="@/assets/img/common/selected.png" alt="" width="76" height="14" v-show="showEdit">
                        </span>
                        <span @click="onClickShowSource" :class="[showEdit?'':'span-active']">
                            试题来源
                            <img src="@/assets/img/common/selected.png" alt="" width="76" height="14" v-show="!showEdit">
                        </span>
                    </div>
                    <div class="question-edit" v-show="showEdit">
                        <div class="section">
                            <div class="title">题型</div>
                            <div class="content">
                                <select v-model="questionType">
                                    <option v-for="(question, key, index) in getQuestionTypeArray()" :value="question.component" :key="index">
                                        {{question.chineseName}}
                                    </option>
                                </select>
                            </div>
                        </div>
                        <!-- 录入组件 -->
                        <component
                        :inputQuestion="TalInputQuestion"
                        @initQuestionEmit="onEmitInitQuestion"
                        @questionChangeEmit="onChangeInputQuestion"
                        :is="questionType"
                        ref="questionType"
                        v-if="showQuestionComponent">
                        </component>
                    </div>
                    <div class="question-source" v-show="!showEdit">
                        <question-source
                        ref="sourceData"
                        @sourceDataEmit="sourceDataEmit">
                        </question-source>
                    </div>
                </div>
                <!-- 查重页开始 -->
                <div class="check-repeat" v-show="showCheckRepeat" style="overflow-x: scroll">
                    <check-repeat
                    :repeatQuestionArray='repeatQuestionArray'
                    :questionType='TalOutputQuestion.type'
                    :inputSource='sourceDataArray'
                    :inputCurrentSubject='currentSubject'
                    @emitCopyQuestion='emitCopyQuestion'
                    @determineRepeatQuestionEmit='determineRepeatQuestionEmit'>
                    </check-repeat>
                </div>
                <!-- 查重页结束 -->
            </div>
        </div>
        <div class="hint" v-if="currentGradeLevel == '' || currentSubject == ''">
            <img src="@/assets/img/recording/hint.png" alt="hint">
            <span>请选择科目和年级</span>
        </div>
    </div>
</template>

<script>
import $ from 'jquery'

import { Question, SourceType, QuestionTypeCollection, NetworkCode } from '@/common/constant'

// import request from '@/common/request'

// import {
//     QUESTION_ACTIONS_ADD_QUESTION,
//     QUESTION_ACTIONS_CURRENT_USER_INFO,
//     QUESTION_MUTATIONS_SET_CURRENT_SUBJECT,
//     QUESTION_MUTATUIONS_SET_CURRENT_GRADE
// } from '@/store/modules/question'

// import {
//     GET_SEARCH_RESULT,
//     SEARCH_RESULT_ACTIONS_FETCH_RESULT
// } from '@/store/modules/searchResult'

import Source from '@/views/Entry/Direct/Source/Source'

import checkRepeat from '@/views/Entry/Direct/CheckRepeat'

// import { SOURCE_GETTERS_SOURCE_NAME } from '@/store/modules/source'
// import { mapGetters, mapState } from 'vuex'

import { verifyQuestionStem } from '@/common/common'

export default {
    components: {
        'question-source': Source,
        'check-repeat': checkRepeat
    },
    inject: ['reload'],
    data() {
        return {
            wrapperHeight: '800px',
            SourceType, // 获取来源类型
            Question,

            currentType: '1',
            questionType: Question.SingleChoice.component,
            // questionType: Question.Pair.component,

            showEdit: true,
            showCheckRepeat: false,

            gradeLevelArray: [],
            currentGradeLevel: '',
            subjectArray: [],
            currentSubject: '',
            // 接收子组件传过来的数据
            TalOutputQuestion: {
                type: Question.SingleChoice.type,
                body: {
                    stem: {
                        body: '',
                        options: {}
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Letters,
                        items: ''
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {}
                    }
                }
            },
            // 一键复制 向子组件传的数据
            TalInputQuestion: {
                type: Question.SingleChoice.type,
                body: {
                    stem: {
                        body: '',
                        options: {}
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Letters,
                        items: ''
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {}
                    }
                }
            },

            sourceDataArray: [],

            loading: false,
            repeatQuestionArray: [],
            showQuestionComponent: true
        }
    },
    mounted() {
        this.setHeight()
        this.requestCurrentUserInfo()
    },
    methods: {
        /* action */
        // 题目有任何输入变化
        onChangeInputQuestion: function(question) {
            this.TalOutputQuestion = JSON.parse(JSON.stringify(question))
        },
        // 点击保存题目事件
        onClickSaveQuestion: function() {
            var self = this
            $('.btn-save').attr('disabled', true)
            let res = this.$refs.questionType.checkQuestionError()
            if (res.length !== 0) {
                this.$modalMessage({
                    offset: ['400px', '400px'],
                    title: `检查错误(${res.length}个)`,
                    msg: res,
                    needIndex: true,
                    confirm: res => {
                        self.$modalMessageClose()
                    }
                })
            } else {
                self.$api['recording/addQuestion']({
                    type_id: self.TalOutputQuestion.type,
                    level_id: self.currentGradeLevel,
                    subject_id: self.currentSubject,
                    source: self.sourceDataArray,
                    body: self.TalOutputQuestion.body
                }).then(res => {
                    self.$message({message: '保存成功',type: 'success'})
                    setTimeout(()=>{
                        $('.btn-save').attr('disabled', '')
                        self.reload()
                    }, 3000)
                }).catch( e => {
                    self.$message({message: `保存失败, ${e.message}`,type: 'error'})
                })
            }
        },
        onClickShowEdit: function() {
            this.showEdit = true
        },

        onClickShowSource: function() {
            this.showEdit = false
        },

        onClickShowEntry: function() {
            this.showCheckRepeat = false
        },

        onClickShowCheckRepeat: function() {
            setTimeout(()=>{
                var self = this
                let errResult = verifyQuestionStem(self.TalOutputQuestion.body.stem, this.currentType)
                if (errResult.isError) {
                    if (+this.currentType === Question.WordStosen.type) {
                        self.$message({
                            type: 'error',
                            message: '请填写连词成句的词语',
                            duration: 2000
                        })
                    } else {
                        self.$message({
                            type: 'error',
                            message: '请填写题干',
                            duration: 2000
                        })
                    }
                }
                else {
                    let search_str = ''
                    search_str += `${this.TalOutputQuestion.body.stem.body}`
                    $.each(this.TalOutputQuestion.body.stem.options, (index, item)=>{
                        search_str += `${item}`
                    })
                    self.loading = true
                    self.$api['recording/searchQuestion']({
                        search_str: search_str,
                        level_id: this.currentGradeLevel,
                        subject_id: this.currentSubject,
                        type_id: this.currentType
                    }).then(data => {
                        console.log('获取相似题目成功: ', data)
                        self.loading = false
                        self.repeatQuestionArray = data
                        self.showCheckRepeat = true
                    }).catch(e => {
                        console.log('获取相似题目失败: ', e)
                        self.loading = false
                        self.showCheckRepeat = true
                    })
                }
            },0)

        },
        onClickGiveUp: function() {
            var self = this
            this.$modalMessage({
                offset: ['400px', '400px'],
                align: 'center',
                msg: ['放弃处理后将不保存现有录题进度!', '是否确认放弃?'],
                confirm: res => {
                    self.$modalMessageClose()
                    self.reload()
                }
            })
        },
        /* End action */

        /* emit  初始化数据*/
        onEmitInitQuestion: function(question) {
            this.TalInputQuestion = JSON.parse(JSON.stringify(question))
            this.TalOutputQuestion = JSON.parse(JSON.stringify(question))
        },
        determineRepeatQuestionEmit: function () {
            this.reload()
        },
        emitCopyQuestion: function(res) {
            // 设置为undefined, 让题型组件中的prop默认值完成初始化, 即全部清空
            // setTimeout是为了将题型一键复制功能放到队列的最后端，即初始化完成以后再渲染
            this.TalInputQuestion = undefined
            setTimeout( () => {
                this.TalInputQuestion = {}
                this.$set(this.TalInputQuestion, 'type', res.type)
                this.$set(this.TalInputQuestion, 'body', {
                    stem: res.stem,
                    answer: res.answer,
                    analysis: res.analysis
                })

                this.TalOutputQuestion = JSON.parse(JSON.stringify(this.TalInputQuestion))
                if (res.type === Question.Complex.type) {
                    // 这单独处理复合题的数据格式
                    this.$refs.questionType.refresh(this.TalInputQuestion)
                }
                this.$nextTick(() => {
                    // 重新渲染MathJax
                    MathJax.Hub.Queue(["Typeset",MathJax.Hub])
                    this.showCheckRepeat = false
                })
            }, 0)

        },
        sourceDataEmit: function (res) {
            this.sourceDataArray = res
        },
        /* End emit */

        /* private */
        // 设置wrapper高度
        setHeight: function () {
            let height = $('#main-content').height()
            this.wrapperHeight = `${height}px`
        },
        // 请求该用户可以录入题目的科目和年级
        requestCurrentUserInfo: function() {
            var self = this
            let obj = {
                uid: sessionStorage.getItem('uid')
            }
            this.$api['login/currentUserInfo']({
                uid: sessionStorage.getItem('uid')
            }).then(data => {
                if (data) {
                    // 认证未通过是 data是undefined
                    self.gradeLevelArray = data.auth_grade
                }
            })
        },
        // 获取正确下拉列表数据，将来可以优化放到一个公共的地方去
        getQuestionTypeArray: function() {
            var result = []
            for (var key in this.Question) {
                if (this.Question[key].type != this.Question.Unknown.type) {
                    result.push(this.Question[key])
                }
            }
            return result
        },

        verifySource: function (source) {
            let res = {
                isEmpty: true
            }
            $.each(source, (index, item) => {
                if (item.source_type_id && item.source_type_id !== '') res.isEmpty = false
            })
            return res
        },

        reset: function () {
            this.showQuestionComponent = false
            this.questionType = Question.SingleChoice.component
            this.sourceDataArray = []
            this.showCheckRepeat = false
            setTimeout(()=>{
                this.showQuestionComponent = true
            }, 0)
        }
        /* End private */
    },
    watch: {
        currentGradeLevel: function (newVal, oldVal) {
            console.log('directEntry watch currentGradeLevel', this.currentGradeLevel)
            this.$store.state.question.currentGradeLevel = this.currentGradeLevel
            if (this.currentGradeLevel === '') {
                this.subjectArray = []
            } else {
                let index = $("select[name='grade-level']").find('option:selected').data('index')
                this.subjectArray = this.gradeLevelArray[index].grade_set
            }
            this.currentSubject = ''
        },

        currentSubject: function (newVal, oldVal) {
            this.$store.state.question.currentSubject = this.currentSubject
            this.reset()
        },

        questionType: function(newVal, oldVal) {
            $.each(Question, (index, item) => {
                if (item.component == newVal) this.currentType = item.type
            })
            // 切换题型，设为undefined,则题型组件会使用props的默认值，完成题型组件的初始化
            this.TalInputQuestion = undefined
            // 销毁 解析组件中的bus事件
            this.$bus.$off('refreshAnalysis')
        }
    }
}
</script>

<style lang="scss" scoped>
@import '@/assets/css/recording/DirectEntry.scss';
</style>
