<template>
    <div id="system-wrapper">
        <div id="system-header-bar">
            <div class="logo-area">
                <img class="logo-background" src="@/assets/img/common/logo-bg.png">
                <img class="logo" src="@/assets/img/common/logo-text.png">
            </div>
            <div class="info-area">
                <div class="user">
                    <a class="btn-user" @click="onClickUser">
                        欢迎 {{username}}
                    </a>
                    <transition name="toggle">
                        <ul class="user-options" v-if="show_user_options">
                            <li class="user-option-item">
                                <button class="btn-user-option-item" @click="onClickLogout">退出登录</button>
                            </li>
                        </ul>
                    </transition>
                </div>
            </div>
        </div>
        <div class="system-wrapper">
            <div class="app-container">
                <router-link class="app-entry" :class="'school'+index" :to="item.path" v-for="(item, index) in appData" :key="index">{{item.name}}</router-link>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            appData: [
                {
                    name: '录题平台',
                    path: '/questionEntry'
                },
                {
                    name: '内容编排',
                    path: '/composeTemplate'
                },
                {
                    name: '标注体系',
                    path: '/questionEntry'
                },
                {
                    name: '检索页面',
                    path: '/retrieval'
                }
            ],

            show_user_options: false,
            do_not_close_user_options: false
        }
    },
    mounted() {
        var self = this
        $(document).on('click', () => {
            if (self.do_not_close_user_options)
                self.do_not_close_user_options = false
            else {
                self.show_user_options = false
            }
        })
    },
    methods: {
        onClickUser: function() {
            var self = this
            if (self.show_user_options) self.show_user_options = false
            else {
                self.show_user_options = true
                self.do_not_close_user_options = true
            }
        },

        onClickLogout: function() {
            var self = this
            sessionStorage.removeItem('username')
            sessionStorage.removeItem('uid')
            sessionStorage.removeItem('auth_token')
            self.$router.push({ name: 'Login' })
        }
    },
    computed: {
        username: function() {
            return sessionStorage.getItem('username')
        }
    }
}
</script>

<style lang="scss">
#system-wrapper {
    width: 100%;
    min-width: 1000px;
    height: auto;
    min-height: 100%;

    #system-header-bar {
        display: flex;
        width: 100%;
        height: 70px;
        background-image: linear-gradient(90deg, #5f7aff 0%, #6bc1fe 100%);

        .logo-area {
            width: 210px;
            height: 70px;
            position: relative;

            .logo-background {
                width: 210px;
                height: 70px;
            }

            .logo {
                position: absolute;
                top: 20px;
                left: 40px;
                width: 120px;
                height: 28px;
            }
        }

        .info-area {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding-right: 40px;
            width: calc(100% - 210px);

            .user {
                position: relative;

                .btn-user {
                    display: block;
                    padding-right: 15px;
                    color: #fff;
                    background: url(../../assets/img/common/arrow-down.png) right 60%
                        no-repeat;
                    transition: all 0.5s;
                }

                .user-options {
                    position: absolute;
                    right: 0;
                    width: 80px;
                    background: #fff;
                    box-shadow: 0 2px 5px 2px #e8edef;

                    .user-option-item {
                        width: 100%;
                        height: 30px;

                        .btn-user-option-item {
                            width: 100%;
                            height: 100%;
                            border: none;
                            cursor: pointer;
                        }

                        .btn-user-option-item:hover {
                            color: #6e86fd;
                        }
                    }
                }
            }
        }
    }

    .system-wrapper {
        display: flex;
        justify-content: center;
        align-items: flex-start;
        padding: 40px;
        width: 100%;
        height: auto;
        min-height: calc(100% - 70px);
        background: #edeff5;
        box-sizing: border-box;

        .app-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            width: 1200px;
            margin-top: 120px;
        }

        .app-entry {
            display: block;
            margin-bottom: 50px;
            width: 300px;
            height: 100px;
            line-height: 100px;
            text-align: center;
            color: #fff;
            border-radius: 15px;
            background-image: linear-gradient(90deg, #5f7aff 0%, #6bc1fe 100%);
            transition: all 0.5s;
        }
        .school0 {
            background: url('../../assets/img/common/questionEntry.png');
        }
        .school1 {
            background: url('../../assets/img/common/composeTemplate.png');
        }
        .school2 {
            background: url('../../assets/img/common/questionTag.png');
        }

        .app-entry:hover {
            box-shadow: 1px 1px 2px 4px #ccc;
        }

        .app-entry:nth-child(odd) {
            margin-right: 50px;
        }
    }
}
</style>


