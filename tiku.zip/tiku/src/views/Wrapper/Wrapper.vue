<template>
    <div id="wrapper-background">
        <div id="side-bar">
            <div class="logo-area">
                <div class="logo">
                    <img src="@/assets/img/common/logo-bg.png" alt="logo-bg" width="210" height="70">
                    <img src="@/assets/img/common/logo-text.png" alt="logo-text" width="117" height="28">
                </div>
            </div>
            <div class="nav-area">
                <div class="nav-item" v-for="(item, title) in side_bar_content">
                    <button class="nav-level1" :data-title="title" v-if="item.level2" @click="onClicSwitchkLevel1">
                        <img class="logo" :src="item.imgSrc">
                        <span>{{title}}</span>
                        <img class="arrow" :class="item.is_active ? 'active':''" v-if="item.level2" src="@/assets/img/common/v.png">
                    </button>
                    <router-link class="nav-level1" :to="item.path" v-else>
                        <img class="logo" :src="item.imgSrc">
                        <span>{{title}}</span>
                    </router-link>
                    <ul class="nav-container" v-if="item.is_active && item.level2">
                        <li v-for="nav in item.level2">
                            <router-link class="nav-level2" :to="nav.path">{{nav.name}}</router-link>
                        </li>
                    </ul>
                </div>
            </div>
        </div>


        <div id="wrapper">
            <div id="head-bar">
                <div class="user">
                    <a class="btn-user" @click="onClickUser">
                        <img src="@/assets/img/common/icon-account.png">
                        {{username}}
                    </a>
                    <transition name="toggle">
                        <ul class="user-options" v-if="show_user_options">
                            <li class="user-option-item"><button class="btn-user-option-item" @click="onClickLogout">退出登录</button></li>
                        </ul>
                    </transition>
                </div>
            </div>
            <div id="main-content">
                <router-view></router-view>
            </div>
        </div>
    </div>
</template>

<script>
// 导入图片，直接用v-bind绑定不能显示图片
import icon_question_entry from "@/assets/img/common/navbar-level1-icon-question-entry.png";
import icon_user_management from "@/assets/img/common/navbar-level1-icon-user-management.png";
import icon_label from "@/assets/img/common/navbar-level1-icon-label.png"
import icon_content_management from  "@/assets/img/common/navbar-level1-icon-content-management.png"

import { mapActions, mapState } from 'vuex'

export default {
    data() {
        return {
            side_bar_content: {
                题目录入: {
                    is_active: true,
                    imgSrc: icon_question_entry,
                    path: '/directEntry',
                    level2: [
                        {
                            name: "直接录入",
                            path: "/questionEntry/directEntry",
                            is_active: true
                        }
                    ]
                },
                用户管理: {
                    is_active: true,
                    imgSrc: icon_user_management,
                    path: '/auth/authManagement',
                    level2: [
                        {
                            name: "权限管理",
                            path: "/auth/authManagement",
                            is_active: true
                        }
                        // ,
                        // {
                        //     name: "个人中心",
                        //     path: "/center",
                        //     is_active: false
                        // }
                    ]
                },
                题目标注: {
                    is_active: false,
                    imgSrc: icon_label,
                    path: '/tag',
                },
                标签管理: {
                    is_active: true,
                    imgSrc: icon_content_management,
                    path: '/tagManagement/labelSystem',
                    level2: [
                        {
                            name: "基础标签库",
                            path: "/tagManagement/basicLabel",
                            is_active: false
                        },
                        {
                            name: "标签体系定制",
                            path: "/tagManagement/labelSystem",
                            is_active: true
                        }
                    ]
                }
            },

            do_not_close_user_options: false,
            show_user_options: false
        };
    },
    mounted () {
        var self = this
        $(document).on('click', ()=>{
            if (self.do_not_close_user_options) self.do_not_close_user_options = false
            else {
                self.show_user_options = false
            }
        })
    },
    methods: {
        onClicSwitchkLevel1: function(e) {
            var self = this
            let element = ''
            $.each($(e)[0].path, (index, ele)=>{
                if ($(ele)[0].className && $(ele)[0].className == 'nav-level1') {
                    element = ele
                    return false
                }
            })
            let title = $(element).data('title')
            self.side_bar_content[title].is_active = !self.side_bar_content[title].is_active
        },

        onClickUser: function () {
            var self = this
            if (self.show_user_options) self.show_user_options = false
            else {
                self.show_user_options = true
                self.do_not_close_user_options = true
            }
        },

        onClickLogout: function () {
            var self = this
            sessionStorage.removeItem('username')
            sessionStorage.removeItem('uid')
            sessionStorage.removeItem('auth_token')
            self.$router.push({ name: 'Login' })
        }
    },
    computed: {
        username: function () {
            return sessionStorage.getItem('username')
        }
    }
};
</script>

<style lang="scss">
@import "assets/css/recording/wrapper.scss";

@import "assets/css/recording/Common.scss";
</style>
