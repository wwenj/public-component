<template>
    <div class="layer-add-new-teacher-content">
        <div class="title">新增老师</div>
        <div class="input-area">
            <div class="input-item">
                <div class="input-line" :class=" name == '' && is_name_touched ? 'warning':''">
                    <img src="@/assets/img/common/icon-account.png">
                    <input class="" type="text" v-model="name" @blur="onBlurName" placeholder="请输入老师的姓名">
                </div>
                <div class="warning-area" v-if="name == '' && is_name_touched">
                    <img src="../../assets/img/common/icon-tips.png">
                    <span>{{name_tip}}</span>
                </div>
            </div>

            <div class="input-item">
                <div class="input-line" :class="phone_number == '' && is_phone_touched ? 'warning':''">
                    <img src="@/assets/img/common/icon-account.png">
                    <input class="" type="text" v-model="phone_number" @blur="onBlurPhone" placeholder="请输入老师的手机号">
                </div>
                <div class="warning-area" v-if="phone_number == '' && is_phone_touched">
                    <img src="../../assets/img/common/icon-tips.png">
                    <span>{{phone_tip}}</span>
                </div>
            </div>

        </div>
        <div class="operation-area">
            <button class="btn-cancel" @click="onClickCancel">取消</button>
            <button class="btn-confirm" @click="onCLickConfirm">确定</button>
        </div>
    </div>
</template>

<script>
import request from '@/common/request'
export default {
    data () {
        return {
            is_name_touched: false,
            is_phone_touched: false,

            name_tip: '真的不能为空',
            phone_tip: '不能为空',

            name: '',
            phone_number: ''
        }
    },
    created() {
        var self = this
        $('.vl-notice-title').hide()
        $('.vl-notify-content').css('padding', 0)
        let height = $('.vl-notify-iframe').height()
        $('.vl-notify-iframe').css('height', `${height - 43}px`).css('border-radius', '12px')
    },
    mounted() {
        var self = this

    },
    methods: {
        onBlurName: function () {
            var self = this
            self.is_name_touched = true
        },

        onBlurPhone: function () {
            var self = this
            self.is_phone_touched = true
        },

        onClickCancel: function () {
            var self = this
            self.$layer.closeAll()
        },

        onCLickConfirm: function () {
            var self = this
            if (self.name != '' && self.phone_number != '') {
                let obj = {
                    username: self.name,
                    phone_number: self.phone_number
                }
                let req = request.addUser(obj)
                req.then((res) => {
                    self.$layer.closeAll()
                    if (res.status != 400 ) {
                        self.$layer.msg(`${self.name}(${self.phone_number}新增用户成功)`)
                        let req_new = request.getUserList()
                        req_new.then((res)=>{
                            self.$parent.user_list = res.data.data.data
                            self.$forceUpdate()
                        })
                    }
                    else {
                        self.$layer.msg(res.message)
                    }
                })
                req.catch((err) => {
                    console.log("err: ", err)
                })
            }
            else {
                self.is_name_touched = true
                self.is_phone_touched = true
            }
        }
    }
}

</script>

<style lang="scss" scoped>
@import '@/assets/css/auth/AddTeacher.scss';
</style>


