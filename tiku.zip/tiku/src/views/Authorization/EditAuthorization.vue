<template>
    <div class="wrapper-edit-authorization">

        <div class="info-area">
            <div class="info-item">
                <label for="">姓名 : </label>
                <span>{{user_info.username}}</span>
            </div>
            <div class="info-item">
                <label for="">手机号 : </label>
                <span>{{user_info.phone_number}}</span>
            </div>
        </div>

        <div class="authorization-control-area">
            <span>用户管理权限</span>
            <button class="btn-enableAuth" v-if="user_info.is_active" @click="onClickDisableAuth">权限开启</button>
            <button class="btn-disableAuth" v-if="!user_info.is_active" @click="onClickEnableAuth">权限关闭</button>
        </div>

        <div class="authorization-management-content">
            <div class="title">
                <span>录题权限</span>
            </div>
            <div class="authorization-container" :id="gradeItem.id" v-for="(gradeItem, grade) in original_permission">
                <div class="label">{{gradeItem.name}}</div>
                <div>
                    <button class="auth-item" :class="[user_permission_set[gradeItem.name].select_all ? 'active':'']" :data-grade="gradeItem.name" @click="onClickSelectAll">全部</button>
                    <button class="auth-item" :class="[user_permission_set[gradeItem.name].list[auth.id] ? 'active':'' ]" :data-grade="gradeItem.name" :data-id="auth.id" v-for="(auth, index) in gradeItem.permission_set" @click="onClickAuthItem">{{auth.name}}</button>
                </div>
            </div>
        </div>

        <button class="btn-submit-authorization" @click="onClickSubmit">保存</button>

    </div>
</template>

<script>
import request from '@/common/request'
export default {
    data () {
        return {
            id: '',  // 用户id 获取用户详情 & 提交权限修改 的依据
            user_info: {},  // 用户个人详情
            original_permission: [],  // 完整权限树
            user_permission_set: {}, // 用户权限暂存对象， 依据user_info中的permission_set创建 array->obj
            permission: {} 
        }
    },
    mounted() {
        var self = this
        self.id = self.$route.params.id

        let permission = request.getPermissionByTree()
        permission.then((res) => {
            self.original_permission = res.data.data[0].permission_set
            $.each(self.original_permission, (key, value) => {
                self.permission[value.name] = []
                self.user_permission_set[value.name] = {
                    select_all: false,
                    list: {}
                }
                $.each(value.permission_set, (i, a) => {
                    self.permission[value.name].push(a.id)
                })
            })

            let obj = { id: self.id }

            let user_detail = request.getUserDetail(obj)
            user_detail.then((res)=>{
                self.user_info = res.data.data
                $.each(self.user_info.permission_set, (index, item)=>{
                    $.each(self.permission, (grade, auth_list) => {
                        if (auth_list.indexOf(item) != -1) self.user_permission_set[grade].list[item] = true
                    })
                })
            })
        })
    },
    methods: {
        onClickEnableAuth: function () {
            var self = this
            self.user_info.is_active = true
            self.$forceUpdate()
        },

        onClickDisableAuth: function () {
            var self = this
            self.user_info.is_active = false
        },

        onClickSelectAll: function (e) {
            var self = this
            let grade = $(e.target).data('grade')
            if (self.user_permission_set[grade].select_all) self.user_permission_set[grade].select_all = false
            else {
                self.user_permission_set[grade].select_all = true
                self.user_permission_set[grade].list = {}
            }
            self.$forceUpdate()
        },

        onClickAuthItem: function (e) {
            var self = this
            let grade = $(e.target).data('grade')
            let auth_id = $(e.target).data('id')
            if (self.user_permission_set[grade].list[auth_id]) delete self.user_permission_set[grade].list[auth_id]
            else self.user_permission_set[grade].list[auth_id] = true

            let count = 0
            $.each(self.user_permission_set[grade].list, (index, auth) => {
                count++
            })
            if (self.permission[grade].length == count) {
                self.user_permission_set[grade].select_all = true
                self.user_permission_set[grade].list = {}
            }
            else {
                self.user_permission_set[grade].select_all = false
            }
            self.$forceUpdate()
            
        },

        onClickSubmit: function () {
            var self = this
            let permission_set = []
            $.each(self.user_permission_set, (grade, set) => {
                if (set.select_all) {
                    $.each(self.permission[grade], (i, auth) => {
                        permission_set.push(auth.toString())
                    })
                }
                else {
                    $.each(set.list, (i, auth) => {
                        permission_set.push(i)
                    })
                }
            })
            
            let obj = {
                id: self.id,
                is_active: self.user_info.is_active,
                permission_set: permission_set
            }
            let req = request.editUser(obj)
            req.then((res) => {
                self.$layer.msg('权限编辑成功')
            })
            req.catch((err) => {
                self.$layer.msg('权限编辑失败')
            })
        }
    }
}
</script>

<style lang="scss" scoped>
@import '@/assets/css/auth/EditAuthorization.scss';
</style>


