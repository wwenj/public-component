<template>
    <div class="layer-confirm-authorization-content">

        <div class="logo-area"></div>

        <div class="info-area">您是否要禁用{{info.username}}({{info.phone_number}})的账号</div>

        <div class="operation-area">
            <button class="btn-cancel" @click="onClickCancel">取消</button>
            <button class="btn-confirm" @click="onClickConfirm">确定</button>
        </div>

    </div>
</template>

<script>
import request from '@/common/request'
export default {
    data () {
        return {
            id: '',
            index: '',
            info: {}
        }
    },
    created() {
        var self = this
        $('.vl-notice-title').hide()
        $('.vl-notify-content').css('padding', 0)
        let height = $('.vl-notify-iframe').height()
        $('.vl-notify-iframe').css('height', `${height - 43}px`).css('border-radius', '12px')
    },
    mounted() {
         var self = this
         self.index = self.$parent.operating_index
         self.id = self.$parent.user_list[self.index].id
         self.info = self.$parent.user_list[self.index]
    },
    methods: {
        onClickCancel: function () {
            var self = this
            self.$layer.closeAll()
        },

        onClickConfirm: function () {
            var self = this
            let obj = {
                id: self.id,
                is_active: false
            }
            let req = request.editUser(obj)
            req.then((res) => {
                self.$parent.user_list[self.index].is_active = false
                self.$layer.closeAll()
                self.$layer.msg(`${self.info.username}(${self.info.phone_number})已被禁用`)
            })
            req.catch((err) => {
                console.log("err: ", err)
                self.$layer.closeAll()
            })
            
        }
    }
}
</script>

<style lang="scss" scoped>
@import '@/assets/css/auth/ConfirmAuth.scss';
</style>


