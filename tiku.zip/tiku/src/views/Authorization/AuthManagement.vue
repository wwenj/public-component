<template>
    <div class="wrapper-auth-management">
        <div class="search-line">
            <input class="search" type="text" v-model="search_info" placeholder="请输入姓名或账号">
            <button class="btn-add-teacher" @click="onClickSearch">搜索</button>
            <button class="btn-add-teacher" @click="onClickAddTeacher">新增老师</button>
        </div>
        <div class="user-list-content">
            <div class="user-list-container">
                <div class="empty" v-if="user_list.length == 0">
                    <img src="../../assets/img/common/empty.png">
                    <span>暂无结果，请重新搜索</span>
                </div>
                <table class="user-list" v-if="user_list.length != 0">
                    <thead>
                        <tr>
                            <td>姓名</td>
                            <td>手机号</td>
                            <td>权限编辑</td>
                            <td>是否禁用</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in user_list">
                            <td>{{item.username}}</td>
                            <td>{{item.phone_number}}</td>
                            <td> <router-link :id="item.id" class="edit" :to="{ name: 'UserAuthorization', params: { id: item.id } }">编辑</router-link></td>
                            <td>
                                <button class="btn-disabled" v-if="item.is_active" :data-index="index" @click="onClickDisableAuth">禁用</button>
                                <button class="btn-enabled" v-if="!item.is_active" :data-index="index" @click="onClickEnableAuth">已禁用</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="pagination-container"></div>
        </div>
    </div>
</template>

<script>
import request from '@/common/request'
import add from '@/views/Authorization/AddTeacher.vue'
import confirm from '@/views/Authorization/ConfirmAuth.vue'
export default {
    data(){
        return {
            search_info: '',
            user_list: [],

            operating_index: '',
        }
    },
    mounted() {
        var self = this
        let user_list = request.getUserList()
        user_list.then((res)=>{
            self.user_list = res.data.data.data
        })
    },
    methods: {
        onClickSearch: function() {
            var self = this
            let obj = {
                search: self.search_info
            }
            let req = request.getUserList(obj)
            req.then((res)=>{
                self.user_list = res.data.data.data
                console.log(self.user_list)
            })
        },

        onClickAddTeacher: function(){
            var self = this
            this.$layer.iframe({
                content: {
                    content: add,
                    parent: this,
                    data: {
                        "what": "lewis"
                    }
                },
                area: ['400px', '460px'],
                title: '',
                shade: true,
                type: 3
            })
        },

        onClickEnableAuth: function (e) {
            var self = this
            let index = $(e.target).data('index')
            self.user_list[index].is_active = true

            let obj = {
                id: self.user_list[index].id,
                is_active: self.user_list[index].is_active
            }
            let req = request.editUser(obj)
            req.then((res) => {
                self.$layer.msg(`${self.user_list[index].username} (${self.user_list[index].phone_number}) 成功启用`)
            })
            req.catch((err) => {
                console.log("err: ", err)
                self.$layer.msg(`${self.user_list[index].username} (${self.user_list[index].phone_number}) 启用失败`)
            })

            self.$forceUpdate()
        },

        onClickDisableAuth: function (e) {
            var self = this
            let index = $(e.target).data('index')
            self.operating_index = index
            self.$layer.iframe({
                content: {
                    content: confirm,
                    parent: this,
                    data: { name: 'lewis' }
                },
                area: ['400px', '320px'],
                title: '',
                shade: true,
                type: 3
            })
        }
    }
}
</script>

<style lang="scss" scoped>
@import '@/assets/css/auth/AuthManagement.scss';
</style>


