<template>
    <div class="wrapper-user-authorization">
        <div class="info-area">
            <div class="info-item info-name">
                <label for="">姓名</label>
                <span>{{user_info.username}}</span>
            </div>
            <div class="info-item info-phone-number">
                <label for="">手机号码</label>
                <span>{{user_info.phone_number}}</span>
            </div>
            <button class="btn-edit-authorization" @click="onClickEditAuth">编辑权限</button>
        </div>
        <div class="search-line">
            <select name="process">
                <option value="">请选择流程</option>
            </select>
            <select name="grade">
                <option value="">请选择年部</option>
            </select>
            <select name="course">
                <option value="">请选择科目</option>
            </select>
        </div>
        <div class="authorization-content">
            <div class="authorization-container">
                <div class="empty" v-if="user_info.permission_set.length == 0">
                    <img src="../../assets/img/common/empty.png">
                    <span>暂无结果，请重新搜索</span>
                </div>
                <table class="authorization" v-if="user_info.permission_set.length != 0">
                    <thead>
                        <tr>
                            <td>流程</td>
                            <td>年部</td>
                            <td>科目</td>
                            <td>编辑权限</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in user_info.permission_set">
                            <td>{{permission[item].root_name}}</td>
                            <td>{{permission[item].level.name}}</td>
                            <td>{{permission[item].subject.name}}</td>
                            <td><button class="btn-delete">删除</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="pagination-container"></div>
        </div>
    </div>
</template>

<script>
import request from '@/common/request'
export default {
    data () {
        return {
            id: '',
            user_info: {
                permission_set: []
            },

            permission: {
                "1": "1"
            }
        }
    },
    mounted() {
        var self = this
        self.id = self.$route.params.id
        let obj = {
            id: self.id
        }
        let req = request.getPermissionByList()
        req.then((res) => {
            $.each(res.data.data, (i, p) => {
                self.permission[p.id] = p
            })
            console.log(self.permission)
            let r = request.getUserDetail(obj)
            r.then((res) => {
                self.user_info = res.data.data
                console.log(self.user_info)
            })
        })
        req.catch((err) => {
            console.log(err)
        })
    },
    methods: {
        onClickEditAuth: function() {
            var self = this
            self.$router.push({ name: 'EditAuthorization', params: { id: self.id } })
        }
    }
}
</script>

<style lang="scss" scoped>
@import '@/assets/css/auth/UserAuthorization.scss';
</style>


