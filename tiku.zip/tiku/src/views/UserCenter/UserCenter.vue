<template>
    <div class="wrapper">
        <div class="top">
            <div class="top-text">
                <span>待处理试题总数：{{allErrorNum}}</span>
                <span>录题错误总数：{{recordErrorNum}}</span>
                <span>标签错误总数：{{tagErrorNum}}</span>
            </div>
            <div class="top-select">

            </div>
        </div>
    </div>
</template>

<script>

export default {
    components: {
    },
    data () {
        return {
            allErrorNum: 0,
            recordErrorNum: 0,
            tagErrorNum: 0
        }
    },
    methods: {
    }
}
</script>

<style lang="scss" scoped>
</style>
