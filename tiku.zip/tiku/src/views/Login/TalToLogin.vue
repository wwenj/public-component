<template>
    <div>
        <div class="input-area">
            <div class="input-line">
                <img src="@/assets/img/common/icon-account.png">
                <input type="text" class="input" maxlength="16" v-model="username" placeholder="请输入手机号码" @focus="inputFocus('username')" @keyup.enter="onClickLogin">
            </div>
            <TalErrorInput ref="userNameError"></TalErrorInput>
            <div class="input-line">
                <img src="@/assets/img/login/icon-verificationCode.png">
                <input type="password" class="input" maxlength="16" v-model="password" placeholder="请输入密码" @focus="inputFocus('password')" @keyup.enter="onClickLogin">
            </div>
            <TalErrorInput :inputErrorText="inputErrorText" ref="passWordError"></TalErrorInput>
            <div class="operation-line">
                <label>
                    <input type="checkbox" v-model="isKeepPassword"> 记住账号密码
                </label>
                <a @click="forgetPasswordOnClick">忘记密码?</a>
            </div>
        </div>
        <div class="login-area">
            <button class="btn-login" @click="onClickLogin">登录</button>
        </div>
    </div>
</template>

<script>
export default {
    data () {
        return {
            username: localStorage.getItem('rememberPhoneNumber'),
            password: localStorage.getItem('rememberPassword'),
            // 是否记住账号
            isKeepPassword: false,
            inputErrorText: '不能为空' // 更新底部报错信息
        }
    },
    mounted () {
        if (this.username) {
            this.isKeepPassword = true
        }
    },
    methods: {
        /* action */
        // 点击登录事件
        onClickLogin: function () {
            let tmpUser = this.inputBlur(this.username, 'username')
            let tmpPass = this.inputBlur(this.password, 'password')
            let that = this
            if (tmpUser && tmpPass) {
                this.$api['login/login']({
                    username: this.username,
                    password: this.password
                }).then((res) => {
                    // sessionStorage 关闭页面或浏览器后则被清除
                    sessionStorage.setItem('auth_token', res.remember_token)
                    sessionStorage.setItem('uid', res.user.uid)
                    sessionStorage.setItem('username', res.user.username)
                    if (that.isKeepPassword) {
                        // localStorage 只有手动删除才会被清除，否则永远保存在浏览器中
                        localStorage.setItem('rememberPhoneNumber', that.username)
                        localStorage.setItem('rememberPassword', that.password)
                    } else {
                        localStorage.clear()
                    }
                    that.$router.push({
                        path: '/school'
                    })
                }).catch((e) => {
                    // that.inputErrorText = '账号或密码错误'
                    that.inputErrorText = e.message
                    that.$refs.passWordError.errorInputShow()
                })
            }
        },
        // 忘记密码事件
        forgetPasswordOnClick: function () {
            this.$emit('forgetPasswordEmit', 'TalForgetLogin')
        },
        // 文本框失焦对其做检查
        inputBlur: function (num, index) {
            if (!num) {
                if (index === 'username') {
                    this.$refs.userNameError.errorInputShow()
                } else {
                    this.$refs.passWordError.errorInputShow()
                    self.inputErrorText = '不能为空'
                }
                return false
            } else {
                return true
            }
        },
        // 文本框聚焦
        inputFocus: function (index) {
            if (index === 'username') {
                this.$refs.userNameError.errorInputHidd()
            } else {
                this.$refs.passWordError.errorInputHidd()
            }
        },
        /* private */
        verifyPhoneNumber: function (phoneNumber) {
            let verifyStr = /^[1][3,4,5,7,8][0-9]{9}$/
            if (!verifyStr.test(phoneNumber)) {
                console.log('号码正则匹配错误')
                this.$refs.passWordError.errorInputShow()
                this.inputErrorText = '手机号格式不正确'
                return false
            }

            return true
        }
    }
}
</script>


<style lang="scss" scoped>
@import '@/assets/css/Login.scss';
.error-icon {
    img {
        vertical-align: middle;
    }
    span {
        vertical-align: middle;
    }
    font-size: 12px;
    color: #ff0000;
}
</style>

