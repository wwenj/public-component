<template>
    <p class="error-icon" v-if="isShow">
        <img src="@/assets/img/common/icon-tips.png" alt="">
        <span>{{ inputErrorText }}</span>
    </p>
</template>
<script>
export default {
    props: {
        inputErrorText: {
            type: String,
            default: '不能为空'
        }
    },
    data () {
        return {
            isShow: false
        }
    },
    methods: {
        errorInputShow: function () {
            this.isShow = true
        },
        errorInputHidd: function () {
            this.isShow = false
        }
    }
}
</script>
<style lang="scss" scoped>
.error-icon {
    img {
        vertical-align: middle;
    }
    span {
        vertical-align: middle;
    }
    font-size: 12px;
    color: #ff0000;
    border-top: 1px solid #ff0000;
    margin-top: -1px;
}
</style>


