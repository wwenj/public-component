<template>
    <div class="loginSuccess">
        <button class="toLogin" @click="toLogin">返回首页</button>
    </div>
</template>
<script>
export default {
    methods: {
        toLogin: function () {
            this.$emit('forgetPasswordEmit', 'TalToLogin')
        }
    }
}
</script>
<style lang="scss" scoped>
.loginSuccess {
    position: absolute;
    top: 5;
    left: 0;
    width: 350px;
    height: 470px;
    background:#fff url('../../assets/img/login/setPasswordSuccess.png') no-repeat;
    background-size: 350px 470px;
    border-radius: 15px;
    z-index: 10000;
}
.toLogin {
    width: 200px;
    height: 40px;
    background-image: linear-gradient(90deg, #5f7aff 0%, #6bc1fe 100%);
    box-shadow: 0px 9px 15px 0px rgba(95, 122, 255, 0.25);
    border-radius: 20px;
    color: #fff;
    margin-top: 50px;
    outline: none;
    position: absolute;
    top: 290px;
    left: 74px;
    cursor: pointer;
}
</style>

