<template>
    <div>
        <div class="input-area">
            <div class="input-line">
                <img src="@/assets/img/common/icon-account.png">
                <input type="password" class="input" maxlength="16" placeholder="输入新密码" v-model="password1" @focus="inputFocus('username')" @input="inputOnClick(password1)">
            </div>
            <TalErrorInput ref="userNameError"></TalErrorInput>
            <div class="input-line">
                <img src="@/assets/img/login/icon-verificationCode.png">
                <input type="password" class="input" maxlength="16" v-model="password2" placeholder="再次输入确认新密码" @focus="inputFocus('password')" @input="inputOnClick(password2)">
            </div>
            <TalErrorInput ref="passWordError" :inputErrorText="inputErrorText"></TalErrorInput>
        </div>
        <div class="bottom">
            <button class="bottomBtn" @click="getPasswordOnClick">确定</button>
            <button class="bottomBtn bottomBtnRignt" @click="cancelOnClick">取消</button>
        </div>
    </div>
</template>
<script>
export default {
    data () {
        return {
            password1: '',
            password2: '',
            inputErrorText: '不能为空' // 更新底部报错信息
        }
    },
    methods: {
        /* action */
        // 点击取消
        cancelOnClick: function () {
            this.$emit('forgetPasswordEmit', 'TalToLogin')
            // 用户中途点击取消，清除storage中的mobile
            sessionStorage.removeItem('mobile')
        },
        // 点击确定
        getPasswordOnClick: function () {
            // 不能为空，两次密码不一致，字符小于16
            let tmpPass1 = this.inputBlur(this.password1, 'username')
            let tmpPass2 = this.inputBlur(this.password2, 'username1')

            if (tmpPass1 && tmpPass2) {
                let temWord1 = this.inputOnClick(this.password1)
                let temWord2 = this.inputOnClick(this.password2)
                if (temWord1 && temWord2) {
                    this.$api['login/changePassword']({
                        mobile: sessionStorage.getItem('mobile'),
                        check_pwd: this.password1,
                        n_pwd: this.password2
                    }).then(res => {
                        this.$emit('forgetPasswordEmit', 'TalSetSuccess')
                        // 设置成功以后，删除storae中的mobile
                        sessionStorage.removeItem('mobile')
                    }).catch(e => {
                        this.inputErrorText = '不能与近期设置密码相同'
                        this.$refs.passWordError.errorInputShow()
                    })
                }
            }
        },
        /* private */
        // 文本框失焦对其做检查
        inputBlur: function (num, index) {
            if (!num) {
                if (index === 'username') {
                    this.$refs.userNameError.errorInputShow()
                } else {
                    this.$refs.passWordError.errorInputShow()
                    this.inputErrorText = '不能为空'
                }
                return false
            } else {
                if (this.password1 !== this.password2) {
                    console.log('两次密码输入不一致')
                    this.inputErrorText = '两次密码输入不一致'
                    this.$refs.passWordError.errorInputShow()
                    return false
                }
                return true
            }
        },
        // 文本框聚焦
        inputFocus: function (index) {
            if (index === 'username') {
                this.$refs.userNameError.errorInputHidd()
            } else {
                this.$refs.passWordError.errorInputHidd()
            }
        },
        // 忘记密码文本框变化计算字符数量够不够
        inputOnClick: function (password) {
            let passwordLength = password.length
            if (passwordLength < 6 || passwordLength > 16) {
                this.inputErrorText = '密码长度为6-16个字符'
                this.$refs.passWordError.errorInputShow()
                return false
            } else {
                this.$refs.passWordError.errorInputHidd()
                return true
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import '@/assets/css/Login.scss';
.bottomBtn {
    width: 120px;
    height: 40px;
    background-color: #ffffff;
    box-shadow: 0px 9px 15px 0px rgba(139, 159, 255, 0.25);
    border: 1px solid #5f7aff;
    border-radius: 20px;
    cursor: pointer;
    outline: none;
    font-size: 18px;
    color: #6e86fd;
    margin-top: 40px;
}
.bottomBtnRignt {
    background-image: linear-gradient(90deg, #5f7aff 0%, #6bc1fe 100%);
    box-shadow: 0px 9px 15px 0px rgba(95, 122, 255, 0.25);
    border-radius: 20px;
    color: #ffffff;
}
</style>

