<template>
    <div class="login-wrapper">
        <div class="box-container">
            <div class="login-background"></div>
            <div class="login-content-right">
                <img src="@/assets/img/login/blue-title-icon.png" class="title">
                <component @forgetPasswordEmit="forgetPasswordEmit" :is="componentsName"></component>
            </div>
        </div>
    </div>
</template>

<script>
import TalForgetLogin from '@/views/Login/TalForgetLogin'
import TalSetPassword from '@/views/Login/TalSetPassword'
import TalToLogin from '@/views/Login/TalToLogin'
import TalSetSuccess from '@/views/Login/TalSetSuccess'

export default {
    components: {
        TalForgetLogin,
        TalSetPassword,
        TalToLogin,
        TalSetSuccess
    },
    data () {
        return {
            componentsName: TalToLogin // 当前显示的动态组件
        }
    },
    methods: {
        /* emit */
        forgetPasswordEmit: function (name) {
            this.componentNameChange(name)
        },
        /* private */
        componentNameChange: function (name) {
            this.componentsName = name
        }
    }
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/Login.scss";
</style>


