<template>
    <div>
        <div class="input-area">
            <div class="input-line">
                <img src="@/assets/img/common/icon-account.png">
                <input type="text" class="input" maxlength="15" placeholder="请输入手机号码" v-model="username" @focus="inputFocus('username')">
            </div>
            <TalErrorInput ref="userNameError" :inputErrorText="inputErrorTextUser"></TalErrorInput>
            <div class="input-line">
                <img src="@/assets/img/login/icon-verificationCode.png">
                <input type="text" class="input" maxlength="6" v-model="code" placeholder="验证码" @focus="inputFocus('password')">
                <button v-if="sendButton" class="toSend" @click="toSendOnClick">点击发送验证码</button>
                <button v-else class="toSend">发送成功</button>
            </div>
            <TalErrorInput ref="passWordError" :inputErrorText="inputErrorText"></TalErrorInput>
            <p v-if="sendTextShow" class="sendText">验证码已经发送，您可以
                <span>{{ sendTime }}</span>s后重新获取验证码</p>
        </div>
        <div class="bottom">
            <button class="bottomBtn" @click="SendCodeOnClick">确定</button>
            <button class="bottomBtn bottomBtnRignt" @click="cancelOnClick">取消</button>
        </div>
    </div>
</template>

<script>

import { NetworkCode } from '@/common/constant'

export default {
    data () {
        return {
            username: '',
            code: '',
            sendTime: 60,
            sendButton: true, // 验证码是否可发送
            inputErrorText: '不能为空', // 更新底部报错信息
            inputErrorTextUser: '不能为空000', //
            sendTextShow: false // 发送验证码后显示
        }
    },
    methods: {
        /* action */
        // 点击取消
        cancelOnClick: function () {
            this.$emit('forgetPasswordEmit', 'TalToLogin')
        },
        // 点击发送验证码
        toSendOnClick: function () {
            let tmpUser = this.inputBlur(this.username, 'username')
            if (tmpUser) {
                this.$api['login/sendVerificationCode']({
                    mobile: this.username
                }).then((res) => {
                    this.countDown()
                }).catch((e) => {
                    this.inputErrorTextUser = '该手机号未注册，请确定后重新输入'
                    this.$refs.userNameError.errorInputShow()
                })
            }
        },
        // 点击确认验证验证码
        SendCodeOnClick: function () {
            let tmpUser = this.inputBlur(this.username, 'username')
            let tmpCode = this.inputBlur(this.code, 'password')
            if (tmpUser && tmpCode) {
                // 临时存储到storage中，设置新密码用
                sessionStorage.setItem('mobile', this.username)
                this.$api['login/checkVerificationCode']({
                    mobile: this.username,
                    code: this.code
                }).then(res => {
                    this.$emit('forgetPasswordEmit', 'TalSetPassword')
                }).catch(e => {
                    if (e.code === NetworkCode.noNumberError) {
                        this.$refs.passWordError.errorInputShow()
                        this.inputErrorText = '验证码必须6位'
                    } else {
                        this.$refs.passWordError.errorInputShow()
                        this.inputErrorText = '验证码输入有误，请重新输入'
                    }
                })
            }
        },
        // 文本框失焦对其做检查
        inputBlur: function (num, index) {
            if (!num) {
                if (index === 'username') {
                    this.inputErrorTextUser = '不能为空'
                    this.$refs.userNameError.errorInputShow()
                } else {
                    this.$refs.passWordError.errorInputShow()
                    this.inputErrorText = '不能为空'
                }
                return false
            } else {
                if (this.verifyPhoneNumber()) {
                    return false
                }
                return true
            }
        },
        // 文本框聚焦
        inputFocus: function (index) {
            if (index === 'username') {
                this.$refs.userNameError.errorInputHidd()
            } else {
                this.$refs.passWordError.errorInputHidd()
            }
        },
        /* private */
        // 计算剩余几秒可再次发送验证码
        countDown () {
            this.sendTextShow = true
            this.sendButton = false
            var clock = setInterval(() => {
                this.sendTime--
                if (this.sendTime === 0) {
                    this.sendButton = true
                    this.sendTextShow = false
                    this.sendTime = 60
                    clearInterval(clock)
                }
            }, 1000)
        },
        // 对文本框内容做筛选
        verifyPhoneNumber: function () {
            if (this.username) {
                let verifyStr = /^[1][3,4,5,7,8][0-9]{9}$/
                if (!verifyStr.test(this.username)) {
                    this.$refs.userNameError.errorInputShow()
                    this.inputErrorTextUser = '手机号格式不正确'
                    return true
                }
                return false
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import '@/assets/css/Login.scss';
.input-line {
    position: relative;
}
.input-area {
    .toSend {
        width: 100px;
        height: 24px;
        background-image: linear-gradient(90deg, #5f7aff 1%, #6bcafe 100%);
        border-radius: 3px;
        font-size: 12px;
        letter-spacing: 0px;
        color: #ffffff;
        outline: none;
        border: none;
        cursor: pointer;
        position: absolute;
        top: 0;
        right: 0;
    }
    .sendText {
        font-size: 12px;
        color: #bab9cb;
        margin-top: 10px;
    }
    span {
        margin-left: -3px;
        color: #5f7aff;
    }
}
.bottomBtn {
    width: 120px;
    height: 40px;
    background-color: #ffffff;
    box-shadow: 0px 9px 15px 0px rgba(139, 159, 255, 0.25);
    border: 1px solid #5f7aff;
    border-radius: 20px;
    cursor: pointer;
    outline: none;
    font-size: 18px;
    color: #6e86fd;
    margin-top: 40px;
}
.bottomBtnRignt {
    background-image: linear-gradient(90deg, #5f7aff 0%, #6bc1fe 100%);
    box-shadow: 0px 9px 15px 0px rgba(95, 122, 255, 0.25);
    border-radius: 20px;
    color: #ffffff;
}
</style>


