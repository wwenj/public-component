<template>
    <div class="wrapper-base-label">
        <div class="base-label-content">
            <label>【{{name}}】</label>
            <div class="tag-container" v-if="tagArray.length != 0">
                <ul>
                    <li class="tag-item" v-for="(item, index) in tagArray" :key="item.id">
                        <label :class="item.primary == 1 ? 'active' : ''"><input type="checkbox" name="primary" :checked="item.primary" :data-index="index" @click="onClickPrimary">[主标签]</label>
                        <span>{{item.word_path}}</span>
                        <button class="btn btn-delete-tag" :data-id="item.id" :data-index="index" @click="onClickDeleteTag"></button>
                    </li>
                </ul>
            </div>
        </div>
        <button class="btn btn-fetch-tag-tree" @click="onClickFetchTagTree"></button>
    </div>
</template>

<script>
export default {
    props: {
        name: {
            type: String,
            default: ''
        },
        qid: {
            type: String,
            default: ''
        },
        subjectId: {
            type: Number,
            default: 0
        },
        inputTags: {
            type: Array,
            default: () => {
                return []
            }
        }
    },
    data () {
        return {
            tagArray: [],
            primary: ''
        }
    },
    methods: {
        /* action */
        // 点击'获取当前base标签的标签树'事件 唤出标签树弹窗
        onClickFetchTagTree: function () {
            var self = this
            this.$api['questionTag/tagGetTree']({
                dimension: this.name,
                qid: this.qid,
                subject_id: this.subjectId
            }).then(data => {
                self.$TagTree({
                    title: self.name,
                    selectedTags: self.tagArray,
                    tagTree: data.tag_tree,
                    confirm: (res) => {
                        // console.log('res', res)
                        self.tagArray = self.reduceArray(res.concat(self.tagArray))
                        self.$TagTreeClose()
                    }
                })
            })
        },

        // 点击'删除标签'事件
        onClickDeleteTag: function (e) {
            let index = e.target.dataset['index']
            this.tagArray.splice(index, 1)
            this.$message({
                type: 'success',
                message: '删除标签成功'
            })
        },

        // 点击'主标签'checkbox事件 设置/取消主标签
        onClickPrimary: function (e) {
            let index = e.target.dataset['index']
            this.tagArray[index].primary === 1 ? this.$set(this.tagArray[index], 'primary', 0) : this.$set(this.tagArray[index], 'primary', 1)
        },
        /* End action */

        /* private */
        // 对象数组去重方法
        reduceArray: function (array) {
            // let reduceObj = {}
            // $.each(array, (index, item) => {
            //     reduceObj[item.id] = item
            // })
            // let res = []
            // $.each(reduceObj, (key, item) => {
            //     res.push(item)
            // })
            let hash = {}
            let res = array.reduce((p, v) => (hash[v.id] ? '' : hash[v.id] = true && p.push(v), p), [])
            return res
        }
        /* End private */
    },
    watch: {
        tagArray: {
            handler: function (newVal, oldVal) {
                this.$emit('emitTags', {
                    base: this.name,
                    tags: newVal
                })
            },
            deep: true
        },

        inputTags: {
            handler: function (newVal, oldVal) {
                this.tagArray = newVal
            },
            deep: true
        }
    }
}
</script>

<style lang="scss" scoped>
.wrapper-base-label {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 10px;
    padding: 20px;
    background: #fff;
    border: 1px solid rgba(160, 171, 188, 0.22);
    border-radius: 4px;
    box-sizing: border-box;

    .base-label-content {
        width: calc( 100% - 40px );
        label {
            font-family: 'MicrosoftYaHei';
            font-size: 14px;
            color: #2f2f2f;
            letter-spacing: 1px;
        }

        .tag-container {
            margin-top: 30px;
            padding-left: 10px;

            .tag-item {
                line-height: 25px;
                font-size: 14px;
                font-family: MicrosoftYaHei;

                label {
                    margin-right: 15px;
                    color: #b3baca;
                }

                label.active {
                    color: #6e86fd;
                }

                input[type="checkbox"] {
                    margin-right: 10px;
                }

                span {
                    color: #2f2f2f;
                }

                button.btn-delete-tag {
                    vertical-align: middle;
                    margin-left: 5px;
                    width: 14px;
                    height: 14px;
                    background: url('~@/assets/img/recording/del.png') no-repeat center;
                    background-size: contain;
                }
            }

            .tag-item:not(:first-child) {
                margin-top: 25px;
            }
        }
    }

    button.btn-fetch-tag-tree {
        width: 20px;
        height: 20px;
        border: none;
        border-radius: 50%;
        background: url('~@/assets/img/common/icon-add-label.png') center center no-repeat;
        cursor: pointer;
    }
}
</style>


