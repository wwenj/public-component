<template>
    <div class='wrapper-tag'>
        <div class="question-transition-area">
            <!-- <button class="btn-question-prev" @click="onClickPrevQuestion">上一题</button> -->
            <button class="btn-question-prev" @click="onClickLeave()">离开</button>
            <button class="btn-question-next" @click="onClickNextQuestion">下一题</button>
        </div>
        <tag-source :source="source"></tag-source>

        <div class="question-label-area">
            <div class="head-title">
                <span>标注</span>
                <button class="submit" @click="onClickSubmit">提交</button>
            </div>
            <div class="main">
                <div class="wrapper-preview" style="overflow-x: scroll">
                    <tal-preview-item
                    :inputQuestion="question"
                    :needTags="true"
                    :inputTags="TagData">
                    </tal-preview-item>
                </div>
                <div class="wrapper-label">
                    <div class="tab-line">
                        <button class="tab-item active">试题标注</button>
                    </div>
                    <div class="section">
                        <div class="title">卷面类型</div>
                        <div class="content">
                            <select class="paper-type-selector" v-model="paperType">
                                <option value="0" v-if="paperTypeArrayLength == 0">暂无可选类型</option>
                                <option value="0" v-if="paperTypeArrayLength != 0">请选择</option>
                                <option :value="key" v-for="(item, key) in paperTypeArray" :key="key" v-if="paperTypeArrayLength != 0">{{item}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="section">
                        <div class="title">标注</div>
                        <div class="content">
                            <div class="star-container">
                                <label style="margin-right: 10px;" for="">请选择难度 : </label>
                                <el-rate style="padding: 10px 0;" v-model="star"></el-rate>
                            </div>
                            <search-bar
                            :qid="quesiton_source_info.qid"
                            @emitSearchItem="emitSearchItem"
                            ref="searchBar">
                            </search-bar>
                        </div>
                        <div class="label-area">
                            <tag-base-label
                            v-for="(item, index) in baseTagArray"
                            :key="index" :name="item.name"
                            :qid="question.id"
                            :subjectId="subjectId"
                            :inputTags="TagData[item.name]"
                            @emitTags="emitTags">
                            </tag-base-label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>

<script>
import $ from 'jquery'
// import SockJS from 'sockjs-client'
// import request from '@/common/request'
// import { urls } from '@/common/urls'
/* 引入组件 */
import TagSource from '@/views/Tag/TalTagSource'
import TagBaseLabel from '@/views/Tag/TalTagBaseLabel'
/* End 引入组件 */
export default {
    components: {
        TagSource,
        TagBaseLabel
    },
    data () {
        return {
            question: {
                id: '',
                type: '',
                body: {
                    stem: {
                        body: '',
                        options: {}
                    },
                    answer: {
                        type: '',
                        items: {}
                    },
                    analysis: {
                        enabled: '',
                        type: '',
                        detail: {}
                    }
                }
            },

            systemId: 1, // 系统ID 由首页传入 将来可能改成prop
            gradeLevelId: 1, // 年部ID 由首页传入 将来可能改成prop
            subjectId: 2, // 科目ID 由首页传入 将来可能改成prop

            source: {},

            quesiton_source_info: {
                qid: '',
                input_type: '',
                subject: '',
                grade_level: ''
            },

            creator_info: {
                order_creator: {
                    name: '发起人',
                    value: ''
                },
                created_at: {
                    name: '发起时间',
                    value: ''
                }
            },

            baseTagArray: [], // base标签列表
            TagData: {}, // 标签对象

            paperType: '0', // 卷面类型
            paperTypeArray: {}, // 卷面类型对象，用于加载select

            star: 0 // 难度

            // searchResult: {} // 搜索框搜索出的标签，用于将搜索框内容和base标签同步，这个地方很麻烦，可以用bus通信 or vuex通信

            // authToken: sessionStorage.getItem('auth_token')
            // sock: null,
            // timeOut: 50000,
            // timer: null,
            // maxSendNum: 0,
            // nextTimer: null
        }
    },
    mounted () {
        var self = this
        let obj = {
            qid: '',
            subject_id: this.subjectId
        }
        self.getNextQuestion(obj)
    },
    beforeDestroy () {
        console.warn('=====tag  beforeDetroy======')
        // clearTimeout(this.timer)
        // clearTimeout(this.nextTimer)
        // if (this.sock) {
        //     this.sock.close()
        // }
    },
    // 离开当前路由所进行的操作
    beforeRouteLeave (to, from, next) {
        let that = this
        if (+this.paperType !== 0 || this.star !== 0 || Object.keys(this.TagData).length !== 0) {
            // 询问并跳转
            this.confirmBox('离开页面会丢失当前录入的信息哦!!!').then(() => {
                that.$api['questionTag/tagLeave']().then(data => {
                    next()
                })
            })
        } else {
            // 用户什么都没有填，不询问，直接跳转
            that.$api['questionTag/tagLeave']().then(data => {
                next()
            })
        }
    },
    methods: {
        // websocket
        // sockStart: function () {
        //     this.sock = new WebSocket(
        //         `${urls.SERVER_TEST_HOST_PORT}?token=${this.authToken}`
        //     )
        //     this.sock.onopen = () => {
        //         console.warn('start')
        //         this.sock.send(
        //             `TAG:LISTEN:${this.quesiton_source_info.qid}:${
        //                 this.subjectId
        //             }`
        //         )
        //         console.warn(
        //             `TAG:LISTEN:${this.quesiton_source_info.qid}:${
        //                 this.subjectId
        //             }`
        //         )
        //         this.sockHeart()
        //     }
        //     this.sock.onerror = () => {
        //         console.warn('error')
        //         clearTimeout(this.nextTimer)
        //         this.maxSendNum = 0
        //         this.nextTimer = setTimeout(() => {
        //             this.sockTrible()
        //         }, 2000)
        //     }
        // },
        // sockMessage: function () {
        //     this.sock.onmessage = e => {
        //         console.log('message', e.data)
        //         if (
        //             e.data === 'ERROR:TOKEN_INVALID' ||
        //             e.data === 'MSG:ANOTHER_CONNECTION_FORCE_LINKED'
        //         ) {
        //             this.logOut()
        //         }
        //         if (e.data === 'PONG') {
        //             this.maxSendNum = 0
        //         } else {
        //             this.maxSendNum++
        //         }
        //         if (this.maxSendNum > 6) {
        //             this.sock.close()
        //         }
        //         this.sockHeart()
        //     }
        //     this.sock.onerror = () => {
        //         console.warn('error')
        //         clearTimeout(this.nextTimer)
        //         this.maxSendNum = 0
        //         this.nextTimer = setTimeout(() => {
        //             this.sockTrible()
        //         }, 2000)
        //     }
        // },
        // sockClose: function () {
        //     this.sock.onclose = e => {
        //         console.warn('close')
        //     }
        // },
        // sockTrible: function () {
        //     if (this.sock) {
        //         this.sock.close()
        //     }
        //     this.sockStart()
        //     this.sockMessage()
        //     this.sockClose()
        // },
        // sockHeart: function () {
        //     clearTimeout(this.timer)
        //     this.timer = setTimeout(() => {
        //         this.sock.send('PING')
        //     }, this.timeOut)
        // },
        logOut: function () {
            sessionStorage.removeItem('username')
            sessionStorage.removeItem('uid')
            sessionStorage.removeItem('auth_token')
            this.$router.push({ name: 'Login' })
        },
        /* action */
        // 点击'上一题'事件 获取上一题
        // onClickPrevQuestion: function () {
        //     var self = this
        //     let obj = {
        //         qid: this.question.id,
        //         subject_id: this.subjectId
        //     }
        //     self.clearData()
        //     this.$api['questionTag/tagPrev'](obj)
        //         .then(res => {
        //             console.log('获取上一题成功')
        //             console.log(res)
        //             self.$layer.msg('获取上一题成功')
        //             self.setQuestionInfo(res)
        //             self.getBaseTag()
        //             self.$refs.searchBar.onClickClear()
        //         })
        //         .catch(err => {
        //             console.log('----错误')
        //             console.log(err)
        //             // self.$layer.msg('获取上一题失败')
        //             self.$layer.msg('当前已是第一题')
        //             self.$refs.searchBar.onClickClear()
        //         })
        // },

        // 点击'下一题事件' 因初次加载时需要无id获取一次下一题 so点击事件和ajax请求分离
        onClickNextQuestion: function () {
            let obj = {
                qid: this.question.id,
                subject_id: this.subjectId,
                force: true
            }
            this.clearData()
            this.getNextQuestion(obj)
        },

        // 点击'提交'事件
        // 校验标注信息是否完整 && 正确 通过校验->提交
        // 提交延迟3秒后 自动进入下一题的标注 数据清空
        onClickSubmit: function () {
            var self = this
            if (this.verifySubmit()) {
                let tags = []
                $.each(self.TagData, (base, item) => {
                    $.each(item, (key, tag) => {
                        tag.tid = tag.id
                        delete tag.id
                        tags.push(tag)
                    })
                })
                let obj = {
                    qid: self.question.id,
                    subject_id: self.subjectId,
                    difficult: self.star,
                    paper_type: parseInt(self.paperType),
                    tags: tags
                }
                this.$api['questionTag/tagSubmit'](obj)
                    .then(res => {
                        setTimeout(() => {
                            self.clearData()
                            let reqInfo = {
                                qid: self.question.id,
                                subject_id: self.subjectId,
                                force: true
                            }
                            self.getNextQuestion(reqInfo)
                        }, 3000)
                        self.$message({
                            type: 'success',
                            message: '提交标签成功'
                        })
                    })
                    .catch(err => {
                        console.log(err)
                        self.$message.error('提交标签失败')
                    })
            }
        },
        onClickLeave: function () {
            let that = this
            this.confirmBox('您确定要离开打标签页面吗？').then(() => {
                // 如果确认离开，则跳转路由，事件请求在 路由导航守卫里
                that.$router.replace('/school')
            }).catch(() => {
                console.log('未离开')
            })
        },
        /* End action */

        /* emit */
        // TagBaseLabel组件emit所选tags事件
        emitTags: function (res) {
            this.$set(this.TagData, res.base, res.tags)
            // if (Object.keys(this.TagData[res.base]).length === 0) {
            //     delete this.TagData[res.base]
            // }
        },

        // searchBar组件emit所选tag事件
        // 将search-tag传给对应的TagBase组件
        emitSearchItem: function (res) {
            var self = this
            let reg = /【(.+?)】/g
            let match = reg.exec(res.word_path)
            if (match) {
                let base = match[1]
                let key = self.baseTagArray.find(v => v.name === base)
                if (key === undefined) {
                    self.$message({
                        type: 'warning',
                        message: '当前标签的主标签不可用'
                    })
                } else {
                    // let repeat = false
                    // key = key.name
                    // if (self.searchResult[key]) {
                    //     $.each(self.searchResult[key], (index, item) => {
                    //         if (item.id === res.tag_node_id) {
                    //             repeat = true
                    //         }
                    //     })
                    // } else {
                    //     // 初始化searhResult
                    //     self.$set(self.searchResult, key, [])
                    // }
                    // if (!repeat) {
                    //     self.searchResult[key].push({
                    //         word_path: res.word_path,
                    //         primary: 0,
                    //         id: res.tag_node_id,
                    //         name: res.name
                    //     })
                    // }
                    key = key.name
                    let repeat = self.TagData[key].some(v => v.id === res.tag_node_id)
                    if (!repeat) {
                        self.TagData[key].push({
                            word_path: res.word_path,
                            primary: 0,
                            id: res.tag_node_id,
                            name: res.name
                        })
                    }
                }
            } else {
                self.$message({
                    type: 'warning',
                    message: '该标签未包含任何主标签'
                })
            }
        },
        /* End emit */

        /* private */
        // 获取下一题
        getNextQuestion: function (obj) {
            var self = this
            this.$api['questionTag/tagNext'](obj)
                .then(res => {
                    if (obj.qid) self.$layer.msg('获取下一题成功')
                    self.setQuestionInfo(res)
                    self.getBaseTag()
                    self.$refs.searchBar.onClickClear()
                })
                .catch(err => {
                    console.log(err)
                    self.$layer.msg('获取下一题失败')
                    self.$refs.searchBar.onClickClear()
                })
        },

        // 获取当前题型的base标签
        getBaseTag: function () {
            var self = this
            let obj = {
                system_id: self.systemId,
                grade_level_id: self.gradeLevelId,
                subject_id: self.subjectId
            }

            this.$api['questionTag/tagDimensions'](obj)
                .then(res => {
                    self.baseTagArray = res
                    res.map(v => self.$set(self.TagData, v.name, []))
                })
                .catch(err => {
                    console.log(err)
                })
        },

        // 获取题目信息后 将来源信息设置给TagSource组件事件
        setQuestionInfo: function (data) {
            var self = this
            let tempQuestion = {
                id: data.question_base_data.qid,
                type: data.question_base_data.question_type_id,
                body: data.question_base_data.body
            }
            self.question = tempQuestion

            self.paperTypeArray = data.paper_type_list

            self.quesiton_source_info = {
                qid:
                    data.question_base_data.qid == null
                        ? '暂无数据'
                        : data.question_base_data.qid,
                input_type:
                    data.question_base_data.input_type == null
                        ? '暂无数据'
                        : data.question_base_data.input_type,
                subject:
                    data.question_base_data.subject == null
                        ? '暂无数据'
                        : data.question_base_data.subject,
                grade_level:
                    data.question_base_data.grade_level == null
                        ? '暂无数据'
                        : data.question_base_data.grade_level
            }

            self.creator_info = {
                order_creator: {
                    name: '发起人',
                    value:
                        data.question_base_data.order_creator == null
                            ? '暂无数据'
                            : data.question_base_data.order_creator
                },
                created_at: {
                    name: '发起时间',
                    value:
                        data.question_base_data.created_at == null
                            ? '暂无数据'
                            : data.question_base_data.created_at
                }
            }

            self.source = {
                sourceInfo: self.quesiton_source_info,
                creatorInfo: self.creator_info
            }

            self.$nextTick(() => {
                /* eslint-disable */
                MathJax.Hub.Queue(['Typeset', MathJax.Hub])
                /* eslint-enable */
            })
            // clearTimeout(this.nextTimer)
            // this.maxSendNum = 0
            // this.nextTimer = setTimeout(() => {
            //     this.sockTrible()
            // }, 2000)
        },

        // 校验提交内容是否完整
        verifySubmit: function () {
            var self = this
            let errData = {
                isError: false,
                message: []
            }
            if (this.paperType === '0') {
                errData.isError = true
                errData.message.push(
                    `${errData.message.length + 1}.卷面类型未选择;`
                )
            }
            if (this.star === 0) {
                errData.isError = true
                errData.message.push(
                    `${errData.message.length + 1}.试题难度未填写;`
                )
            }
            let primaryExist = Object.keys(self.TagData).some(v => self.TagData[v].some(t => t.primary === 1))
            
            // $.each(this.TagData, (base, item) => {
            //     $.each(item, (key, tag) => {
            //         if (tag.primary === 1) {
            //             primaryExist = true
            //             return false
            //         }
            //     })
            // })
            if (!primaryExist) {
                errData.isError = true
                errData.message.push(
                    `${errData.message.length + 1}.请至少选择一个标签为主标签;`
                )
            }
            if (errData.isError) {
                self.$modalMessage({
                    title: `检查错误（${errData.message.length}个）`,
                    btn: ['返回修改'],
                    msg: errData.message,
                    confirm: res => {
                        self.$modalMessageClose()
                    }
                })
            } else return true
        },
        // emitclearSearchResult: function () {
        //     this.searchResult = {}
        // },
        // 清空数据
        clearData: function () {
            this.TagData = {}
            $.each(this.TagData, (key, item) => {
                delete this.TagData[key]
            })
            // this.searchResult = {}
            // $.each(this.searchResult, (key, item) => {
            //     delete this.searchResult[key]
            // })
            this.star = 0
            this.paperType = '0'
        },

        confirmBox: function (msg) {
            return this.$confirm(`${msg}`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                })
        }
        /* End private */
    },
    computed: {
        // ok
        paperTypeArrayLength () {
            var self = this
            if (
                self.paperTypeArray == null ||
                self.paperTypeArray === undefined
            ) {
                return 0
            } else return Object.keys(self.paperTypeArray).length
        }
    }
}
</script>

<style lang="scss" scoped>
@import '@/assets/css/Tag/Tag.scss';
</style>
