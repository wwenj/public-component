<template>
    <div class="tag-question-source-area">
        <div class="tag-question-info-area">
            <div class="question-info">
                <i v-for="(info, key, index) in source.sourceInfo" :key="index">
                    <span v-if="key == 'qid'">题目ID: </span>
                    <span>{{info}}</span>
                </i>
            </div>
            <div class="creator-info">
                <i v-for="(info, key) in source.creatorInfo" :key="key">
                    <span>{{info.name}}: </span>
                    <span>{{info.value}}</span>
                </i>
            </div>
        </div>
        <div class="tag-question-operation-area">
            <button class="btn btn-correct" @click="onClickCorrect">纠错</button>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        source: {
            type: Object,
            default: () => {
                return {
                    sourceInfo: {},
                    creatorInfo: {}
                }
            }
        }
    },
    data () {
        return {}
    },
    methods: {
        /* action */
        // 点击'纠错'事件 唤出纠错弹窗
        onClickCorrect: function () {
            var self = this
            this.$modalCorrect({
                qid: this.source.sourceInfo.qid,
                confirm: (res) => {
                    self.$modalCorrectClose()
                    self.$message({
                        type: 'success',
                        message: '成功，您的问题已提交'
                    })
                }
            })
        }
        /* End action */
    }
}
</script>

<style lang="scss" scoped>
.tag-question-source-area {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 0 20px;
    width: 100%;
    height: 100px;
    background: #fff;
    border-radius: 0 0 4px 4px;
    box-sizing: border-box;

    .tag-question-info-area {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        padding: 10px 0;
        width: 60%;
        min-width: 400px;
        height: 100%;
        box-sizing: border-box;

        .question-info {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            height: 40px;

            i {
                display: inline-block;
                height: 10px;
                line-height: 8px;
                padding: 0 20px;

                span {
                    font-size: 14px;
                    letter-spacing: 1px;
                    color: #2f2f2f;
                }
            }

            i:not(:last-child) {
                border-right: 1px solid #eaeaea;
            }
        }

        .creator-info {
            height: 30px;
            line-height: 30px;

            i {
                display: inline-block;
                height: 10px;
                line-height: 8px;
                padding: 0 20px;

                span {
                    font-size: 12px;
                    letter-spacing: 1px;
                    color: #838a9b;
                }
            }

            i:not(:last-child) {
                border-right: 1px solid #eaeaea;
            }
        }
    }

    .tag-question-operation-area {
        margin-top: 20px;

        .btn-correct {
            margin-right: 20px;
            width: 100px;
            height: 30px;
            line-height: 30px;
            color: #6e86fd;
            letter-spacing: 1px;
            outline: none;
            background-clip: padding-box, border-box;
            background-origin: padding-box, border-box;
            background-image: linear-gradient(135deg, #f5f6f8, #f5f6f8), linear-gradient(135deg, #6e86fd, #6ac1fe);
            border: 1px solid transparent;
            border-radius: 15px;
            cursor: pointer;
        }

    }
}
</style>
