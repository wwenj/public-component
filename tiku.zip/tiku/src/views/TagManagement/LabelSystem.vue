<template>
    <div class="wrapper-label-system">
        <div class="origin-area"></div>
        <div class="label-area"></div>
    </div>
</template>

<script>
export default {
    data () {
        return {}
    }
}
</script>

<style lang="scss" scoped></style>
