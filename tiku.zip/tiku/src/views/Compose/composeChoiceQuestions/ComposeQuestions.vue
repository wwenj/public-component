<template>
    <div class="compose-question">
        <div class="sort">
            <span>综合排序</span>
            <span>使用次数</span>
            <span>作答次数</span>
            <span>正确率</span>
            <span class="question-num">试题共计：{{ questionsData.q_total }}道</span>
        </div>
        <div class="question" v-for="(item,index) in questionsData.q_info" :key="index">
            <div class="title">
                <span>使用：250次</span>
                <span>作答：250次</span>
                <span>正确率：50%</span>
                <p>
                    来源：2018年北京市小学初二期末考试
                    <i>共{{item.source.count}}个</i>
                </p>
            </div>
            <h2 class="stem">
                <span>{{index+1}}.</span>
                <p v-html="item.question.body.stem.body"></p>
            </h2>
            <div class="options" v-for="(item,index) in item.question.body.stem.options" :key="index">
                <span>{{index}}.</span>
                <p v-html="item"></p>
            </div>
            <!-- 题目底部 -->
            <div class="bottom">
                <div class="bottom-box">
                    <button>纠错</button>
                    <button @click="composeAnalysisOnClick(item)">解析</button>
                    <button class="add-question" @click="addQuestionOnClick(item,index)" v-if="!saveDataObj[index + questionsData.page * 10]">+ 试题</button>
                    <button class="del-question" @click="delQuestionOnClick(item,index)" v-else>- 移除</button>
                </div>
            </div>
        </div>
        <div class="pagination" v-if="questionsData.page_total>1">
            <el-pagination prev-text="上一页" next-text="下一页" @current-change="currentChangeEmit" :page-size=pageSize background layout="prev, pager, next" :total="questionsData.page_total">
            </el-pagination>
        </div>
        <!-- 侧边固定已选择个数 -->
        <div class="save" @click="toComposeLayoutOnClick">
            <span>{{saveData.length}}</span>
            <p>进入组卷</p>
        </div>
        <composeQuestionsAnalysis ref="composeAnalysis"></composeQuestionsAnalysis>
    </div>
</template>
<script>
import { mapActions } from 'vuex'
// import { SET_QUESTIONS_ACTION } from '@/store/modules/compose.js'
import composeQuestionsAnalysis from '@/views/Compose/composeChoiceQuestions/ComposeQuestionsAnalysis'

export default {
    components: {
        composeQuestionsAnalysis
    },
    data () {
        return {
            pageSize: 1, // 页数
            questionsData: {}, // 查询到题目
            saveData: [], // 最后保存题目
            saveDataObj: {}
        }
    },
    // created () {
    //     this.$nextTick(() => {
    //         // MathJax.Hub.Queue(['Typeset', MathJax.Hub])
    //     })
    // },
    methods: {
        /** action */
        // 把选中试题存到saveDataObj对象，key为当（前页码*10+index）用于渲染逻辑
        // 数据转到数组中传到下一组件
        addQuestionOnClick: function (item, index) {
            let tmpIndex = index + this.questionsData.page * 10
            this.saveDataObj[tmpIndex] = item
            this.saveDataArray()
        },
        delQuestionOnClick: function (item, index) {
            let tmpIndex = index + this.questionsData.page * 10
            delete this.saveDataObj[tmpIndex]
            this.saveDataArray()
        },
        // 进入组卷3 编排页面
        toComposeLayoutOnClick: function () {
            this.setQuestions(this.saveData)
            this.$router.push('/composeLayout')
        },
        // 点击解析
        composeAnalysisOnClick: function (item) {
            this.$refs.composeAnalysis.confirmShow(item.question)
        },
        /** nelement 分页 emit */
        currentChangeEmit: function (page) {
            this.$emit('pageChangeEmit', page)
        },
        /** public */
        // 传入试题数据
        setQuestionsData: function (data) {
            this.questionsData = data
            // 公式转化
            /* eslint-disable */
            this.$nextTick(() => {
                MathJax.Hub.Queue(['Typeset', MathJax.Hub])
            })
            /* eslint-disable */
        },
        /** output */
        /** private */
        // 保存选题对象，转化为数组
        saveDataArray: function() {
            this.saveData = []
            for (let items in this.saveDataObj) {
                this.saveData.push(this.saveDataObj[items])
            }
        },
        ...mapActions(['setQuestions'])
    }
}
</script>

<style lang="scss" scoped>
.compose-question {
    // background: red;
    width: 100%;
    margin-bottom: 10px;
    .sort {
        width: 100%;
        height: 50px;
        background-color: #ffffff;
        margin-top: 9px;
        border-radius: 6px 6px 0px 0px;
        padding-left: 18px;
        box-sizing: border-box;
        span {
            display: inline-block;
            margin-right: 40px;
            line-height: 50px;
            font-size: 12px;
            // color: #6e86fd;
            cursor: pointer;
            color: #6a6f7b;
        }
        .question-num {
            float: right;
            color: #3e4c89;
            margin-right: 50px;
        }
    }
    .title {
        width: 100%;
        height: 46px;
        background-color: #f5f6f8;
        line-height: 46px;
        span {
            display: inline-block;
            font-size: 12px;
            letter-spacing: 1px;
            color: #838a9b;
            margin-left: 42px;
        }
        p {
            float: right;
            font-size: 12px;
            color: #838a9b;
            margin-right: 50px;
            cursor: pointer;
            i {
                font-style: normal;
                margin-left: 20px;
            }
        }
    }
    .question {
        background: #fff;
        margin-top: 10px;
        .stem {
            padding-top: 10px;
            font-size: 14px;
            font-weight: normal;
            font-stretch: normal;
            letter-spacing: 1px;
            color: #2f2f2f;
            position: relative;
            margin-bottom: 20px;
            span {
                float: left;
                line-height: 41px;
                margin-left: 15px;
            }
            p {
                margin-left: 40px;
                max-width:92%;
                min-height: 40px;
                line-height: 40px;
            }
        }
        .options {
            display: inline-block;
            margin: 0px 0 25px 40px;
            font-size: 14px;
            color: #2f2f2f;
            p {
                display: inline-block;
            }
        }
        .bottom {
            height: 50px;
            width: 100%;
            border-top: 1px solid #eaeaea;
            position: relative;
            line-height: 50px;
            .bottom-box {
                position: absolute;
                right: 0;
                button {
                    border: none;
                    font-size: 14px;
                    color: #6e86fd;
                    line-height: 50px;
                    margin-right: 30px;
                }
                .add-question {
                    width: 100px;
                    height: 30px;
                    color: #fff;
                    text-align: center;
                    line-height: 30px;
                    background-image: linear-gradient(
                        90deg,
                        #5f7aff 0%,
                        #6bc1fe 100%
                    );
                    border-radius: 15px;
                }
                .del-question {
                    width: 100px;
                    height: 30px;
                    color: #fff;
                    text-align: center;
                    line-height: 30px;
                    background-image: linear-gradient(
                        90deg,
                        #b1b8c9 0%,
                        #c9ceda 100%
                    );
                    border-radius: 15px;
                }
            }
        }
    }
    .pagination {
        text-align: center;
        margin: 40px 0;
    }
    .save {
        width: 182px;
        height: 46px;
        position: fixed;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        box-shadow: 0px 0px 10px rgba(107, 105, 105, 0.644);
        background-color: #6e86fd;
        border-radius: 23px 0px 0px 23px;
        cursor: pointer;
        span {
            color: #6e86fd;
            display: inline-block;
            width: 40px;
            height: 40px;
            border-radius: 40px;
            background: #fff;
            margin: 3px;
            line-height: 40px;
            text-align: center;
        }
        p {
            display: inline-block;
            margin-left: 20px;
            color: #ffffff;
            font-size: 14px;
        }
    }
}
</style>

