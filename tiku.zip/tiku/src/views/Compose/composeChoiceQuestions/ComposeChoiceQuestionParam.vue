<template>
    <div class="param" v-if="composeParamsArray">
        <!-- 学年 -->
        <div class="params school-year">
            <span class="title">学年:</span>
            <ul>
                <!-- <li class="liClick">全部</li> -->
                <li :class="composeParams.schoolyear.indexOf(item.id) !== -1?'liClick':''" v-for="(item,index) in composeParamsArray.start_school_year.data" :key="index" @click="schoolYearOnClick(item,index)">{{item.name}}</li>
            </ul>
        </div>
        <!-- 省份学校 -->
        <div class="params province">
            <span class="title">省份:</span>
            <ul>
                <el-select style="width:120px;" size="mini" v-model="value.province" placeholder="省" @change="provinceOnChange">
                    <el-option v-for="(item,index) in provinceDataArray" :key="index" :label="item.name" :value="item.id">
                    </el-option>
                </el-select>
                <el-select style="width:120px;" size="mini" v-model="value.city" placeholder="市" @change="cityOnChange">
                    <el-option v-for="(item,index) in cityDataArray" :key="index" :label="item.name" :value="item.id">
                    </el-option>
                </el-select>
                <el-select style="width:120px;" size="mini" v-model="value.area" placeholder="区" @change="areaOnChange">
                    <el-option v-for="(item,index) in areaDataArray" :key="index" :label="item.name" :value="item.id">
                    </el-option>
                </el-select>
                <button @click="findSchoolOnClick">
                    <span>{{schoolName.name}}</span>
                    <img src="@/assets/img/compose/findIcon.png" alt="">
                </button>
            </ul>
        </div>
        <!-- 年级 -->
        <div class="params grade">
            <span class="title">年级:</span>
            <ul>
                <li :class="composeParams.grade.indexOf(item.id) !== -1?'liClick':''" @click="gradeOnClick(item, index)" v-for="(item,index) in composeParamsArray.grade_id.data" :key="index">{{item.name}}</li>
            </ul>
        </div>
        <!-- 学期 -->
        <div class="params term">
            <span class="title">学期:</span>
            <ul>
                <li :class="composeParams.term.indexOf(item.id) !== -1?'liClick':''" @click="termOnClick(item, index)" v-for="(item,index) in composeParamsArray.term_id.data" :key="index">{{item.name}}</li>
            </ul>
        </div>
        <!-- 使用场景 -->
        <div class="params question-type">
            <span class="title">使用场景:</span>
            <ul>
                <li :class="composeParams.scene.indexOf(item.id) !== -1?'liClick':''" @click="questionTypeOnClick(item, index)" v-for="(item,index) in composeParamsArray.source_type_id.data" :key="index">{{item.name}}</li>
            </ul>
        </div>
        <!-- 卷面题型 -->
        <div class="params paper-type">
            <span class="title">卷面题型:</span>
            <ul>
                <li :class="composeParams.showtype.indexOf(item.id) !== -1?'liClick':''" @click="paperTypeOnClick(item, index)" v-for="(item,index) in composeParamsArray.paper_type_id.data" :key="index">{{item.name}}</li>
            </ul>
        </div>
        <choice-school @schoolIdEmit="schoolIdEmit" ref="findSchool" :inputProvinceDataArray="provinceDataArray"></choice-school>
    </div>
</template>
<script>
import request from '@/common/request'
import { NetworkCode } from '@/common/constant'
import { mapGetters } from 'vuex'
import ChoiceSchool from '@/views/Compose/composeBase/ChoiceSchool'
import { toCityAjax, toAreaAjax } from '@/common/commonAjax'
export default {
    components: {
        ChoiceSchool
    },
    data () {
        return {
            value: {
                // 选中省市区id
                province: '',
                city: '',
                area: ''
            },
            cityDataArray: [], // 市option数据
            areaDataArray: [], // 区option数据
            provinceDataArray: [], // 省option数据
            composeParamsArray: null, // 首次请求所有参数
            schoolName: {
                name: '查找学校'
            },
            // 请求试题信息的筛选参数
            composeParams: {
                schoolyear: [''], // 学年支持多选，需要传入一个列表，可为空，可不传
                province: '', // 省，单选，需要传入一个省的id，可为空，可不传
                city: '', // 市，单选，需要传入一个市的id，可为空，可不传
                area: '', // 区，单选，需要传入一个区的id，可为空，可不传
                school: '', // 学校，单选，需要传入一个学校的id，可为空，可不传
                grade: [''], // 年级，支持多选，需要传入年级id列表，可为空，可不传
                term: [''], // 学期，支持多选，需要传入学期id列表，可为空，可不传
                scene: [''], // 使用场景，支持多选，需要传入使用场景id列表，可为空，可不传
                showtype: [''] /// /卷面题型，支持多选，需要传入卷面题型id列表，可为空，可不传
            }
        }
    },
    mounted () {
        // 首次请求所有参数
        this.getSubjectType()
    },
    methods: {
        /* action */
        // 切换省，清空市区选中数据，清空市区数组
        provinceOnChange: function () {
            this.schoolName = { name: '查找学校' }
            this.value.city = ''
            this.value.area = ''
            this.areaDataArray = []
            this.composeParams.province = this.value.province
            this.composeParams.school = ''
            if (this.value.province) {
                var that = this
                toCityAjax(this.value.province, function (data) {
                    that.cityDataArray = data
                })
            } else {
                this.cityDataArray = []
            }
            this.$emit('paramsSearchEmit')
        },
        // 切换市
        cityOnChange: function () {
            this.schoolName = { name: '查找学校' }
            this.composeParams.school = ''
            this.value.area = ''
            this.composeParams.city = this.value.city
            if (this.value.city) {
                var that = this
                toAreaAjax(this.value.city, function (data) {
                    that.areaDataArray = data
                })
            } else {
                this.areaDataArray = []
            }
            this.$emit('paramsSearchEmit')
        },
        // 切换区
        areaOnChange: function () {
            this.schoolName = { name: '查找学校' }
            this.composeParams.school = ''
            this.composeParams.area = this.value.area
            this.$emit('paramsSearchEmit')
        },
        // 搜查学校
        findSchoolOnClick: function () {
            this.$refs.findSchool.show(
                this.value,
                this.cityDataArray,
                this.areaDataArray
            )
        },
        // 选择学年
        schoolYearOnClick: function (item, index) {
            this.paramsDataSave(item, this.composeParams.schoolyear)
        },
        // 选择年级
        gradeOnClick: function (item, index) {
            this.paramsDataSave(item, this.composeParams.grade)
        },
        // 选择学期
        termOnClick: function (item, index) {
            this.paramsDataSave(item, this.composeParams.term)
        },
        // 选择使用场景
        questionTypeOnClick: function (item, index) {
            this.paramsDataSave(item, this.composeParams.scene)
        },
        // 选择卷面题型
        paperTypeOnClick: function (item, index) {
            this.paramsDataSave(item, this.composeParams.showtype)
        },
        /** ChoiceSchool emit */
        // 选择学校后返回数据
        schoolIdEmit: function (
            value,
            cityDataArray,
            areaDataArray,
            schoolItem
        ) {
            this.value = value
            this.cityDataArray = cityDataArray
            this.areaDataArray = areaDataArray
            this.schoolName = schoolItem
            this.composeParams.school = schoolItem.school_id
            this.composeParams.province = schoolItem.province_id
            this.composeParams.city = schoolItem.city_id
            this.composeParams.area = schoolItem.area_id

            this.$emit('paramsSearchEmit')
        },
        /** output */
        outputComposeParams: function () {
            return this.composeParams
        },
        /** private */
        // 对params参数对象封装
        paramsDataSave: function (item, composeParamsArray) {
            if (item.id) {
                // 删除全部选项
                let tmpALl = composeParamsArray.indexOf('')
                if (tmpALl !== -1) {
                    composeParamsArray.splice(tmpALl, 1)
                }
                // 添加、删除选择的选项
                let tmpIndex = composeParamsArray.indexOf(item.id)
                if (tmpIndex !== -1) {
                    composeParamsArray.splice(tmpIndex, 1)
                } else {
                    composeParamsArray.push(item.id)
                }
            } else {
                // 点击全部选项
                composeParamsArray.splice(0, composeParamsArray.length)
                composeParamsArray.push('')
            }
            this.$emit('paramsSearchEmit')
        },
        // ajax
        getSubjectType: function () {
            let obj = {
                level_id: this.currentLevel,
                subject_id: this.currentSubject
            }
            request
                .getComposeParams(obj)
                .then(response => {
                    if (response.data.code !== NetworkCode.Success) {
                        console.log(
                            '组卷条件参数请求错误' + response.data.message
                        )
                    } else {
                        console.log('组卷条件参数请求成功')
                        console.log(response.data.data)
                        this.composeParamsArray = response.data.data
                        this.provinceDataArray =
                            response.data.data.province_id.data
                    }
                })
                .catch(error => {
                    console.log(error)
                    alert('组卷条件参数请求过程出错')
                })
        }
    },
    computed: {
        ...mapGetters(['currentSubject', 'currentLevel', 'materials'])
    }
}
</script>
<style lang="scss" scoped>
.param {
    width: 100%;
    padding: 20px;
    box-sizing: border-box;
    background: #fff;
    border-radius: 6px;
    .title {
        // display: inline-block;
        float: left;
        height: 25px;
        line-height: 25px;
        width: 60px;
        color: #2f2f2f;
        font-size: 12px;
        text-align: right;
    }
    ul {
        margin-left: 70px;
    }
    li {
        color: #6a6f7b;
        font-size: 12px;
        height: 25px;
        line-height: 25px;
        margin-right: 10px;
        // margin-bottom: 10px;
        display: inline-block;
        border-radius: 12px;
        padding: 0 10px;
        cursor: pointer;
    }
    .liClick {
        background-color: #6e86fd;
        color: #fff;
    }
    .params {
        margin-bottom: 20px;
    }
    .school-year {
        width: 100%;
        margin-bottom: 0;
        li {
            margin-bottom: 10px;
        }
    }
    .province {
        button {
            width: 170px;
            height: 30px;
            background-color: #f5f6f8;
            border-radius: 15px;
            border: none;
            color: #b1b8c9;
            font-size: 12px;
            text-align: left;
            margin-left: 10px;
            line-height: 30px;
            vertical-align: middle;
            overflow: hidden;
            position: relative;
            span {
                display: inline-block;
                width: 74%;
                overflow: hidden;
                text-indent: 15px;
            }
            img {
                position: absolute;
                right: 10px;
                top: 50%;
                transform: translateY(-50%);
                vertical-align: middle;
            }
        }
    }
    .question-type {
        li {
            margin-bottom: 10px;
        }
    }
}
</style>


