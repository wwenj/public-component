<template>

    <div class="composeQuestion">
        <header-slot>
            <div class="header-nav" :class="isHeader?'headerNav':''" @click="headerNavOnClick(true)">章节挑题</div>
            <div class="header-nav" :class="isHeader?'':'headerNav'" @click="headerNavOnClick(false)">知识点挑题</div>
            <button class="toBack" @click="toBackOnClick">模板配置</button>
        </header-slot>
        <div class="content">
            <div class="left-chapter">
                <div v-if="materials.length" class="top-materials">
                    <div v-if="!isHeader" class="kownledge">知识点列表</div>
                    <el-popover v-else placement="bottom-end" width="650" trigger="click">
                        <el-button id="popover" slot="reference">{{ materials[materialsIndex].name }}：{{ materialsName }}</el-button>
                        <div class="materials" v-if="isHeader">
                            <div class="materials-type">
                                <span> 使用场景：</span>
                                <ul>
                                    <li id="elAleat" v-for="(item,index) in materials" :key="index" @click="materialsOnClick(index)">{{ item.name }}</li>
                                </ul>
                            </div>
                            <div class="materials-grade">
                                <span> 教材：</span>
                                <ul>
                                    <li v-for="(item,index) in materials[materialsIndex].materials" :key="index" @click="materialsGradeOnClick(item)">{{ item.name }}</li>
                                </ul>
                            </div>
                        </div>
                    </el-popover>
                </div>
                <div v-if="chapterData" class="nav-tree">
                    <el-tree ref="tree" class="tree" :data="computedDataTree" :expand-on-click-node="expandOnClickNode" :props="defaultProps" @node-click="handleNodeClick"></el-tree>
                </div>
            </div>
            <div class="right-content">
                <ComposeChoiceQuestionParam ref="composeParams" @paramsSearchEmit="paramsSearchEmit"></ComposeChoiceQuestionParam>
                <ComposeQuestions @pageChangeEmit="pageChangeEmit" ref="questionsShow"></ComposeQuestions>
            </div>
        </div>
    </div>
</template>
<script>
import ComposeChoiceQuestionParam from '@/views/Compose/composeChoiceQuestions/ComposeChoiceQuestionParam'
import ComposeQuestions from '@/views/Compose/composeChoiceQuestions/ComposeQuestions'
import {
    getChapterData,
    KownledgeTree,
    getComposeSearchQuestions
} from '@/common/commonAjax'
import { mapGetters } from 'vuex'
export default {
    components: {
        ComposeChoiceQuestionParam,
        ComposeQuestions
    },
    data () {
        return {
            isHeader: true,
            chapterData: null, // 侧面导航栏章节tree
            kownledgeData: null, // 侧面导航栏知识点tree
            expandOnClickNode: false, // 点击tree是否打开子目录
            materialsIndex: '0', // 教材版本选择索引
            materialsName: '必修一', // 显示必修name
            defaultProps: {
                children: 'childs',
                label: 'name'
            },
            composeParamsData: {
                knowledgepoint: '4907d6a2325049eba1e8aa000380d89d'
            }, // 所有与请求题型相关的查询参数
            composeQuestionData: {} // 查询到的试题
        }
    },
    mounted () {
        if (this.currentSubject) {
            // 请求默认章节树
            var that = this
            let obj = {
                subject_id: this.currentSubject,
                section_node_id: this.materials[0].materials[0].section_node_id
            }
            getChapterData(obj, function (data) {
                that.chapterData = data
            })
            // 请求知识点树
            let tmpKownledge = {
                subject_id: this.currentSubject,
                grade_level_id: this.currentLevel
            }
            KownledgeTree(tmpKownledge, function (data) {
                that.kownledgeData = data
            })
            // 获取查询题型参数
            this.composeParamsData = Object.assign(
                this.composeParamsData,
                this.$refs.composeParams.outputComposeParams()
            )
            this.getQuestionsData()
        } else {
            this.$router.push('/composeTemplate')
        }
    },
    methods: {
        /** action */
        headerNavOnClick: function (Is) {
            this.isHeader = Is
        },
        // 返回配置模板页面
        toBackOnClick: function () {
            this.$router.push('/composeTemplate')
        },
        // 选择侧边导航tree
        handleNodeClick: function (data) {
            if (this.isHeader) {
                delete this.composeParamsData.knowledgepoint
                this.composeParamsData.chapter = data.id
            } else {
                delete this.composeParamsData.chapter
                this.composeParamsData.knowledgepoint = data.id
            }
            console.log(data)
            this.getQuestionsData()
        },
        // 选择教材版本
        materialsOnClick: function (index) {
            this.materialsIndex = index
        },
        // 选择必修
        materialsGradeOnClick: function (item) {
            this.materialsName = item.name
            var that = this
            let obj = {
                subject_id: this.currentSubject,
                section_node_id: item.section_node_id
            }
            getChapterData(obj, function (data) {
                that.chapterData = data
            })
        },
        /** ComposeChoiceQuestionParam emit */
        paramsSearchEmit: function () {
            let tmpData = this.$refs.composeParams.outputComposeParams()
            this.composeParamsData = Object.assign(
                this.composeParamsData,
                tmpData
            )
            this.getQuestionsData()
        },
        // ComposeQuestions emit
        pageChangeEmit: function (page) {
            this.composeParamsData.page = page
            this.getQuestionsData()
        },
        /** pravite */
        // 根据参数请求题目
        getQuestionsData: function () {
            var that = this
            var tmpObj = {}
            tmpObj.filters = this.composeParamsData
            getComposeSearchQuestions(tmpObj, function (data) {
                that.composeQuestionData = data
                // 子组件传试题数据
                that.$refs.questionsShow.setQuestionsData(data)
            })
        }
    },
    computed: {
        // 侧边tree导航栏显示
        computedDataTree: function () {
            if (this.isHeader) {
                return this.chapterData.childs
            } else {
                return this.kownledgeData
            }
        },
        ...mapGetters(['currentSubject', 'currentLevel', 'materials'])
    }
}
</script>
<style lang="scss" scoped>
.composeQuestion {
    width: 100%;
    .header-nav {
        display: inline-block;
        min-width: 72px;
        height: 64px;
        margin-left: 50px;
        font-family: MicrosoftYaHei;
        font-size: 14px;
        line-height: 70px;
        text-align: center;
        color: #838a9b;
        cursor: pointer;
    }
    .headerNav {
        color: #6e86fd;
        border-bottom: 5px solid #5f7aff;
    }
    .toBack {
        width: 110px;
        height: 36px;
        background-image: linear-gradient(90deg, #5f7aff 0%, #6bc1fe 100%);
        border-radius: 18px;
        font-size: 14px;
        color: #ffffff;
        cursor: pointer;
        position: absolute;
        right: 210px;
        top: 50%;
        transform: translateY(-50%);
        border: none;
    }
    .content {
        width: 100%;
        min-height: 100%;
        overflow: auto;
        background: #edeff5;
        padding-top: 1px;
        .left-chapter {
            position: fixed;
            top: 70px;
            left: 0;
            width: 210px;
            // height: 100%;
            border-radius: 5px;
            background: #fff;
            margin-top: 30px;
            box-shadow: 1px -1px 15px #88888871;
            float: left;
            .top-materials {
                width: 100%;
                height: 40px;
                line-height: 40px;
                font-size: 14px;
                color: #6e86fd;
                cursor: pointer;
                border-bottom: 1px solid rgba(173, 171, 171, 0.541);
                .kownledge {
                    text-indent: 25px;
                    font-size: 14px;
                }
            }
            .nav-tree {
                height: 80vh;
                overflow-y: auto;
                overflow-x: hidden;
            }
        }
        .right-content {
            width: calc(100% - 410px);
            margin-right: 100px;
            height: 100%;
            float: right;
            margin-top: 30px;
        }
    }
}
.tree {
    margin-top: 20px;
}
#popover {
    width: 210px;
    height: 40px;
    border: none;
    color: #6e86fd;
    padding: 0;
}
#popover:hover {
    background: #fff;
    color: #6e86fd;
}
// el显示层
.materials {
    width: 650px;
    span {
        float: left;
    }
    ul {
        margin-left: 70px;
        li {
            // display: inline-block;
            float: left;
            overflow: hidden;
            width: 71px;
            height: 25px;
            border-radius: 12px;
            cursor: pointer;
            font-size: 12px;
            line-height: 25px;
            text-align: center;
            margin-right: 10px;
            margin-bottom: 10px;
        }
        li:hover {
            color: #ffffff;
            background-color: #6e86fd;
        }
    }
    .materials-type {
        margin-bottom: 35px;
        overflow: hidden;
    }
    .materials-grade {
        overflow: hidden;
    }
}
#elAleat {
    color: #ffffff;
    background-color: #6e86fd;
}
</style>


