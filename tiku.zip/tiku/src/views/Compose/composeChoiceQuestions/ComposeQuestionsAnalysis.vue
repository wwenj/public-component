<template>
    <transition name="confirm-fade">
        <div class="confirm" v-show="showFlag" @click.stop>
            <div class="confirm-wrapper">
                <div class="confirm-content">
                    <h2>{{ inputAlertTitle }}
                        <span @click="confirmHide">X</span>
                    </h2>
                    <div class="operate">
                        <TalPreviewItem :inputShowTitle="false" :inputQuestion="inputQuestion"></TalPreviewItem>
                    </div>
                </div>
            </div>
        </div>
    </transition>
</template>

<script type="text/ecmascript-6">
export default {
    data () {
        return {
            inputAlertTitle: '试题解析',
            showFlag: false,
            inputQuestion: {}
        }
    },
    methods: {
        // 组件显示
        confirmShow (item) {
            this.inputQuestion = item
            this.showFlag = true
            // 公式转化
            /* eslint-disable */
            this.$nextTick(() => {
                MathJax.Hub.Queue(['Typeset', MathJax.Hub])
            })
            /* eslint-disable */
        },
        // 组件隐藏
        confirmHide () {
            this.showFlag = false
        }
    }
}
</script>

<style scoped lang="scss">
.confirm {
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    z-index: 9980;
    color: #4d4d4d;
    background-color: rgba(0, 0, 0, 0.5);
    .confirm-wrapper {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 800px;
        min-height: 280px;
        padding-bottom: 30px;
        background-color: #ffffff;
        border-radius: 12px;
        overflow: hidden;
        transform: translate(-50%, -50%);
        box-sizing: border-box;
        .confirm-content {
            h2 {
                width: 100%;
                height: 50px;
                line-height: 50px;
                letter-spacing: 1px;
                color: #ffffff;
                font-size: 18px;
                font-weight: normal;
                text-indent: 20px;
                background-image: linear-gradient(
                    90deg,
                    #5f7aff 0%,
                    #6bc1fe 100%
                );
                span {
                    float: right;
                    margin-right: 20px;
                    font-size: 20px;
                    cursor: pointer;
                }
            }
            .operate {
                overflow-y: auto;
                max-height: 680px;
            }
            .operate-btn {
                display: inline-block;
                width: 160px;
                height: 36px;
                border-radius: 18px;
                border: solid 1px #6e86fd;
                outline: none;
            }
            .left {
                color: #ffffff;
                border: none;
                background-image: linear-gradient(
                    90deg,
                    #5f7aff 0%,
                    #6bc1fe 100%
                );
                margin-right: 15px;
            }
        }
    }
}

.confirm-fade-enter-active {
    animation: confirm-fadein 0.3s;
}

.confirm-content {
    animation: confirm-zoom 0.3s;
}

@keyframes confirm-fadein {
    0% {
        opacity: 0;
    }

    100% {
        opacity: 1;
    }
}

@keyframes confirm-zoom {
    0% {
        transform: scale(0);
    }

    50% {
        transform: scale(1.1);
    }

    100% {
        transform: scale(1);
    }
}
</style>
