<template>
    <div class="compose-layout-wrapper">
        <div class="header">
            <header-slot>
                <p class="title">昌平实验中学 高一 数学  人教版  导学案</p>
            </header-slot>
        </div>
        <div class="content">
            <div class="side-left">
                左半边
            </div>
            <div class="middle">
                中间部分中间部分中间部分中间部分中间部
                中间部分中间部分中间部分中间部分中间部
                中间部分中间部分中间部分中间部分中间部
                间部分中间部分中间部分中间部分中间部分
                间部分中间部分中间部分中间部分中间部分
                间部分中间部分中间部分中间部分中间部分
                √
                √
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
                <p>间部分中间部分中间部分中间部分中间部分</p>
            </div>
            <div :class="[toggleSlide ? 'side-right' : 'side-right-expand']">
                <div class="slide-btn" @click="slideOnClick">{{slideTip}}</div>
            </div>
        </div>
        <div class="footer">
            <button class="btn">预览</button>
            <button class="btn">提交</button>
        </div>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
    data () {
        return {
            toggleSlide: true,
            slideTip: '展开'
        }
    },
    created () {
        // 组卷2选中的试题数据
        console.log(this.composeQuestions)
    },
    methods: {
        slideOnClick: function () {
            this.toggleSlide = !this.toggleSlide
            this.slideTip = this.toggleSlide ? '展开' : '收缩'
        }
    },
    computed: {
        ...mapGetters(['composeQuestions'])
    }
}
</script>

<style lang="scss" scoped>
.compose-layout-wrapper {
    width: 100%;
    height: 100%;
    background: #edeff5;
    overflow: hidden;
    .header {
        .title {
            margin-left: 31px;
            margin-top: 29px;
            font-size: 18px;
            color: #2f2f2f;
        }
    }
    .content {
        position: relative;
        display: flex;
        height: calc(100% - 175px);
        margin-top: 21px;
        .side-left {
            width: 210px;
            height: 100%;
            background: #f5f6f8;
        }
        .middle {
            flex: 1;
            padding: 31px 40px 45px 42px;
            background: #fff;
            overflow: scroll;
        }
        .side-right {
            position: absolute;
            top: 0;
            right: -210px;
            @extend .side-left;
            transition: .5s;
            // box-shadow: -2px 0px 8px #ccc;
            .slide-btn {
                box-sizing: border-box;
                position: absolute;
                top: 236px;
                left: -31.5px;
                width: 32px;
                height: 116px;
                padding: 39px 9px;
                font-size: 14px;
                background: url('~@/assets/img/compose/expand.png') no-repeat;
                color: #fff;
            }
        }
        .side-right-expand {
            @extend .side-right;
            right: 0;
            // transition: .5s;
        }
    }
    .footer {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 84px;
        margin-bottom: 20px;
        .btn {
            width: 150px;
            height: 32px;
            margin: 0 12px;
            background-image: linear-gradient(90deg,#5f7aff 0%,#6bc1fe 100%);
            border-radius: 16px;
            color: #fff;
        }
    }
}
</style>


