<template>
    <div class="compose-wrapper">
        <!-- 头部信息插槽 -->
        <header-slot></header-slot>
        <div class="compose">
            <div class="content school">
                <span class="title">学校</span>
                <el-autocomplete :value="schoolResult.school_name" value-key='school_name' size='medium' clearable :fetch-suggestions="querySearchAsync" placeholder="请输入学校名称" @select="handleSelect"></el-autocomplete>
                <compose-error-text style="margin-left:90px" ref="findSchool"></compose-error-text>
            </div>
            <!-- 选择模板 -->
            <div class="content template" v-if="composeTypeArray.length">
                <span class="title">模板选择</span>
                <span v-for="(item) in composeTypeArray" @click="composeTypeOnclick(item.id)" :key="item.id" class="compose-type" :id="clickStyle(item.id,iscomposeType)">
                    {{ item.name }}
                </span>
            </div>
            <!-- 年部科目 -->
            <div class="content subject" v-if="levelSubjectArray.length">
                <span class="title">年部科目</span>
                <ul>
                    <li v-for="(item) in levelSubjectArray" :key="item.id">
                        <span class="level">{{item.name}}</span>
                        <button v-for="(itemChil) in item.data" :key="itemChil.id" :id="leveClickStyle(item.id, itemChil.id,levelSubjectIndex)" @click="subjectOnclick(item.id, itemChil.id)">{{ itemChil.name }}</button>
                    </li>
                </ul>
            </div>
            <!-- 教材版本 -->
            <div class="content materials" v-if="materialsArray.length">
                <span class="title">教材版本</span>
                <ul>
                    <button v-for="(item,index) in materialsArray" :key="index" :id="clickStyle(index,materialsIndex)" @click="materialsOnclick(index)">{{ item.name }}</button>
                </ul>
            </div>
            <!-- 年级/必修 -->
            <div class="content grade" v-if="materialsArray.length">
                <span class="title">年级</span>
                <div class="button">
                    <button v-for="(item,index) in materialsArray[materialsIndex].materials" :key="index" :id="clickStyle(index, gradeIndex)" @click="gradeOnClick(index,item.section_node_id)">{{ item.name }}</button>
                </div>
            </div>
            <!-- 章节结构 -->
            <div class="content chapter" v-if="materialsArray.length">
                <span class="title">章节结构</span>
                <button class="add-btn" @click="addChapterOnclick">
                    <img src="@/assets/img/recording/add.png" alt="">
                    <span>添加章节</span>
                </button>
                <ul>
                    <li v-if="chapterDataArray.length" v-for="(item,index) in chapterDataArray" :key="index">
                        {{ item.path }}
                        <img src="@/assets/img/recording/del.png" @click.stop="delChapterOnClick(index,item.id)">
                    </li>
                </ul>
                <compose-error-text style="margin-left:90px" ref="addChapter"></compose-error-text>
            </div>
            <button class="next" @click="toNextOnClick">下一步</button>
            <DelConfirmAlert ref="delConfirmAlert" @delConfirmEmit="delConfirmEmit"></DelConfirmAlert>
            <switchConfirmAlert ref="switchConfirmAlert" @switchConfirmEmit="switchConfirmEmit"></switchConfirmAlert>
            <Chapter-tree @chapterDataEmit="chapterDataEmit" ref="chapterTree">
            </chapter-tree>
        </div>
        <el-table :data="levelSubjectArray" v-loading.body.fullscreen="computedLoading" element-loading-text="数据玩命加载中....."></el-table>
    </div>
</template>
<script>
import DelConfirmAlert from '@/views/Compose/composeBase/DelConfirmAlert'
import switchConfirmAlert from '@/views/Compose/composeBase/SwitchConfirmAlert'
import ComposeErrorText from '@/views/Compose/composeBase/ComposeErrorText'
import request from '@/common/request'
import { NetworkCode } from '@/common/constant'
import { mapActions } from 'vuex'
import { getChapterData } from '@/common/commonAjax'
export default {
    components: {
        DelConfirmAlert,
        switchConfirmAlert,
        ComposeErrorText
    },
    data () {
        return {
            triggerFalse: false, // 初次搜索框聚焦时不搜索内容
            composeTypeArray: [], // 模板的类型
            levelSubjectArray: [], // 年部，学科
            materialsArray: [], // 教材版本，年级
            chaptersDataArray: [], // 章节信息
            iscomposeType: 1, // 模板选择索引
            materialsIndex: 0, // 教材版本索引，确认年级，显示样式
            gradeIndex: 0, // 年级索引
            levelSubjectIndex: [3, 2], // 学部学科索引,选择结果
            schoolResult: {}, // 学校搜索结果
            chapterDataArray: [], // 选择章节信息
            chapterSaveDataId: '', // 选择章节id
            isClickOption: false // 标识有没有选择搜索学校选项
        }
    },
    computed: {
        // 数据请求结束前显示loading
        computedLoading: function () {
            if (
                this.composeTypeArray.length &&
                this.levelSubjectArray.length &&
                this.materialsArray.length
            ) {
                this.$nextTick(() => {
                    return false
                })
            } else {
                return true
            }
        }
    },
    mounted () {
        // 首次请求年部学科，模板，教材版本，年级
        this.getSubjectType()
        this.getMaterialsData()
        let tmpData = {
            subject: this.levelSubjectIndex[1],
            level: this.levelSubjectIndex[0]
        }
        this.setSubjectLevel(tmpData)
    },
    methods: {
        /* action */
        // 搜索学校，input
        querySearchAsync (queryString, cb) {
            this.isClickOption = false
            let obj = {
                keyword: queryString
            }
            request
                .getSourceSchool(obj)
                .then(response => {
                    if (response.data.code !== NetworkCode.Success) {
                        console.log('搜索学校请求错误' + response.data.message)
                    } else {
                        console.log('搜索学校请求成功')
                        console.log(response.data.data)
                        cb(response.data.data) // 显示搜索结果
                    }
                })
                .catch(error => {
                    console.log(error)
                    alert('搜索学校请求过程出错')
                })
        },
        // 点击搜索学校结果
        handleSelect: function (item) {
            console.log(item)
            this.schoolResult = item
            this.isClickOption = true
        },
        // 点击下一步
        toNextOnClick: function () {
            // 从选项中选择后再次修改数据清空
            if (!this.isClickOption) {
                this.schoolResult = {
                    name: ''
                }
            }
            this.$refs.findSchool.errorInputHidd()
            this.$refs.addChapter.errorInputHidd()
            if (!this.schoolResult.school_id) {
                this.$refs.findSchool.errorInputShow('请选择学校')
            }
            if (!this.chapterDataArray.length) {
                this.$refs.addChapter.errorInputShow('请选择章节')
            }
            if (this.schoolResult.school_id && this.chapterDataArray.length) {
                this.$router.push('/composeQuestions')
            }
        },
        // 选择模板点击
        composeTypeOnclick: function (index) {
            this.iscomposeType = index
        },
        // 选择教材版本点击
        materialsOnclick: function (index) {
            this.$refs.switchConfirmAlert.confirmShow('教材版本')
            this.chapterDataArray = []
            this.materialsIndex = index
            // 切换版本教材更新章节
            var that = this
            let obj = {
                subject_id: this.levelSubjectIndex[1],
                section_node_id: this.materialsArray[index].materials[0]
                    .section_node_id
            }
            // 查询章节
            getChapterData(obj, function (data) {
                that.chaptersDataArray = data
            })
        },
        // 选择年级点击
        gradeOnClick: function (index, id) {
            this.$refs.switchConfirmAlert.confirmShow('年级')
            this.chapterDataArray = []
            var that = this
            this.gradeIndex = index

            let obj = {
                subject_id: this.levelSubjectIndex[1],
                section_node_id: id
            }
            getChapterData(obj, function (data) {
                that.chaptersDataArray = data
            })
        },
        // 选择年部学科点击
        subjectOnclick: function (levelId, subjectId) {
            this.$refs.switchConfirmAlert.confirmShow('年部学科')
            this.chapterDataArray = []
            this.levelSubjectIndex = [levelId, subjectId]
            let obj = {
                subject_id: subjectId,
                grade_level_id: levelId
            }
            this.getMaterialsData(obj)
            let tmpData = {
                subject: subjectId,
                level: levelId
            }
            this.setSubjectLevel(tmpData)

            // 清除教材版本和年级的选择状态
            this.materialsIndex = 0
            this.gradeIndex = 0
        },
        // 增加章节
        addChapterOnclick: function () {
            this.$refs.chapterTree.chapterShow(this.chaptersDataArray.childs)
        },
        // 删除已选章节
        delChapterOnClick: function (index, tid) {
            this.$refs.delConfirmAlert.confirmShow(index, tid)
        },
        /* emit */
        delConfirmEmit: function (index, tid) {
            var tepIndex = tid + ','
            if (this.chapterSaveDataId.length === 1) {
                tepIndex = tid
            }
            var reg = new RegExp(tepIndex, 'g')
            this.chapterSaveDataId = this.chapterSaveDataId.replace(reg, '')
            this.chapterDataArray.splice(index, 1)
        },
        switchConfirmEmit: function () {},
        // 确认章节
        chapterDataEmit: function (dataArr) {
            console.log(dataArr)
            this.chapterDataArray = dataArr
        },
        /* public */
        /* output */
        /* prive */
        // 点击后加上点击后的样式
        clickStyle: function (index, thisIndex) {
            if (index === thisIndex) {
                return 'composeTypeDown'
            } else {
                return ''
            }
        },
        // 点击年部学科后加上点击后的样式
        leveClickStyle: function (levelId, subjectId, thisIndex) {
            if (levelId === thisIndex[0] && subjectId === thisIndex[1]) {
                return 'composeTypeDown'
            } else {
                return ''
            }
        },
        // 获取模板学部学科信息
        /* ajax */
        getSubjectType: function () {
            request
                .gitComposeType()
                .then(response => {
                    if (response.data.code !== NetworkCode.Success) {
                        console.log(
                            '组卷年部学科请求错误' + response.data.message
                        )
                    } else {
                        console.log('组卷年部学科请求成功')
                        this.composeTypeArray = response.data.data.compose_type
                        this.levelSubjectArray =
                            response.data.data.level_subject
                        console.log(response.data.data)
                    }
                })
                .catch(error => {
                    console.log(error)
                    alert('组卷年部学科请求过程出错')
                })
        },
        // 获取教材信息
        getMaterialsData: function (obj) {
            var that = this
            request
                .gitMaterialsType(obj)
                .then(response => {
                    if (response.data.code !== NetworkCode.Success) {
                        console.log('教材请求错误' + response.data.message)
                    } else {
                        console.log('教材请求成功')
                        console.log(response.data.data)
                        this.materialsArray = response.data.data
                        let obj = {
                            subject_id: this.levelSubjectIndex[1],
                            section_node_id: this.materialsArray[0].materials[0]
                                .section_node_id
                        }
                        // 查询章节
                        getChapterData(obj, function (data) {
                            that.chaptersDataArray = data
                        })
                        // 存vuex
                        that.setMaterials(response.data.data)
                    }
                })
                .catch(error => {
                    console.log(error)
                    alert('教材请求过程出错')
                })
        },
        ...mapActions(['setSubjectLevel', 'setMaterials'])
    }
}
</script>

<style lang="scss" scoped>
.compose-wrapper {
    width: 100%;
    overflow: auto;
    background: #edeff5;
    .title {
        float: left;
        width: 60px;
        height: 30px;
        line-height: 30px;
        font-size: 14px;
        color: #2f2f2f;
        margin-right: 30px;
        text-align: justify;
        letter-spacing: 1;
        // text-align: right;1
    }
    .compose {
        width: 1200px;
        margin: auto;
        .content {
            width: 100%;
            background: #fff;
            margin-top: 20px;
            padding: 35px 50px;
        }
        .school {
            input {
                width: 200px;
                height: 30px;
                background-color: #ffffff;
                border-radius: 4px;
                border: solid 1px #e6e8ed;
                text-indent: 15px;
            }
        }
        .template {
            .compose-type {
                display: inline-block;
                vertical-align: middle;
                width: 100px;
                height: 30px;
                background-color: #ffffff;
                border-radius: 4px;
                border: solid 1px rgba(160, 171, 188, 0.5);
                text-align: center;
                cursor: pointer;
                font-size: 14px;
                line-height: 30px;
                letter-spacing: 1px;
                margin-right: 30px;
            }
        }
        .subject {
            ul {
                margin-left: 90px;
                li {
                    margin-bottom: 25px;
                    .level {
                        display: inline-block;
                        width: 60px;
                        height: 20px;
                        text-align: center;
                        line-height: 20px;
                        border-left: 4px solid #6e86fd;
                    }
                    button {
                        width: 80px;
                        height: 30px;
                        background-color: #ffffff;
                        border-radius: 4px;
                        border: solid 1px rgba(160, 171, 188, 0.5);
                        margin-right: 20px;
                        cursor: pointer;
                        // outline: none;
                    }
                }
            }
        }
        .materials {
            ul {
                margin-left: 90px;
            }
            button {
                width: 100px;
                height: 30px;
                background-color: #ffffff;
                border-radius: 4px;
                border: solid 1px rgba(160, 171, 188, 0.5);
                vertical-align: middle;
                margin-right: 30px;
                overflow: hidden;
                margin-bottom: 20px;
            }
        }
        .grade {
            .button {
                margin-left: 90px;
            }
            button {
                width: 100px;
                height: 30px;
                background-color: #ffffff;
                border-radius: 4px;
                border: solid 1px rgba(160, 171, 188, 0.5);
                overflow: hidden;
                margin-right: 30px;
                vertical-align: middle;
                margin-bottom: 25px;
            }
        }
        .chapter {
            margin-bottom: 10px;
            li {
                margin-left: 90px;
                font-size: 14px;
                line-height: 25px;
                letter-spacing: 1px;
                color: #6e86fd;
            }
        }
        .next {
            display: block;
            margin: 40px auto;
            width: 200px;
            height: 36px;
            background-image: linear-gradient(90deg, #5f7aff 0%, #6bc1fe 100%);
            border-radius: 18px;
            font-size: 14px;
            color: #fff;
            cursor: pointer;
        }
    }
}
#composeTypeDown {
    background-color: #6e86fd;
    color: #ffffff;
}
.add-btn {
    width: 110px;
    height: 36px;
    border-radius: 17px;
    color: #6e86fd;
    outline: none;
    background-clip: padding-box, border-box;
    background-origin: padding-box, border-box;
    background-image: linear-gradient(135deg, #f5f6f8, #f5f6f8),
        linear-gradient(135deg, #6e86fd, #6ac1fe);
    border: 1px transparent solid;
    cursor: pointer;
    img {
        width: 12px;
        height: 12px;
        vertical-align: middle;
    }
    span {
        vertical-align: middle;
        font-size: 14px;
    }
}
</style>
