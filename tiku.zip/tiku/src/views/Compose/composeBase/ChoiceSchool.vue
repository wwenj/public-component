<template>
    <transition name="school-fade">
        <div class="school" @click.stop v-if="isShow">
            <div class="school-wrapper">
                <div class="school-header">
                    <h3>选择学校</h3>
                    <span class="close" @click="schoolCloseOnClick">X</span>
                </div>
                <div class="school-content">
                    <div class="address">
                        <span>地域：</span>
                        <div class="address-select">
                            <el-select style="width:100px;" size="mini" v-model="schoolValue.province" placeholder="省" @change="provinceOnChange">
                                <el-option v-for="(item, index) in inputProvinceDataArray" :key="index" :label="item.name" :value="item.id">
                                </el-option>
                            </el-select>
                            <el-select style="width:100px;" size="mini" v-model="schoolValue.city" placeholder="市" @change="cityOnChange">
                                <el-option v-for="(item,index) in cityDataArray" :key="index" :label="item.name" :value="item.id">
                                </el-option>
                            </el-select>
                            <el-select style="width:100px;" size="mini" v-model="schoolValue.area" placeholder="区" @change="areaOnChange">
                                <el-option v-for="(item,index) in areaDataArray" :key="index" :label="item.name" :value="item.id">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
                    <div class="find-school">
                        <span>学校：</span>
                        <input type="text" v-model="keyword" placeholder="请输入学校名称">
                        <img src="@/assets/img/common/findSchool.png" title="搜索" @click="findSchoolAjaxOnClick">
                    </div>
                    <div class="school-list">
                        <div v-if="noSchoolShow" class="no-school">
                            <img src="@/assets/img/common/findNoSchool.png" alt="">
                            <p>暂无匹配学校</p>
                        </div>
                        <ul>
                            <li @click="schoolChoiceOnClick(item)" v-for="(item ,index) in findResultArray" :key="index">
                                <a>{{ item.school_name }}</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </transition>
</template>


<script>
import { toCityAjax, toAreaAjax, findSchool } from '@/common/commonAjax'
export default {
    props: {
        inputProvinceDataArray: {
            type: Array,
            default: function () {
                return []
            }
        }
    },
    data () {
        return {
            isShow: false,
            SchoolAddresData: [],
            findResultArray: [], // 搜索结果
            noSchoolShow: false, // 搜索为空空白页
            schoolValue: {
                // 选中省市区id
                province: '',
                city: '',
                area: ''
            },
            keyword: '', // 关键词搜索
            cityDataArray: [], // 市option数据
            areaDataArray: [] // 区option数据
        }
    },
    methods: {
        /* action */
        // 关闭组件
        schoolCloseOnClick: function () {
            this.isShow = false
        },
        // 切换省，清空市区选中数据，清空市区数组
        provinceOnChange: function () {
            this.schoolValue.city = ''
            this.schoolValue.area = ''
            this.areaDataArray = []
            if (this.schoolValue.province) {
                var that = this
                toCityAjax(this.schoolValue.province, function (data) {
                    that.cityDataArray = data
                })
            } else {
                this.cityDataArray = []
            }
            this.findSchoolAjax()
        },
        // 切换市
        cityOnChange: function () {
            this.schoolValue.area = ''
            if (this.schoolValue.city) {
                var that = this
                toAreaAjax(this.schoolValue.city, function (data) {
                    that.areaDataArray = data
                })
            } else {
                this.areaDataArray = []
            }
            this.findSchoolAjax()
        },
        // 切换区
        areaOnChange: function () {
            this.findSchoolAjax()
        },
        // 点击查找按钮查找学校
        findSchoolAjaxOnClick: function () {
            this.findSchoolAjax()
        },
        // 改变选择省市时
        ProvinceCityOnChange: function ($event, item) {},
        /* public */
        // 显示此组件并传参
        show: function (schoolValue, cityDataArray, areaDataArray) {
            // ref传值导致父子组件传的是个对象引用，子组件会改变父组件的数据，拷贝
            let tmpValue = JSON.parse(JSON.stringify(schoolValue))
            this.schoolValue = tmpValue
            this.cityDataArray = cityDataArray
            this.areaDataArray = areaDataArray
            this.isShow = true
        },
        /* private */
        // 搜索学校请求
        findSchoolAjax: function () {
            var that = this
            let obj = {
                keyword: this.keyword,
                province_id: this.schoolValue.province,
                city_id: this.schoolValue.city,
                area_id: this.schoolValue.area
            }
            findSchool(obj, function (data) {
                that.findResultArray = data
                if (!data.length) { // 显示结果为空页面
                    that.noSchoolShow = true
                } else {
                    that.noSchoolShow = false
                }
            })
        },
        // 选择搜索的学校
        schoolChoiceOnClick: function (item) {
            this.findResultArray = [] // 清空搜索结果
            var that = this
            // async/await异步
            var city = function () {
                return new Promise(function (resolve, reject) {
                    toCityAjax(item.province_id, function (data) {
                        that.cityDataArray = data
                        resolve(data)
                    })
                })
            }
            var area = function () {
                return new Promise(function (resolve, reject) {
                    toAreaAjax(item.city_id, function (data) {
                        that.areaDataArray = data
                        resolve(data)
                    })
                })
            }
            async function schoolSave () {
                that.cityDataArray = await city()
                that.areaDataArray = await area()
                that.schoolValue = {
                    province: String(item.province_id),
                    city: String(item.city_id),
                    area: String(item.area_id)
                }
                that.$emit(
                    'schoolIdEmit',
                    that.cityDataArray,
                    that.areaDataArray,
                    item
                )
            }
            schoolSave()
            this.schoolCloseOnClick()
        }
    }
}
</script>

<style scoped lang="scss">
.school {
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    z-index: 980;
    color: #4d4d4d;
    background-color: rgba(0, 0, 0, 0.5);
    .school-wrapper {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 600px;
        height: 470px;
        background-color: #ffffff;
        border-radius: 12px;
        overflow: hidden;
        .school-header {
            width: 100%;
            height: 50px;
            background-image: linear-gradient(90deg, #5f7aff 0%, #6bc1fe 100%);
            padding: 0 30px;
            box-sizing: border-box;
            h3 {
                height: 100%;
                line-height: 50px;
                float: left;
                font-size: 18px;
                letter-spacing: 1px;
                color: #ffffff;
            }
            .close {
                height: 100%;
                font-size: 18px;
                color: #ffffff;
                line-height: 50px;
                float: right;
                cursor: pointer;
            }
        }
        .school-content {
            padding: 30px 40px;
            box-sizing: border-box;
            select {
                width: 100px;
                height: 36px;
                margin: 0 22px 12px 0;
                background-color: #ffffff;
                border-radius: 4px;
                color: #b1b8c9;
                border: solid 1px rgba(160, 171, 188, 0.22);
            }
            .address {
                height: 36px;
                font-size: 14px;
                color: #2f2f2f;
                .address-select {
                    display: inline-block;
                }
            }
            .find-school {
                width: 100%;
                height: 36px;
                font-size: 14px;
                color: #2f2f2f;
                margin-top: 23px;
                input {
                    width: 341px;
                    height: 36px;
                    background-color: #ffffff;
                    border-radius: 4px;
                    border: solid 1px rgba(160, 171, 188, 0.22);
                    text-indent: 10px;
                }
                img {
                    vertical-align: middle;
                    height: 38px;
                    margin-top: -4px;
                    margin-left: -45px;
                    cursor: pointer;
                }
            }
            .school-list {
                width: 521px;
                height: 240px;
                margin-top: 22px;
                background-color: #f9f9f9;
                border-radius: 10px;
                border: solid 1px #f1f1f1;
                overflow-y: auto;
                padding-top: 10px;
                box-sizing: border-box;
                .no-school {
                    text-align: center;
                    margin-top: 40px;
                    color: #707070;
                    font-size: 12px;
                    p {
                        margin-top: 20px;
                    }
                }
                li {
                    display: inline-block;
                    width: 220px;
                    height: 25px;
                    overflow: hidden;
                    margin-left: 25px;
                    a {
                        cursor: pointer;
                    }
                    a:hover {
                        color: rgb(253, 181, 27);
                    }
                }
            }
        }
    }
}

.school-fade-enter-active {
    animation: school-fadein 0.3s;
}

.school-content {
    animation: school-zoom 0.3s;
}

@keyframes school-fadein {
    0% {
        opacity: 0;
    }

    100% {
        opacity: 1;
    }
}

@keyframes school-zoom {
    0% {
        transform: scale(0);
    }

    50% {
        transform: scale(1.1);
    }

    100% {
        transform: scale(1);
    }
}
</style>
