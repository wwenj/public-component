<template>
    <transition name="confirm-fade">
        <div class="confirm" v-if="showFlag" @click.stop>
            <div class="confirm-wrapper">
                <div class="confirm-content">
                    <h2>{{ inputAlertTitle }}</h2>
                    <p>{{inputAlertContent}}</p>
                    <div class="operate">
                        <button @click="toNext" class="operate-btn left">确认</button>
                        <button @click="toBack" class="operate-btn">取消</button>
                    </div>
                </div>
            </div>
        </div>
    </transition>
</template>

<script type="text/ecmascript-6">
export default {
    data () {
        return {
            inputAlertTitle: '删除章节',
            inputAlertContent: '您确定删除此章节吗',
            showFlag: false,
            idnex: '',
            tid: ''
        }
    },
    methods: {
        // 组件显示
        confirmShow (index, tid) {
            this.showFlag = true
            this.index = index
            this.tid = tid
        },
        // 组件隐藏
        confirmHide () {
            this.showFlag = false
        },
        // 取消callback
        toBack () {
            this.confirmHide()
        },
        // 确认callback
        toNext () {
            this.confirmHide()
            this.$emit('delConfirmEmit', this.index, this.kid)
        }
    }
}
</script>

<style scoped lang="scss">
.confirm {
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    z-index: 19980;
    color: #4d4d4d;
    background-color: rgba(0, 0, 0, 0.24);
    .confirm-wrapper {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 400px;
        height: 280px;
        // background-color: #ffffff;
        border-radius: 12px;
        transform: translate(-50%, -50%);
        padding: 0 20px;
        background: #ffffff url('../../../assets/img/common/delSouceAlert.png') no-repeat;
        box-sizing: border-box;
        .confirm-content {
            h2 {
                width: 100%;
                height: 50px;
                line-height: 50px;
                letter-spacing: 1px;
                color: #ffffff;
                font-size: 18px;
                font-weight: normal;
                font-stretch: normal;
                text-align: center;
            }
            p {
                font-size: 18px;
                height: 140px;
                line-height: 140px;
                text-align: center;
                color: #0b1334;
            }
            .operate {
                text-align: center;
                margin: auto;
                margin-top: 5px;
            }
            .operate-btn {
                display: inline-block;
                width: 160px;
                height: 36px;
                border-radius: 18px;
                border: solid 1px #6e86fd;
                outline: none;
            }
            .left {
                color: #ffffff;
                border: none;
                background-image: linear-gradient(
                    90deg,
                    #5f7aff 0%,
                    #6bc1fe 100%
                );
                margin-right: 15px;
            }
        }
    }
}

.confirm-fade-enter-active {
    animation: confirm-fadein 0.3s;
}

.confirm-content {
    animation: confirm-zoom 0.3s;
}

@keyframes confirm-fadein {
    0% {
        opacity: 0;
    }

    100% {
        opacity: 1;
    }
}

@keyframes confirm-zoom {
    0% {
        transform: scale(0);
    }

    50% {
        transform: scale(1.1);
    }

    100% {
        transform: scale(1);
    }
}
</style>
