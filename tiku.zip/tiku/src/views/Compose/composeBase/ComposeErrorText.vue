<template>
    <p class="error-icon" v-if="isShow">
        <img src="@/assets/img/common/icon-tips.png" alt="">
        <span>{{ inputErrorText }}</span>
    </p>
</template>
<script>
export default {
    data () {
        return {
            isShow: false,
            inputErrorText: '不能为空'
        }
    },
    methods: {
        errorInputShow: function (text) {
            this.isShow = true
            this.inputErrorText = text
        },
        errorInputHidd: function () {
            this.isShow = false
        }
    }
}
</script>
<style lang="scss" scoped>
.error-icon {
    img {
        vertical-align: middle;
    }
    span {
        vertical-align: middle;
    }
    font-size: 12px;
    color: #ff0000;
}
</style>


