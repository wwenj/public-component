// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
// import router from './router'
// 引入插件
import router from './plugins/router'
import inject from './plugins/inject'

import store from './store'
// import axios from 'axios'
import layer from 'vue-layer'
// import wangEditor from '../static/wangEditor-3.1.1/release/wangEditor'

import { editorRegisterUI } from 'common/editor.js'


import components from '@/components/register-components'

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

Vue.use(ElementUI)
Vue.config.productionTip = false
/** 引入axios */
// Vue.prototype.$ajax = axios
Vue.use(inject)
Vue.prototype.$layer = layer(Vue)
// Vue.prototype.$wangEditor = wangEditor
Vue.use(components)

/** 定义一个bus, 以完成兄弟组件间通信 */
var eventBus = {
    install () {
        Vue.prototype.$bus = new Vue()
    }
}
Vue.use(eventBus)

global.vbus = new Vue()

// 富文本编辑器初始化自定义按钮
editorRegisterUI()

// 浏览器刷新关闭事件监听，阻止用户误操作


/* eslint-disable no-new */
new Vue({
    el: '#app',
    router,
    store,
    components: {
        App
    },
    template: '<App/>'
})
