<template>
    <transition name="chapter-fade">
        <div class="chapter" @click.stop v-if="isShow">
            <div class="chapter-wrapper">
                <div class="chapter-header">
                    <h3>所属章节</h3>
                    <button class="btn btn-collapse" @click="onClickCollapse">
                        <span v-if="isCollapse">收起</span>
                        <span v-else>展开</span>
                        <img src="@/assets/img/common/arrow-down.png" class='arrow' :class="isCollapse ? 'rotate' : ''">
                    </button>
                </div>
                <div class="chapter-content">
                    <div class="el-tree">
                        <el-tree class="" ref="tree" node-key="id"
                        :default-checked-keys="setCheckedKeysData"
                        :default-expand-all='isCollapse'
                        :data="chapterDataArray" :props="defaultProps" show-checkbox></el-tree>
                    </div>
                </div>
                <div class="chapter-footer">
                    <button class="rightBtn" @click="chapterCloseOnClick">取消</button>
                    <button @click="chapterConfirmOnClick">确定</button>
                </div>
            </div>
        </div>
    </transition>
</template>

<script>
/**
 * 调用chapterShow(data:array)显示传数据
 * 返回chapterDataEmit事件，参数为id，path属性的对象的集合
 */
export default {
    data () {
        return {
            isShow: false,
            isCollapse: false,
            chapterSaveDataArray: [], // 确定选中的章节信息
            // chapterShowDataArray: ['b806cd33bc8611e8a28088e9fe4e0263', 'b805e1d7bc8611e899ad88e9fe4e0263', 'b805e82ebc8611e88c0f88e9fe4e0263', 'b805f361bc8611e8914888e9fe4e0263'], // 默认勾选tree显示的枝干
            setCheckedKeysData: [], // 点击树节点后需要重新展示的树节点
            defaultProps: {
                children: 'childs',
                label: 'name'
            },
            // tree显示数据，数组
            chapterDataArray: [],
            chapterTmpDataArray: [] // 点击保存的节点数组
        }
    },
    methods: {
        /* checkChange: function (treeData, b) {
            console.log('------tree-------')
            // 获取当前点击tree节点的的id和其所有祖先节点的id组成数组
            let tmpTreeData = treeData.path.split(',')
            tmpTreeData.push(treeData.id)
            // 当点击的节点没有被勾选时把他们添加进勾选数组，已被勾选则移除出数组
            if (this.setCheckedKeysData.indexOf(treeData.id) === -1) {
                this.setCheckedKeysData = this.setCheckedKeysData.concat(tmpTreeData)
            } else {
                var that = this
                tmpTreeData.forEach(function (item) {
                    let tmpIndex = that.setCheckedKeysData.indexOf(item)
                    that.setCheckedKeysData.splice(tmpIndex, 1)
                })
            }
            console.log(this.setCheckedKeysData)
            // 组好数据最后重新展示当前该勾选的节点
            this.$refs.tree.setCheckedKeys(this.setCheckedKeysData)
        }, */
        /* action */
        // 取消
        chapterCloseOnClick: function () {
            this.isShow = false
            this.chapterDataArray = []
        },
        // 确认
        chapterConfirmOnClick: function () {
            this.chapterSaveDataArray = []
            var that = this
            // 获取选中所属章节的信息
            let tmpChapterData = this.$refs.tree.getCheckedNodes()

            tmpChapterData.forEach(function (item) {
                if (item.is_leaf === 1) {
                    let obj = {
                    id: item.section_node_id,
                    path: item.word_path
                }
                that.chapterSaveDataArray.push(obj)
                }
            })
            console.log('----tree--------')
            console.log(this.chapterSaveDataArray)
            this.$emit('chapterDataEmit', this.chapterSaveDataArray)
            this.isShow = false
            this.chapterDataArray = []
        },
        onClickCollapse: function () {
            this.isCollapse = !this.isCollapse
            for (var i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
                this.$refs.tree.store._getAllNodes()[i].expanded = this.isCollapse
            }
        },
        /* public */
        // 所属章节组件显示，传入显示数据
        chapterShow: function (data) {
            this.isShow = true
            this.chapterDataArray = data
        },
        /* output */
        // 返回当前确认的所有章节id,path组成的数组
        outputChapterSaveDataId: function () {
            return this.chapterSaveDataArray
        }
    }
}
</script>

<style scoped lang="scss">
.chapter {
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    z-index: 19980;
    color: #4d4d4d;
    background-color: rgba(0, 0, 0, 0.5);
    .chapter-wrapper {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        overflow: hidden;
        width: 600px;
        height: 700px;
        background-color: #ffffff;
        border-radius: 12px;
        select {
            width: 160px;
            height: 36px;
            background-color: #ffffff;
            border-radius: 4px;
            border: solid 1px rgba(160, 171, 188, 0.22);
            margin: 0 22px 12px 0;
            color: #b1b8c9;
        }
        .chapter-header {
            width: 100%;
            height: 50px;
            background-image: linear-gradient(90deg, #5f7aff 0%, #6bc1fe 100%);
            padding: 0 30px;
            box-sizing: border-box;
            .btn-collapse {
                font-size: 14px;
                letter-spacing: 1px;
                color: #fff;
                float: right;
                height: 50px;
                line-height: 50px;
                cursor: pointer;
                border: none;
                // 动画过渡效果
                .arrow {
                    width: 12px;
                    height: 8px;
                    transform: rotateZ(0);
                    transition: all .5s;
                    z-index: 1;
                }
                .arrow.rotate {
                    transform: rotateZ(180deg);
                }
                // 动画过渡效果结束
            }
            h3 {
                height: 100%;
                line-height: 50px;
                float: left;
                font-size: 18px;
                letter-spacing: 1px;
                color: #ffffff;
            }
            .close {
                height: 100%;
                font-size: 18px;
                color: #ffffff;
                line-height: 50px;
                float: right;
                cursor: pointer;
            }
        }
        .chapter-footer {
            width: 100%;
            height: 65px;
            background-color: #ffffff;
            border-radius: 0px 0px 12px 12px;
            box-shadow: 0px -1px 20px #8888887e;
            z-index: 1000;
            position: absolute;
            bottom: 0px;
            button {
                width: 110px;
                height: 30px;
                color: #ffffff;
                background-image: linear-gradient(
                    90deg,
                    #5f7aff 0%,
                    #6bc1fe 100%
                );
                border-radius: 15px;
                margin-right: 30px;
                float: right;
                margin-top: 17px;
                cursor: pointer;
                outline: none;
            }
            .rightBtn {
                border-radius: 15px;
                border: solid 1px #6e86fd;
                background: #ffffff;
                color: #6e86fd;
            }
        }
        .chapter-content {
            padding: 30px 25px 0 20px;
            box-sizing: border-box;
            .select-top {
                height: 36px;
                font-size: 14px;
                color: #2f2f2f;
                margin-bottom: 20px;
                .select-content {
                    display: inline-block;
                    margin-left: 10px;
                }
                .select-title {
                    display: inline-block;
                    width: 70px;
                    margin-left: 30px;
                }
            }
            .el-tree {
                width: 100%;
                height: 555px;
                overflow: auto;
            }
        }
    }
}
.chapter-fade-enter-active {
    animation: chapter-fadein 0.3s;
}

.chapter-content {
    animation: chapter-zoom 0.3s;
}

@keyframes chapter-fadein {
    0% {
        opacity: 0;
    }

    100% {
        opacity: 1;
    }
}

@keyframes chapter-zoom {
    0% {
        transform: scale(0);
    }

    50% {
        transform: scale(1.1);
    }

    100% {
        transform: scale(1);
    }
}
</style>
