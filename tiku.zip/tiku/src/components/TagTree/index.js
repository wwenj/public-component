import Vue from 'vue'
import $ from 'jquery'
import TagTree from '@/components/TagTree/TagTree'

TagTree.installTagTree = function (options) {
    var Tagtree = Vue.extend(TagTree)

    var component = new Tagtree({
        data: options
    }).$mount()
    $('#main-content').append(component.$el)
}

TagTree.closeTagTree = function () {
    $('.layer-label-list-wrapper').remove()
}

export default TagTree
