<template>
    <div class="layer-label-list-wrapper" @click.self="onClickCancel">
        <div class="layer-label-list-content">
            <div class="title">
                <span>【{{title}}】</span>
                <button class="btn btn-collapse" @click="onClickCollapse">
                    <span v-if="isCollapse">收起</span>
                    <span v-else>展开</span>
                    <img src="@/assets/img/common/v.png" class='arrow' :class="isCollapse ? 'rotate' : ''">
                </button>
            </div>
            <div class="content">
                <el-tree
                    ref="tree"
                    node-key="id"
                    show-checkbox
                    empty-text="无标签可选"
                    :data="tagTree"
                    :expand-on-click-node="false"
                    :check-on-click-node="true"
                    :default-expand-all='isCollapse'
                    :props="defaultProps">
                </el-tree>
            </div>
            <div class="footer">
                <button class="btn btn-confirm" @click="getCheckedNodes">确认</button>
                <button class="btn btn-cancel" @click="onClickCancel">取消</button>
            </div>
        </div>
    </div>
</template>

<script>
import $ from 'jquery'

export default {
    data () {
        return {
            title: '',
            isCollapse: false,
            selectedTags: [],
            tagTree: [],
            defaultProps: {
                children: 'childs',
                label: 'name'
            },

            confirm: function () {}

            // isStrictly: true
        }
    },
    created () {
        $('.vl-notice-title').hide()
        $('.vl-notify-content').css({
            padding: 0,
            height: '100%'
        })

        $('.vl-notify-iframe').css({
            borderRadius: '12px'
        })
        $('.vl-notify.vl-notify-main').css({
            paddingBottom: 0
        })
    },
    mounted () {
        var self = this
        let tmpArray = []
        $.each(self.selectedTags, (index, item) => {
            tmpArray.push({
                id: item.id,
                name: item.name,
                primary: item.primary
            })
        })
        self.$refs.tree.setCheckedNodes(tmpArray)
    },
    methods: {
        onClickCollapse: function () {
            this.isCollapse = !this.isCollapse
            for (var i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
                this.$refs.tree.store._getAllNodes()[i].expanded = this.isCollapse
            }
        },
        onClickCancel: function () {
            this.$TagTreeClose()
        },
        getCheckedNodes: function () {
            this.confirm(this.$refs.tree.getCheckedNodes(true, false))
        },
        getCheckedKeys: function () {
            this.confirm(this.$refs.tree.getCheckedKeys())
        }
    }
}
</script>

<style lang="scss">
.layer-label-list-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,.5);

    .layer-label-list-content {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        width: 600px;
        height: 700px;
        margin: auto;
        border-radius: 12px;
        background: #fff;
        z-index: 10;

        .title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 80px;
            padding: 0 30px;
            color: #fff;
            background: url('~@/assets/img/common/label-bullet-box-top.png') no-repeat;

            .btn-collapse {
                font-size: 14px;
                letter-spacing: 1px;
                color: #fff;

                // 动画过渡效果
                .arrow {
                    width: 12px;
                    height: 8px;
                    transform: rotateZ(0);
                    transition: all .5s;
                    z-index: 1;
                }
                .arrow.rotate {
                    transform: rotateZ(180deg);
                }
                // 动画过渡效果结束
            }
        }

        .content {
            max-height: 555px;
            padding: 10px 25px 30px;
            overflow: scroll;
            box-sizing: border-box;
        }

        ul:not(:first-child) {
            margin-left: 40px;
        }

        ul li {
            margin-top: 10px;
            // border: 1px solid blue;
        }
        ul:first-child > li > label {
            display: inline-block;
            width: 94%;
            border-bottom: 1px solid #ccc;
        }

        .footer {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            position: absolute;
            bottom: 0;
            width: 100%;
            height: 65px;
            background-color: #fff;
            opacity: .9;
            box-shadow: 0 1px 20px #ccc;
            border-radius: 0px 0px 12px 12px;

            .btn {
                height: 30px;
                width: 110px;
                margin-right: 30px;
                border-radius: 15px;
                border: none;
            }
            .btn-confirm {
                color: #fff;
                background: linear-gradient(to right,#5f7aff, #6bc1fe)
            }
            .btn-cancel {
                color: #6e86fd;
                border: solid 1px #6e86fd;
            }
        }

        // 重写 列表 样式
        .vl-notify.vl-notify-main {
            padding-bottom: 0;
        }
        .el-tree > .el-tree-node {
            display: flex;
            flex-direction: column;
            justify-content: center;
            margin-top: 20px;
            padding: 18px;
            border-radius: 10px;
            background: #f9f9f9;
        }

        .el-tree-node {
            color: #2f2f2f;
        }

        .el-tree-node.is-checked {
            color: #7088fd;
        }
    }

    .el-tree-node__expand-icon {
        position: absolute;
        right: 20px;
    }
}
</style>
