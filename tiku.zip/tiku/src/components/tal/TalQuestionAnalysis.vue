<template>
    <div class="analysis-wrapper">
        <div class="title">解析</div>
        <div class="analysis-header">
            <span>
                <input type="checkbox" class="jiexi-checkbox" @change="clearAnalysisOnChange" v-model="isNeedAnalysis">
                <span class="jiexi-checkbox-text">
                    <span class="strong">无需解析</span>
                    <span class="em">（仅限题目简单，需要解析但暂时没有解析的题目不要选择）</span>
                </span>
            </span>
            <span v-if="!isNeedAnalysis && isShowAccordingOptionAnalysis">
                <input type="checkbox" name="" v-model="isAccordingOptionAnalysis" @change="accordingOptionAnalysisOnChange">
                <span class="jiexi-checkbox-text">
                    <span class="strong">{{privateGetOptionCheckTitle()}}</span>
                </span>
            </span>
        </div>
        <div class="analysis-content" v-if="!isNeedAnalysis">
            <!-- 按照选项解析 -->
            <div class="option-analysis" v-show="isAccordingOptionAnalysis">
                <div v-for="(item, index) in optionAnalysisArray" :key="item.id">
                    <div v-if="index < currentOptionsCount" class="analysis-item" style="flex-direction: row; align-items: center;">
                        <span :style="[{'width': privateQuestionAnalysisTitleWidth()}]">{{privateGetOptionTitleWithIndex(index)}}:</span>
                        <div class="editor-wrapper" :style="[{'width': privateQuestionAnalysisEditorWidth()}]">
                            <editor :inputText='item.textInput' :inputIndex="index" @editorEmit='editorEmit'></editor>
                        </div>
                    </div>
                </div>
            </div>
            <div class="method-analysis" v-show="!isAccordingOptionAnalysis">
                <!-- 按照方法解析 -->
                <div v-for="(item, index) in methodAnalysisArray" :key="item.id">
                    <div v-if="index < currentMethodsCount" class="analysis-item" style="flex-direction: column; align-items: flex-start;">
                        <div v-if="currentMethodsCount > 1">{{methodMap[index]}}</div>
                        <div class="editor-wrapper">
                            <editor :inputText='item.textInput' :inputIndex="index" @editorEmit='editorEmit' :style="{width: index === 0 ? '100%' : '92%'}"></editor>
                            <img src="@/assets/img/recording/del.png" alt="del" @click="deleteOnClick(index)" v-if="index !== 0">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="analysis-footer" v-if="!isAccordingOptionAnalysis && !isNeedAnalysis">
            <button @click="addOnClick" class="add-btn" :disabled='!computedCanAddNewAnalysis' :class="[!computedCanAddNewAnalysis ? 'btn-disabled' : '']">
                <img src="@/assets/img/recording/add.png" alt="+" v-if="computedCanAddNewAnalysis">
                <img src="@/assets/img/recording/gray.png" alt="+" v-else>
                <span>更多方法</span>
            </button>
        </div>
    </div>
</template>

<script>
import { QuestionTypeCollection, Question, methodMap } from '@/common/constant'
import { stringIsEmpty } from '@/common/common'
export default {
    // input 表示props
    // onClickAddChosse
    // xxEmit
    props: {
        // 按选项解析用的到， 默认值4
        inputOptionsCount: {
            type: Number,
            default: 4
        },
        inputQuestionType: {
            type: Number,
            required: true,
            default: Question.SingleChoice.type
        },
        // 方法能增加的最大数量，默认为10
        inputMaxMethodsCount: {
            type: Number,
            default: 10
        },
        // 选项能增加的最大数量，默认为20
        inputMaxOptionsCount: {
            type: Number,
            default: 20
        },
        // 从父组件传入的解析数据， 默认值如下, 解析类型默认为方法解析（Content） |Opt 选项解析和分小题解析
        inputAnalysisData: {
            type: Object,
            default () {
                return {
                    enabled: 1,
                    type: QuestionTypeCollection.AnalysisType.Content,
                    detail: {}
                }
            }
        }
    },
    data () {
        return {
            // 方法个数
            currentMethodsCount: 1,
            currentOptionsCount: this.inputOptionsCount,
            // 按选项解析存储的数组
            optionAnalysisArray: [],
            // 按方法解析存储的数组
            methodAnalysisArray: [],
            // 是否需要解析
            isNeedAnalysis: !this.inputAnalysisData.enabled,
            // 是否按选项解析
            isAccordingOptionAnalysis: this.inputAnalysisData.type === QuestionTypeCollection.AnalysisType.Opt,
            isShowAccordingOptionAnalysis: false,
            // 在此数据结构里获取解析的类型
            QuestionTypeCollection,
            methodMap,
            Question,
            // 单个解析的id
            analysisItemNextId: 0
        }
    },
    created () {
        this.privateInitData(this.inputAnalysisData.detail)
        this.$bus.$on('refreshAnalysis', params => {
            console.log('兄弟组件传过来的参数', params)
            this.privateInitData(params.detail)
        })
    },
    mounted () {
        // 组件首次加载执行  判断是否显示 按选项解析标题
        this.privateQuestionIsNeedOptionAnalysis()
    },
    methods: {
        /* action */
        // 增加方法解析
        addOnClick: function () {
            let methodAnalysisArrayLength = this.methodAnalysisArray.length
            if (this.currentMethodsCount === methodAnalysisArrayLength) {
                alert(`最多添加${this.inputMaxMethodsCount}个选项哦！`)
            } else {
                this.currentMethodsCount += 1
            }
            this.$emit('anaysisObjectChangeEmit', this.outputAnalysisObject())
        },
        // 删除某一个方法解析
        deleteOnClick: function (index) {
            let deleteAnalysisArray = this.methodAnalysisArray.splice(index, 1)
            let deleteAnalysis = deleteAnalysisArray[0]
            deleteAnalysis.text = ''
            this.methodAnalysisArray.push(deleteAnalysis)
            this.currentMethodsCount -= 1
            this.$emit('anaysisObjectChangeEmit', this.outputAnalysisObject())
        },
        // 清空解析
        clearAnalysisOnChange: function () {
            if (this.isAccordingOptionAnalysis) {
                let isNeed = window.confirm('是否确认无需解析，确认后解析将被清空')
                // let that = this
                if (isNeed) {
                    // 清空
                    this.methodAnalysisArray.forEach((item, index) => {
                        item.text = ''
                    })
                    this.optionAnalysisArray.forEach((item, index) => {
                        item.text = ''
                    })
                    this.isAccordingOptionAnalysis = false
                    this.currentMethodsCount = 1
                    this.$emit('anaysisObjectChangeEmit', this.outputAnalysisObject())
                } else {
                    this.isNeedAnalysis = false
                }
            } else {
                this.methodAnalysisArray.forEach((item, index) => {
                    item.text = ''
                })
                this.optionAnalysisArray.forEach((item, index) => {
                    item.text = ''
                })
                this.isAccordingOptionAnalysis = false
                this.currentMethodsCount = 1
                this.$emit('anaysisObjectChangeEmit', this.outputAnalysisObject())
            }
        },
        accordingOptionAnalysisOnChange: function () {
            this.privateInitOptionAnalysisArray([])
            this.$emit('anaysisObjectChangeEmit', this.outputAnalysisObject())
        },
        /* emit */
        editorEmit: function (data) {
            let text = data.text
            let index = data.index
            if (this.isAccordingOptionAnalysis) {
                this.$set(this.optionAnalysisArray[index], 'textOutput', text)
            } else {
                this.$set(this.methodAnalysisArray[index], 'textOutput', text)
            }
            this.$emit('anaysisObjectChangeEmit', this.outputAnalysisObject())
        },
        /* public */
        refreshOptionsCount: function (optionsCount) {
            this.currentOptionsCount = optionsCount
        },
        refreshAnalysisData: function (analysisObject) {
            this.privateInitData(analysisObject)
        },
        // 校验解析
        verifyQuestionAnalysis: function () {
            let analysisObject = this.outputAnalysisObject()
            let questionErrorArray = []
            // 只有在选中 需要解析的时候才会进行下列操作
            if (analysisObject.enabled) {
                // 分两种情况，按选项（小题）解析和按方法解析
                if (analysisObject.type === QuestionTypeCollection.AnalysisType.Content) {
                    for (let key in analysisObject.detail) {
                        if (!stringIsEmpty(analysisObject.detail[key])) {
                            questionErrorArray.push('解析不能为空，请完善解析内容')
                            return questionErrorArray
                        }
                    }
                } else if (analysisObject.type === QuestionTypeCollection.AnalysisType.Opt) {
                    for (let key in analysisObject.detail) {
                        if (!stringIsEmpty(analysisObject.detail[key])) {
                            if (
                                this.inputQuestionType === Question.Filling.type ||
                                this.inputQuestionType === Question.MulChoiceMul.type
                            ) {
                                questionErrorArray.push('空格解析不能为空，请完善解析内容')
                            } else if (
                                this.inputQuestionType === Question.Cloze.type ||
                                this.inputQuestionType === Question.Pair.type ||
                                this.inputQuestionType === Question.Judgement.type
                            ) {
                                questionErrorArray.push('小题解析不能为空，请完善解析内容')
                            } else {
                                questionErrorArray.push('选项解析不能为空，请完善解析内容')
                            }

                            return questionErrorArray
                        }
                    }
                }
            }
            return questionErrorArray
        },
        /* output */
        // 向父元素传递 解析对象
        outputAnalysisObject: function () {
            let analysisObject = {}
            analysisObject.detail = {}
            analysisObject['enabled'] = this.isNeedAnalysis ? 0 : 1
            // 无需解析
            if (this.isNeedAnalysis) {
                analysisObject['type'] = ''
                analysisObject['detail'] = {}
            } else {
                // 如果按照选项解析
                if (this.isAccordingOptionAnalysis) {
                    analysisObject['type'] = QuestionTypeCollection.AnalysisType.Opt
                    for (let i = 0; i < this.currentOptionsCount; i++) {
                        analysisObject.detail[this.privateGetOptionTitleWithIndex(i)] = this.optionAnalysisArray[i].textOutput
                    }
                } else {
                    analysisObject['type'] = QuestionTypeCollection.AnalysisType.Content
                    for (let i = 0; i < this.currentMethodsCount; i++) {
                        analysisObject.detail[i + 1] = this.methodAnalysisArray[i].textOutput
                    }
                }
            }
            return analysisObject
        },
        /* private */
        privateInitData: function (analysisObject) {
            // 获取解析数组
            let tmpAnalysisArray = []
            for (let key in analysisObject) {
                let value = analysisObject[key]
                tmpAnalysisArray.push(value)
            }
            // 按选项解析，则把数据存储在optionAnalysisArray中
            // 清空
            this.optionAnalysisArray = []
            this.methodAnalysisArray = []

            if (this.isAccordingOptionAnalysis) {
                // this.privateInitMethodAnalysisArray([])
                this.privateInitOptionAnalysisArray(tmpAnalysisArray)
            } else {
                this.currentMethodsCount = Object.keys(analysisObject).length
                // 方法解析必须最少有一个
                if (this.currentMethodsCount === 0) {
                    this.currentMethodsCount = 1
                }
                this.privateInitMethodAnalysisArray(tmpAnalysisArray)
                // this.privateInitOptionAnalysisArray([])
            }
        },
        privateInitOptionAnalysisArray: function (tmpAnalysisArray) {
            console.log('tmpAnalysisArray', tmpAnalysisArray)
            let tmpAnalysisArrayLength = tmpAnalysisArray.length
            for (let i = 0; i < this.inputMaxOptionsCount; i++) {
                let text = ''
                if (i < tmpAnalysisArrayLength) {
                    text = tmpAnalysisArray[i]
                }
                let value = {
                    id: this.analysisItemNextId++,
                    textInput: text,
                    textOutput: text
                }
                console.log('value', value)
                this.optionAnalysisArray.push(value)
            }
        },
        privateInitMethodAnalysisArray: function (tmpAnalysisArray) {
            let tmpAnalysisArrayLength = tmpAnalysisArray.length
            for (let i = 0; i < this.inputMaxMethodsCount; i++) {
                let text = ''
                if (i < tmpAnalysisArrayLength) {
                    text = tmpAnalysisArray[i]
                }
                let value = {
                    id: this.analysisItemNextId++,
                    textInput: text,
                    textOutput: text
                }
                this.methodAnalysisArray.push(value)
            }
        },
        // 计算选项的标题
        privateGetOptionTitleWithIndex: function (index) {
            // 将来可以根据类型进行switch,case
            let analysisTitle = ''
            switch (this.inputQuestionType) {
                case Question.SingleChoice.type:
                case Question.MulChoice.type:
                    analysisTitle = `${String.fromCharCode(65 + index)}`
                    break
                case Question.Judgement.type:
                case Question.Pair.type:
                case Question.Cloze.type:
                    analysisTitle = `${1 + index}`
                    break
                case Question.Filling.type:
                case Question.MulChoiceMul.type:
                    analysisTitle = `空${1 + index}解析 `
                    break
                default:
                    break
            }
            return analysisTitle
        },
        // 计算分选项解析的标题
        privateGetOptionCheckTitle: function () {
            let title = ''
            switch (this.inputQuestionType) {
                case Question.SingleChoice.type:
                case Question.MulChoice.type:
                    title = '选项解析'
                    break
                case Question.Judgement.type:
                case Question.Filling.type:
                case Question.MulChoiceMul.type:
                case Question.Pair.type:
                case Question.Cloze.type:
                    title = '分小题解析'
                    break
                default:
                    break
            }
            return title
        },
        // 计算本题型是否需要选项解析
        // 传参表示填空题和对选题的选项个数
        privateQuestionIsNeedOptionAnalysis: function (optionsCount) {
            let result = false
            switch (this.inputQuestionType) {
                case Question.SingleChoice.type:
                case Question.MulChoice.type:
                case Question.Judgement.type:
                case Question.Pair.type:
                case Question.Cloze.type:
                    result = true
                    break
                case Question.Subjective.type:
                case Question.Sort.type:
                case Question.WordStosen.type:
                    result = false
                    break
                case Question.Filling.type:
                case Question.MulChoiceMul.type:
                    if (optionsCount > 1) {
                        result = true
                    }
                    break
                default:
                    break
            }
            this.isShowAccordingOptionAnalysis = result
        },
        privateQuestionAnalysisTitleWidth: function () {
            let width = ''
            switch (this.inputQuestionType) {
                case Question.Filling.type:
                case Question.MulChoiceMul.type:
                    width = '80px'
                    break
                case Question.SingleChoice.type:
                case Question.MulChoice.type:
                case Question.Judgement.type:
                case Question.Subjective.type:
                case Question.Pair.type:
                case Question.Cloze.type:
                    width = '20px'
                    break
                default:
                    break
            }
            return width
        },
        privateQuestionAnalysisEditorWidth: function () {
            let width = this.privateQuestionAnalysisTitleWidth()
            return `calc( 100% - ${width} )`
        }
    },
    computed: {
        // 是否可以添加新的选项
        computedCanAddNewAnalysis () {
            return this.currentMethodsCount < this.inputMaxMethodsCount
        }
    },
    watch: {
        inputAnalysisData: {
            handler: function (newVal) {
                // 是否需要解析
                this.isNeedAnalysis = !newVal.enabled
                // 是否按选项解析
                this.isAccordingOptionAnalysis = newVal.type === QuestionTypeCollection.AnalysisType.Opt
                this.privateInitData(newVal.detail)
            },
            deep: true
        },
        inputOptionsCount: function (newVal) {
            // 选项个数被更改  判断是否显示 按选项解析标题， 目前主要照顾 填空题
            this.currentOptionsCount = newVal
            this.privateQuestionIsNeedOptionAnalysis(newVal)
            // 解析个数改变，自动通知父组件一次, 预览同步改变
            this.$emit('anaysisObjectChangeEmit', this.outputAnalysisObject())
        }
    }
}
</script>

<style lang="scss" scoped>
    .analysis-wrapper {
        .analysis-header {
            //解析下面复选框与文字
            .jiexi-checkbox {
                vertical-align: middle;
            }
            .jiexi-checkbox-text {
                vertical-align: middle;
                .strong {
                    font-size: 14px;
                    font-weight: 500;
                    color: #838a9b;
                }
                .em {
                    font-size: 12px;
                    color: #b1b8c9;
                    margin-left: -8px;
                }
            }
        }
        .analysis-content {
            .analysis-item {
                display: flex;
                margin-top: 20px;
            }
        }
        .analysis-footer {
            margin-top: 20px;
        }
        .editor-wrapper {
            position: relative;
            width: 100%;
            img {
                position: absolute;
                top: 12px;
                right: 7px;
            }
        }
    }
</style>

