<template>
    <div class="mul-choice-wrapper">
        <!-- 题干组件 -->
        <tal-question-stem-body
        ref="questionStemBody"
        :inputText='inputQuestion.body.stem.body'
        @textChangeEmit='textChangeEmit'>
        </tal-question-stem-body>

        <!-- 选项组件 -->
        <tal-question-options
        ref="questionOptions"
        :inputQuestionType='inputQuestion.type'
        :inputOptionObject='inputQuestion.body.stem.options'
        :inputAnswerObject='inputQuestion.body.answer'
        :inputCurrentCount='computedOptionsCount'
        @answerObjectChangeEmit='answerObjectChangeEmit'
        @optionObjectChangeEmit='optionObjectChangeEmit'
        @allChangeEmit='allChangeEmit'
        @deleteOptionSyncAnalysisEmit='deleteOptionSyncAnalysisEmit'>
        </tal-question-options>

        <!-- 答案组件 -->
        <tal-question-answer
        :inputAnswer='questionData.body.answer.items'>
        </tal-question-answer>

        <!-- 解析组件 -->
        <tal-question-analysis
        ref="questionAnalysis"
        :inputOptionsCount='computedOptionsCount'
        :inputQuestionType='inputQuestion.type'
        :inputAnalysisData='inputQuestion.body.analysis'
        @anaysisObjectChangeEmit='anaysisObjectChangeEmit'>
        </tal-question-analysis>
    </div>
</template>

<script>
import { Question, QuestionTypeCollection } from '@/common/constant'
import { stringIsEmpty } from '@/common/common'
import TalQuestionStemBody from '@/components/tal/TalQuestionStemBody'
import TalQuestionOptions from '@/components/tal/TalQuestionOptions'
import TalQuestionAnswer from '@/components/tal/TalQuestionAnswer'
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'
export default {
    components: {
        TalQuestionStemBody,
        TalQuestionOptions,
        TalQuestionAnswer,
        TalQuestionAnalysis
    },
    props: {
        inputQuestion: {
            type: Object,
            default: function () {
                return {
                    type: Question.MulChoice.type,
                    body: {
                        stem: {
                            body: '',
                            options: {
                                A: '',
                                B: '',
                                C: '',
                                D: ''
                            }
                        },
                        answer: {
                            type: QuestionTypeCollection.AnswerType.Letters,
                            items: ''
                        },
                        analysis: {
                            enabled: 1,
                            type: QuestionTypeCollection.AnalysisType.Content,
                            detail: {
                                1: ''
                            }
                        }
                    }
                }
            }
        }
    },
    data () {
        return {
            questionData: {
                type: Question.MulChoice.type,
                body: {
                    stem: {
                        body: '',
                        options: {
                            A: '',
                            B: '',
                            C: '',
                            D: ''
                        }
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Letters,
                        items: ''
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {
                            1: ''
                        }
                    }
                }
            },
            // 存储题型的各种错误
            questionError: {
                isError: false,
                message: []
            }
        }
    },
    created () {
        this.$emit('initQuestionEmit', this.outputQuestionObject())
    },
    methods: {
        /* emit */
        /* TalQuestionStemBody emit */
        textChangeEmit: function () {
            let body = this.$refs.questionStemBody.outputText()
            this.$set(this.questionData.body.stem, 'body', body)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionOption emit */
        answerObjectChangeEmit: function () {
            let answer = this.$refs.questionOptions.outputAnswerObject()
            this.$set(this.questionData.body, 'answer', answer)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        optionObjectChangeEmit: function () {
            let options = this.$refs.questionOptions.outputOptionObject()
            this.$set(this.questionData.body.stem, 'options', options)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        allChangeEmit: function () {
            let answer = this.$refs.questionOptions.outputAnswerObject()
            let options = this.$refs.questionOptions.outputOptionObject()
            this.$set(this.questionData.body, 'answer', answer)
            this.$set(this.questionData.body.stem, 'options', options)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        deleteOptionSyncAnalysisEmit: function (index) {
            // // 只有是按选项解析的时候才会触发
            // if (this.questionData.body.analysis.type !== QuestionTypeCollection.AnalysisType.Opt) return
            // // index 代表选项删除的是第几个
            // // 为了不影响当前的question对象，深度复制一个
            // let tmpAnalysisDetail = JSON.parse(JSON.stringify(this.questionData.body.analysis.detail))
            // var key = Object.keys(tmpAnalysisDetail).filter((curVal, temIndex) => {
            //     return temIndex === index
            // })
            // // 根据选项是删除的第几个从而删除按选项解析的第几个
            // delete tmpAnalysisDetail[key[0]]
            // let analysis = {
            //     enabled: 1,
            //     type: QuestionTypeCollection.AnalysisType.Opt,
            //     detail: tmpAnalysisDetail
            // }
            // 获取当前题型中detail， 并清空
            let detail = {}
            for (let key in this.questionData.body.analysis.detail) {
                detail[key] = ''
            }
            this.$set(this.questionData.body.analysis, 'detail', detail)
            this.$bus.$emit('refreshAnalysis', this.questionData.body.analysis)
        },
        /* TalQuestionAnalysis emit */
        anaysisObjectChangeEmit: function () {
            let analysis = this.$refs.questionAnalysis.outputAnalysisObject()
            this.$set(this.questionData.body, 'analysis', analysis)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* output */
        outputQuestionObject: function () {
            return this.questionData
        },
        /* private */
        // 验证题干是否符合提交标准
        privateVerifyQuestionStem: function (stem) {
            if (!stringIsEmpty(stem)) {
                this.questionError.isError = true
                this.questionError.message.push('题干内容不能为空，请完善题干内容')
            }
        },
        // 验证选项
        privateVerifyQuestionOptions: function (options) {
            for (let key in options) {
                if (!stringIsEmpty(options[key])) {
                    this.questionError.isError = true
                    this.questionError.message.push(`选项${key}不能为空,请完善选项内容`)
                }
            }
        },
        // 验证答案  未选择答案或者只选择一个答案的情况下报错
        privateVerifyQuestionAnswer: function (answer) {
            // 直接检验字符串的长度，如果为0,则答案为空，如果为1，则只选择了一个答案
            if (answer.length === 0) {
                this.questionError.isError = true
                this.questionError.message.push('答案不能为空，请完善答案内容')
            } else if (answer.length === 1) {
                this.questionError.isError = true
                this.questionError.message.push('答案个数不足，请至少选择2个答案')
            }
        },
        // 验证解析
        privateVerifyQuestionAnalysis: function (analysis) {
            // 只有在选中 需要解析的时候才会进行下列操作
            if (analysis.enabled) {
                // 分两种情况，按选项（小题）解析和按方法解析
                if (analysis.type === QuestionTypeCollection.AnalysisType.Content) {
                    for (let key in analysis.detail) {
                        if (!stringIsEmpty(analysis.detail[key])) {
                            this.questionError.isError = true
                            this.questionError.message.push('解析不能为空，请完善解析内容')
                            return
                        }
                    }
                } else if (analysis.type === QuestionTypeCollection.AnalysisType.Opt) {
                    for (let key in analysis.detail) {
                        if (!stringIsEmpty(analysis.detail[key])) {
                            this.questionError.isError = true
                            this.questionError.message.push('选项解析不能为空，请完善解析内容')
                            return
                        }
                    }
                }
            }
        },
        /* public */
        checkQuestionError: function () {
            console.log('我是多选题的校验')
            let questionError = []

            let questionOptionsErrorArray = this.$refs.questionOptions.verifyQuestionOptions()
            let questionAnswerErrorArray = this.$refs.questionOptions.verifyQuestionAnswer()
            let questionStemBodyErrorArray = this.$refs.questionStemBody.verifyQuestionStemBody()
            let questionAnalysisErrorArray = this.$refs.questionAnalysis.verifyQuestionAnalysis()

            questionError = [...questionStemBodyErrorArray,
                             ...questionOptionsErrorArray,
                             ...questionAnswerErrorArray,
                             ...questionAnalysisErrorArray]

            return questionError
        }
    },
    computed: {
        computedOptionsCount: function () {
            return Object.keys(this.questionData.body.stem.options).length
        }
    },
    watch: {
        // 监听一键复制
        inputQuestion: function (newVal) {
            this.questionData = JSON.parse(JSON.stringify(newVal))
        }
    }
}
</script>

