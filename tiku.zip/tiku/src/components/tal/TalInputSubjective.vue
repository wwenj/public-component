<template>
    <div>
        <!-- 题干组件 -->
        <tal-question-stem-body
        ref="questionStemBody"
        :inputText="inputQuestion.body.stem.body"
        @textChangeEmit='textChangeEmit'>
        </tal-question-stem-body>

        <!-- 答案组件 -->
        <tal-question-subjective-answer
        ref="questionAnswer"
        :inputAnswerData="inputQuestion.body.answer"
        @subjectiveAnswerEmit="subjectiveAnswerEmit">
        </tal-question-subjective-answer>

        <!-- 解析组件 -->
        <tal-question-analysis
        ref="questionAnalysis"
        :inputQuestionType="inputQuestion.type"
        :inputAnalysisData="inputQuestion.body.analysis"
        @anaysisObjectChangeEmit='anaysisObjectChangeEmit'>
        </tal-question-analysis>
    </div>
</template>
<script>
import TalQuestionSubjectiveAnswer from '@/components/tal/TalQuestionSubjectiveAnswer'
import TalQuestionStemBody from '@/components/tal/TalQuestionStemBody'
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'
import { Question, QuestionTypeCollection } from '@/common/constant'

export default {
    components: {
        TalQuestionStemBody,
        TalQuestionSubjectiveAnswer,
        TalQuestionAnalysis
    },
    props: {
        // 题目信息数据，父组件传递,一键复制vuex
        inputQuestion: {
            type: Object,
            default: function () {
                return {
                    type: Question.Subjective.type, // 解答题type
                    body: {
                        stem: {
                            body: '',
                            options: {}
                        },
                        answer: {
                            type: QuestionTypeCollection.AnswerType.Content,
                            items: ''
                        },
                        analysis: {
                            enabled: 1,
                            type: QuestionTypeCollection.AnalysisType.Content,
                            detail: {
                                '1': ''
                            }
                        }
                    }
                }
            }
        }
    },
    created () {
        this.$emit('initQuestionEmit', this.outputQuestionObject())
    },
    data () {
        return {
            questionData: {
                type: Question.Subjective.type, // 解答题type
                body: {
                    stem: {
                        body: '',
                        options: {}
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Content,
                        items: ''
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {
                            '1': ''
                        }
                    }
                }
            }
        }
    },
    methods: {
        /* TalQuestionAnalysis emit */
        anaysisObjectChangeEmit: function () {
            this.questionData.body.analysis = this.$refs.questionAnalysis.outputAnalysisObject()
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionSubjectiveAnswer emit */
        subjectiveAnswerEmit: function (answer) {
            this.questionData.body.answer = answer
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionStemBody emit */
        textChangeEmit: function () {
            this.questionData.body.stem.body = this.$refs.questionStemBody.outputText()
            console.log(this.questionData.body.stem.body)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* output */
        outputQuestionObject: function () {
            // let question = {}
            // question.type = Question.Subjective.type
            // question.body = {
            //     stem: {
            //         body: this.questionData.stem.body,
            //         options: {}
            //     },
            //     answer: this.questionData.answer,
            //     analysis: this.questionData.analysis
            // }
            // return question
            return this.questionData
        },
        /* public */
        // 保存报错接口函数
        checkQuestionError: function () {
            let questionError = []

            let questionStemBodyErrorArray = this.$refs.questionStemBody.verifyQuestionStemBody()
            let questionAnswerErrorArray = this.$refs.questionAnswer.verifyQuestionAnswer()
            let questionAnalysisErrorArray = this.$refs.questionAnalysis.verifyQuestionAnalysis()

            questionError = [...questionStemBodyErrorArray,
                             ...questionAnswerErrorArray,
                             ...questionAnalysisErrorArray]

            return questionError
        }
    },
    watch: {
        inputQuestion: function (newval) {
            console.log('解答题watch', newval)
            this.questionData = JSON.parse(JSON.stringify(newval))
        }
    }
}
</script>
<style lang="scss" scoped>
</style>

