<template>
    <div class="stem">
        <div class="title">题干</div>
        <span class="info-text">说明:富文本编辑器支持截图图片粘贴上传，图片文件拖拽上传</span>
        <editor @editorEmit='editorEmit' :inputText='inputText'></editor>
    </div>

</template>
<script>
import { stringIsEmpty } from '@/common/common'
export default {
    props: {
        // 输入的文本
        inputText: {
            type: String,
            default: ''
        }
    },
    data () {
        return {
            text: this.inputText
        }
    },
    computed: {
    },
    methods: {
        /* action */
        /* editor emit */
        // 富文本编辑器失焦返回
        editorEmit: function (data) {
            this.text = data.text
            // 每次富文本编辑器失焦就向父组件返回操作
            this.$emit('textChangeEmit', data)
        },
        /* public */
        refresh: function (text) {
            this.privateInitData(text)
        },
        verifyQuestionStemBody: function () {
            let questionErrorArray = []
            if (!stringIsEmpty(this.text)) {
                questionErrorArray.push('题干内容不能为空，请完善题干内容')
            }
            return questionErrorArray
        },
        /* output */
        // 父组件预留操作函数，便于获取子组件数据
        outputText: function () {
            return this.text
        },
        /* private */
        privateInitData: function (text) {
            this.text = text
        }
    }
    // watch: {
    //     inputText: function (newval, oldval) {
    //         this.text = newval
    //     }
    // }
}
</script>

<style lang="scss" scoped>
    .stem {
        margin-bottom: 33px;
    }
</style>
