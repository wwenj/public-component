<template>
    <div class="cloze-wrapper">
        <!-- 题干组件 -->
        <tal-question-stem-body
        ref='questionStemBody'
        :inputText='inputQuestion.body.stem.body'
        @textChangeEmit='textChangeEmit'>
        </tal-question-stem-body>

        <!-- 选项组件 -->
        <tal-question-cloze-options
        ref="questionOptions"
        :inputOptionsObject='inputQuestion.body.stem.options'
        :inputAnswerObject='inputQuestion.body.answer.items'
        @addOptionObjectEmit='addOptionObjectEmit'
        @deleteOptionObjectEmit='deleteOptionObjectEmit'
        @answerObjectChangeEmit='answerObjectChangeEmit'>
        </tal-question-cloze-options>

        <!-- 答案组件 -->
        <tal-question-cloze-answer
        ref="questionAnswer"
        :inputOptionsCount='computedOptionsCount'
        :inputAnswerObject='inputQuestion.body.answer.items'
        @clozeAnswerObjectChangeEmit='clozeAnswerObjectChangeEmit'>
        </tal-question-cloze-answer>

        <!-- 解析组件 -->
        <tal-question-analysis
        ref="questionAnalysis"
        :inputOptionsCount='computedOptionsCount'
        :inputQuestionType='inputQuestion.type'
        :inputAnalysisData='inputQuestion.body.analysis'
        @anaysisObjectChangeEmit='anaysisObjectChangeEmit'>
        </tal-question-analysis>
    </div>
</template>

<script>
import { QuestionTypeCollection, Question } from '@/common/constant'
import TalQuestionStemBody from '@/components/tal/TalQuestionStemBody'
import TalQuestionClozeOptions from '@/components/tal/TalQuestionClozeOptions'
import TalQuestionClozeAnswer from '@/components/tal/TalQuestionClozeAnswer'
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'
export default {
    components: {
        TalQuestionStemBody,
        TalQuestionClozeOptions,
        TalQuestionClozeAnswer,
        TalQuestionAnalysis
    },
    props: {
        inputQuestion: {
            type: Object,
            default () {
                return {
                    type: Question.Cloze.type,
                    body: {
                        stem: {
                            body: '',
                            options: {
                                1: {
                                    A: '',
                                    B: '',
                                    C: '',
                                    D: ''
                                },
                                2: {
                                    A: '',
                                    B: '',
                                    C: '',
                                    D: ''
                                },
                                3: {
                                    A: '',
                                    B: '',
                                    C: '',
                                    D: ''
                                },
                                4: {
                                    A: '',
                                    B: '',
                                    C: '',
                                    D: ''
                                },
                                5: {
                                    A: '',
                                    B: '',
                                    C: '',
                                    D: ''
                                },
                                6: {
                                    A: '',
                                    B: '',
                                    C: '',
                                    D: ''
                                }
                            }
                        },
                        answer: {
                            type: QuestionTypeCollection.AnswerType.Pair,
                            items: {
                                1: '',
                                2: '',
                                3: '',
                                4: '',
                                5: '',
                                6: ''
                            }
                        },
                        analysis: {
                            enabled: 1,
                            type: QuestionTypeCollection.AnalysisType.Content,
                            detail: {
                                1: ''
                            }
                        }
                    }
                }
            }
        }
    },
    data () {
        return {
            questionData: {
                type: Question.Cloze.type,
                body: {
                    stem: {
                        body: '',
                        options: {
                            1: {
                                A: '',
                                B: '',
                                C: '',
                                D: ''
                            },
                            2: {
                                A: '',
                                B: '',
                                C: '',
                                D: ''
                            },
                            3: {
                                A: '',
                                B: '',
                                C: '',
                                D: ''
                            },
                            4: {
                                A: '',
                                B: '',
                                C: '',
                                D: ''
                            },
                            5: {
                                A: '',
                                B: '',
                                C: '',
                                D: ''
                            },
                            6: {
                                A: '',
                                B: '',
                                C: '',
                                D: ''
                            }
                        }
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Pair,
                        items: {
                            1: '',
                            2: '',
                            3: '',
                            4: '',
                            5: '',
                            6: ''
                        }
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {
                            1: ''
                        }
                    }
                }
            }
        }
    },
    created () {
        this.$emit('initQuestionEmit', this.outputQuestionObject())
    },
    methods: {
        /* TalQuestionStemBody emit */
        textChangeEmit: function () {
            let body = this.$refs.questionStemBody.outputText()
            this.$set(this.questionData.body.stem, 'body', body)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionClozeOptions */
        addOptionObjectEmit: function () {
            let optionsObject = this.$refs.questionOptions.outputOptionsObject()
            this.$set(this.questionData.body.stem, 'options', optionsObject)

            let answerObject = this.$refs.questionOptions.outputAnswerObject()
            this.$set(this.questionData.body.answer, 'items', answerObject)
            this.$refs.questionAnswer.refresh(this.questionData.body.answer.items)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        deleteOptionObjectEmit: function () {
            let optionsObject = this.$refs.questionOptions.outputOptionsObject()
            this.$set(this.questionData.body.stem, 'options', optionsObject)

            let answerObject = this.$refs.questionOptions.outputAnswerObject()
            this.$set(this.questionData.body.answer, 'items', answerObject)
            this.$refs.questionAnswer.refresh(this.questionData.body.answer.items)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        answerObjectChangeEmit: function () {
            let answerObject = this.$refs.questionOptions.outputAnswerObject()
            this.$set(this.questionData.body.answer, 'items', answerObject)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionClozeAnswer emit */
        clozeAnswerObjectChangeEmit: function () {
            let answerObject = this.$refs.questionAnswer.outputAnswerObject()
            this.$set(this.questionData.body.answer, 'items', answerObject)

            this.$refs.questionOptions.refreshAnswerObject(answerObject)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionAnalysis emit */
        anaysisObjectChangeEmit: function () {
            let analysis = this.$refs.questionAnalysis.outputAnalysisObject()
            this.$set(this.questionData.body, 'analysis', analysis)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* public */
        checkQuestionError: function () {
            console.log('这是完型填空的校验')
            let questionError = []

            let questionStemBodyErrorArray = this.$refs.questionStemBody.verifyQuestionStemBody()
            let questionOptionsErrorArray = this.$refs.questionOptions.verifyQuestionOptions()
            let questionAnswerErrorArray = this.$refs.questionAnswer.verifyQuestionAnswer()
            let questionAnalysisErrorArray = this.$refs.questionAnalysis.verifyQuestionAnalysis()

            questionError = [...questionStemBodyErrorArray,
                             ...questionOptionsErrorArray,
                             ...questionAnswerErrorArray,
                             ...questionAnalysisErrorArray]

            return questionError

            // return ['完型填空题校验未完成']
        },
        /* output */
        outputQuestionObject: function () {
            return this.questionData
        }
    },
    computed: {
        computedOptionsCount: function () {
            return Object.keys(this.questionData.body.stem.options).length
        }
    }
}
</script>

<style lang="scss" scoped>

</style>
