<template>
    <div class="small-question-wrapper">
        <div class="my-title">
            <div>
                <img class='title-img' src="@/assets/img/recording/small-question-title-icon.png" alt="icon" width="11" height="15">
                {{privateSmallQuestionTitle()}}
            </div>
            <div class="select-wrapper">
                <select v-model="questionType" @change="questionTypeOnChange">
                    <option value=0 selected disabled>请选择</option>
                    <option v-for="(question, key, index) in getQuestionTypeArray()" :value="question.component" :key="index">
                        {{question.chineseName}}
                    </option>
                </select>
            </div>
            <div class="button-wrapper">
                <img src="@/assets/img/recording/up-btn.png" alt="↑" width="13" height="16" @click="upOnClick" v-if="!computedUpButtonIsDisabled">
                <img src="@/assets/img/recording/up-btn-disabled.png" alt="↑" width="13" height="16" v-else>
                <img src="@/assets/img/recording/down-btn.png" alt="↓" width="13" height="16" @click="downOnClick" v-if="!computedDownButtonIsDisabled">
                <img src="@/assets/img/recording/down-btn-disabled.png" alt="↓" width="13" height="16" v-else>
                <img src="@/assets/img/recording/del.png" alt="" @click="delQuestionOnClick">
            </div>
        </div>
        <component
        :inputQuestion='question'
        @questionChangeEmit="questionChangeEmit"
        @initQuestionEmit='initQuestionEmit'
        :is="questionType"
        ref="smallQuestionItemRef">
        </component>
    </div>

</template>

<script>
import { Question } from '@/common/constant'
export default {
    props: {
        inputIndex: {
            type: Number,
            default: 1
        },
        inputCurrentQuestionCount: {
            type: Number,
            default: 1
        },
        inputQuestionType: {
            type: String,
            default: ''
        },
        inputQuestion: {
            type: Object,
            default () {
                return {}
            }
        }
    },
    data () {
        return {
            Question,
            questionType: this.inputQuestionType ? this.inputQuestionType : 0,
            // 向组件内传递 题目信息
            question: undefined
        }
    },
    mounted () {
        // question变量是直接向 题型动态组件中传递的数据
        // 为什么不直接用inputQuestion？
        // 因为在点击一键复制的时候，题型组件还没有生成
        // 点击一键复制以后，动态组件初始化，inputQuestion被传入组件，但是此时watch不监听
        // 所以需要等 动态组件初始化完成以后，再通过props向里面传值
        this.$nextTick(() => {
            this.question = this.inputQuestion
        })

        // this.question = this.inputQuestion
        // console.log('this.inputQuestion', this.inputQuestion)
    },
    methods: {
        /* action */
        questionTypeOnChange: function (e) {
            this.question = undefined
            this.$nextTick(function () {
                let question = this.$refs.smallQuestionItemRef.outputQuestionObject()
                let data = {
                    question: JSON.parse(JSON.stringify(question)),
                    index: this.inputIndex
                }
                this.$emit('initSmallQuestionEmit', data)
            })
        },
        delQuestionOnClick: function () {
            this.$emit('delQuestionEmit', this.inputIndex)
        },
        upOnClick: function () {
            this.$emit('upEmit', this.inputIndex)
        },
        downOnClick: function () {
            this.$emit('downEmit', this.inputIndex)
        },
        /* 动态组件 component emit */
        initQuestionEmit: function (question) {
            // 初始化时需要
            // console.log('初始化完成1')
            // this.question = JSON.parse(JSON.stringify(question))
            // console.log('this.inputQuestion', this.inputQuestion)
            // if (Object.keys(this.inputQuestion).length !== 0) {
            //     console.log('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa===============')
            //     // 上下移动时时需要
            //     this.question = this.inputQuestion
            // }
        },
        questionChangeEmit: function (question) {
            console.log(this.questionType)
            console.log('question', question)
            let data = {
                question: question,
                index: this.inputIndex
            }
            this.$emit('changeSmallQuestionEmit', data)
        },
        /* private */
        privateSmallQuestionTitle: function () {
            return '小题' + (this.inputIndex + 1)
        },
        // 获取正确下拉列表数据
        getQuestionTypeArray: function () {
            var result = []
            for (var key in this.Question) {
                if (
                    this.Question[key].type !== this.Question.Unknown.type &&
                    this.Question[key].type !== this.Question.Complex.type
                ) {
                    result.push(this.Question[key])
                }
            }
            return result
        }
    },
    computed: {
        computedUpButtonIsDisabled () {
            return this.inputIndex === 0
        },
        computedDownButtonIsDisabled () {
            return this.inputIndex === this.inputCurrentQuestionCount - 1
        }
    }
}
</script>
<style lang="scss" scoped>
.small-question-wrapper {
    margin-bottom: 30px;
    // padding-bottom: 15px;
    // border-bottom: 1px solid #dcdcdc;
    .my-title {
        position: relative;
        display: flex;
        flex-direction: row;
        width: 100%;
        height: 50px;
        margin: 30px 0;
        line-height: 50px;
        background: rgba(131,138,155, .2);
        font-size: 16px;
        color: #3e4c89;
        .title-img {
            vertical-align: -3%;
            margin-left: 10px;
        }
        .select-wrapper {
            margin-left: 20px;
            select {
                border-radius: 4px;
            }
        }
        .button-wrapper {
            position: absolute;
            top: 0;
            right: 30px;
            img:nth-child(2) {
                margin: 0 20px;
            }
        }
    }
}
</style>

