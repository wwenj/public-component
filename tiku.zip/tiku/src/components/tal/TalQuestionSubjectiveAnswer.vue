<template>
    <div class="subjectiveAnswer">
        <div class="title">答案</div>
        <editor @editorEmit='editorCallBack' :inputText="inputText"></editor>
    </div>
</template>
<script>
import { stringIsEmpty } from '@/common/common'
import { QuestionTypeCollection } from '@/common/constant'
export default {
    // 本组件用emit自定义事件向父组件返回一个数据
    props: {
        // 父组件传递用于文本渲染
        inputAnswerData: {
            type: Object,
            default: () => {}
        }
    },
    data () {
        return {
            inputText: '',
            outputText: ''
        }
    },
    created () {
        this.answerData = this.inputAnswerData.items
    },
    methods: {
        /* editor emit */
        editorCallBack: function (html) {
            let answer = {
                type: QuestionTypeCollection.AnswerType.Content,
                items: html.text
            }
            this.outputText = html.text
            this.$emit('subjectiveAnswerEmit', answer)
        },
        /* public */
        verifyQuestionAnswer: function () {
            if (!stringIsEmpty(this.outputText)) {
                return ['答案不能为空，请完善答案内容']
            }
            return []
        }
    },
    watch: {
        inputAnswerData: {
            handler: function (newVal) {
                console.log('解答题答案watch')
                this.inputText = newVal.items
                this.outputText = newVal.items
            },
            deep: true
        }
    }
}
</script>
<style lang="scss" scoped>
.subjectiveAnswer {
    margin-bottom: 30px;
    .title {
        margin: 30px 0;
    }
}
</style>


