<template>
    <div class="options">
        <ul>
            <li class="optionsList" v-for="(option, index) in optionArray" :key="option.id">
                <!-- v-show 与 v-if的区别 https://www.cnblogs.com/Rexxar/p/5578441.html -->
                <div v-if="index < currentCount">
                    <button :class="[privateGetOptionSelectClassNameByIndex(index)]" :disabled="!computedCanOptionTitleButtonEnable" @click="answerOnClick(index)">{{ privateGetOptionTitleWithIndex(index) }}</button>
                    <editor :inputDelButtonShow="false" :inputIndex="index" @editorEmit='editorGetHtml' :inputText='option.text'></editor>
                    <img src="@/assets/img/recording/del.png" alt="del" @click="deleteOnClick(index)">
                </div>
            </li>
        </ul>
        <button class="add-btn" @click="addOnClick" :disabled="!computedCanAddNewOptions">
            <img src="@/assets/img/recording/add.png" alt="">
            <span>更多选项</span>
        </button>
    </div>

</template>
<script>
import { QuestionTypeCollection, Question } from '@/common/constant'
export default {
    props: {
        // 控制初始显示选项个数，从0开始默认为4个
        inputCurrentCount: {
            type: Number,
            default: 4
        },
        // 选项能增加的最大数量，默认为10
        inputMaxCount: {
            type: Number,
            default: 10
        },
        // 选项删除剩余的最小数量，默认为2
        inputMinCount: {
            type: Number,
            default: 2,
            validator: function (value) {
                // 这个会报错
                // return value <= this.inputMaxCount
                return value <= 100
            }
        },
        // 题目类型
        // 目前支持如下4种
        // 单选,多选,多选多,排序
        inputQuestionType: {
            type: Number,
            default: Question.SingleChoice.type,
            validator: function (value) {
                return value === Question.SingleChoice.type ||
                        value === Question.MulChoice.type ||
                        value === Question.MulChoiceMul.type ||
                        value === Question.Sort.type
            }
        },
        // 录入的选项
        inputOptionObject: {
            type: Object,
            default () {
                return {

                }
            }
        },
        // 输入的答案
        inputAnswerObject: {
            type: Object,
            default () {
                return {
                    type: QuestionTypeCollection.AnswerType.Letters,
                    items: ''
                }
            }
        }
    },
    data () {
        return {
            currentCount: this.inputCurrentCount, // 选项显示个数
            answerArray: [], // 选择的答案列表
            optionArray: [] // 渲染选项的数组结构
        }
    },
    computed: {
        // 是否可以添加新的选项
        computedCanAddNewOptions () {
            return this.currentCount < this.inputMaxCount
        },
        // 选项标题按钮是否可被点击
        computedCanOptionTitleButtonEnable () {
            let result = this.inputQuestionType === Question.SingleChoice.type || this.inputQuestionType === Question.MulChoice.type
            return result
        }
    },
    created () {
        this.privateInitData(this.inputOptionObject, this.inputAnswerObject)
    },
    mounted () {
    },
    methods: {
        /* action */
        // 增加选项
        addOnClick: function () {
            let optionArrayLength = this.optionArray.length
            if (this.currentCount === optionArrayLength) {
                alert(`最多添加${this.inputMaxCount}个选项哦！`)
            } else {
                this.currentCount += 1
            }
            this.$emit('allChangeEmit')
        },
        // 删除选项
        deleteOnClick: function (index) {
            console.log('index', index)
            if (this.currentCount === this.inputMinCount) {
                alert(`最少剩余${this.inputMinCount}个选项哦！`)
            } else {
                // 更新选项数据
                let deleteOptionArray = this.optionArray.splice(index, 1)
                let deleteOption = deleteOptionArray[0]
                deleteOption.text = '<br/>'
                this.optionArray.push(deleteOption)
                this.currentCount -= 1
                // 更新答案数据,每当删除一条数据的时候,清空所有答案
                this.answerArray = []
                this.$emit('allChangeEmit')
            }
        },
        // 点击选项前字符返回选中答案
        answerOnClick: function (index) {
            this.answerArray = [index]
            // 每次改变答案都会向父组件返回操作
            this.$emit('answerObjectChangeEmit')
        },
        /* emit */
        // 富文本编辑器失焦返回
        editorGetHtml: function (data) {
            let text = data.text
            let index = data.index
            let option = this.optionArray[index]
            option.text = text
            // 每次富文本编辑器失焦就向父组件返回操作
            this.$emit('optionObjectChangeEmit')
        },
        /* public */
        refresh: function (optionObject, answerObject) {
            this.privateInitData(optionObject, answerObject)
        },
        /* output */
        // 父组件预留操作函数，便于获取子组件数据
        outputOptionObject: function () {
            let option = {}
            for (let i = 0; i < this.currentCount; i++) {
                let item = this.optionArray[i]
                let text = item.text
                let key = this.privateGetOptionKeyWithIndex(i)
                option[key] = text
            }
            return option
        },
        outputAnswerObject: function () {
            let answerTitleArray = []
            let answerArrayLength = this.answerArray.length
            for (let i = 0; i < answerArrayLength; i++) {
                let index = this.answerArray[i]
                let title = this.privateGetOptionKeyWithIndex(index)
                answerTitleArray.push(title)
            }
            let answerItems = answerTitleArray.join('')
            let answer = {
                type: this.inputAnswerObject.type,
                items: answerItems
            }
            return answer
        },
        outputCount: function () {
            return this.currentCount
        },
        /* private */
        // 计算选项的标题,
        privateGetOptionTitleWithIndex (index) {
            let title = String.fromCharCode(65 + index)
            if (!this.computedCanOptionTitleButtonEnable) {
                title = title + '.'
            }
            return title
        },
        privateGetOptionKeyWithIndex (index) {
            return String.fromCharCode(65 + index)
        },
        privateGetIndexWithOptionTitle (title) {
            // 将来可以根据类型进行switch,case
            return title.charCodeAt() - 65
        },
        // 得到按钮的样式
        privateGetOptionSelectClassNameByIndex (index) {
            if (!this.computedCanOptionTitleButtonEnable) {
                return 'btn-disable'
            }
            let answerArrayLength = this.answerArray.length
            for (let i = 0; i < answerArrayLength; i++) {
                let value = this.answerArray[i]
                if (value === index) {
                    return 'btn btn-active'
                }
            }
            return 'btn'
        },
        privateInitData (optionObject, answerObject) {
            // 先置空
            this.optionArray = []
            this.answerArray = []
            // 获取选项数组
            let tmpOptionArray = []
            for (let key in optionObject) {
                let value = optionObject[key]
                tmpOptionArray.push(value)
            }
            let tmpOptionArrayLength = tmpOptionArray.length
            for (let i = 0; i < this.inputMaxCount; i++) {
                let text = '<br/>'
                if (i < tmpOptionArrayLength) {
                    text = tmpOptionArray[i]
                }
                let value = {
                    // 这个id是用于Dom重新加载用的v-key,跟选项的顺序没有对应关系
                    // 因为我们有可能删除选项或者添加选项
                    id: i,
                    // 这个还是一个问题,需要调查
                    text: text
                }
                this.optionArray.push(value)
            }
            // 获取答案数组
            let items = answerObject.items
            let answerTitleArray = items.split('')
            let answerTitleArrayLength = answerTitleArray.length
            for (let i = 0; i < answerTitleArrayLength; i++) {
                let title = answerTitleArray[i]
                let index = this.privateGetIndexWithOptionTitle(title)
                this.answerArray.push(index)
            }
        }
    }
}
</script>
<style lang="scss" scoped>
.btn-active {
    background: #6e86fd;
}
.optionsList {
    margin-bottom: 20px;
}
.btn-disable {
    width: 36px;
    height: 36px;
    margin-right: 20px;
    font-family: "MicrosoftYaHei" sans-serif;
    font-size: 16px;
    color: #5f7aff;
    background-color: #f5f6f8;
    border-radius: 4px;
    border: solid 0px #5f7aff;
    outline: none;
}
.btn {
    width: 36px;
    height: 36px;
    margin-right: 20px;
    font-family: "MicrosoftYaHei" sans-serif;
    font-size: 16px;
    color: #5f7aff;
    background-color: #f5f6f8;
    border-radius: 4px;
    border: solid 1px #5f7aff;
    outline: none;
}
.btn-active {
    background-color: #6e86fd;
    color: #fff;
}
.add-btn {
    width: 110px;
    height: 36px;
    border-radius: 17px;
    color: #6e86fd;
    outline: none;
    background-clip: padding-box, border-box;
    background-origin: padding-box, border-box;
    background-image: linear-gradient(135deg, #f5f6f8, #f5f6f8),
        linear-gradient(135deg, #6e86fd, #6ac1fe);
    border: 1px transparent solid;
    cursor: pointer;

    img {
        width: 12px;
        height: 12px;
        vertical-align: middle;
    }
    span {
        vertical-align: middle;
        font-size: 14px;
    }
}
</style>



