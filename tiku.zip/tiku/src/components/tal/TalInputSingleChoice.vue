
<template>
    <!-- 尽量不要让父组件的一个值绑定子组件,我们都是通过调用子组件的刷新函数 -->
    <div class="choose">
        <!-- 题干组件 -->
        <tal-question-stem-body
        :inputText="inputQuestion.body.stem.body"
        ref="questionStemBody"
        @textChangeEmit='textChangeEmit'>
        </tal-question-stem-body>

        <!-- 选项组件 -->
        <tal-question-options
        class="options"
        ref="questionOptions"
        :inputOptionObject="inputQuestion.body.stem.options"
        :inputAnswerObject="inputQuestion.body.answer"
        :inputCurrentCount='computedOptionsCount'
        :inputQuestionType="inputQuestion.type"
        @optionObjectChangeEmit='optionObjectChangeEmit'
        @answerObjectChangeEmit='answerObjectChangeEmit'
        @allChangeEmit='allChangeEmit'
        @deleteOptionSyncAnalysisEmit='deleteOptionSyncAnalysisEmit'>
        </tal-question-options>

        <!-- 答案组件 -->
        <!-- 我希望答案组件实时更新，所以用questionData, 一键复制时，questionData同inputQuestion -->
        <tal-question-answer
        :inputAnswer='questionData.body.answer.items'>
        </tal-question-answer>

        <!-- 解析组件 -->
        <tal-question-analysis
        ref="questionAnalysis"
        :inputOptionsCount='computedOptionsCount'
        :inputQuestionType="inputQuestion.type"
        :inputAnalysisData="inputQuestion.body.analysis"
        @anaysisObjectChangeEmit='anaysisObjectChangeEmit'>
        </tal-question-analysis>

    </div>
</template>

<script>
import { Question, QuestionTypeCollection } from '@/common/constant'
import TalQuestionStemBody from '@/components/tal/TalQuestionStemBody'
import TalQuestionOptions from '@/components/tal/TalQuestionOptions'
import TalQuestionAnswer from '@/components/tal/TalQuestionAnswer'
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'
export default {
    components: {
        TalQuestionStemBody,
        TalQuestionOptions,
        TalQuestionAnswer,
        TalQuestionAnalysis
    },
    props: {
        // 题目信息数据，父组件传递,一键复制vuex
        inputQuestion: {
            type: Object,
            default: function () {
                return {
                    type: Question.SingleChoice.type,
                    body: {
                        stem: {
                            body: '',
                            options: {
                                A: '',
                                B: '',
                                C: '',
                                D: ''
                            }
                        },
                        answer: {
                            type: QuestionTypeCollection.AnswerType.Letters,
                            items: ''
                        },
                        analysis: {
                            enabled: 1,
                            type: QuestionTypeCollection.AnalysisType.Content,
                            detail: {
                                '1': ''
                            }
                        }
                    }
                }
            }
        }
    },
    created () {
        this.$emit('initQuestionEmit', this.outputQuestionObject())
        // console.log('singlechoice mounted', this.inputQuestion)
    },
    data () {
        return {
            questionData: {
                type: Question.SingleChoice.type,
                body: {
                    stem: {
                        body: '',
                        options: {
                            A: '',
                            B: '',
                            C: '',
                            D: ''
                        }
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Letters,
                        items: ''
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {
                            '1': ''
                        }
                    }
                }
            }
        }
    },
    methods: {
        /* TalQuestionStemBody emit */
        textChangeEmit: function () {
            let body = this.$refs.questionStemBody.outputText()
            this.$set(this.questionData.body.stem, 'body', body)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionOptions emit */
        optionObjectChangeEmit: function () {
            let options = this.$refs.questionOptions.outputOptionObject()
            this.$set(this.questionData.body.stem, 'options', options)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        answerObjectChangeEmit: function () {
            let answer = this.$refs.questionOptions.outputAnswerObject()
            this.$set(this.questionData.body, 'answer', answer)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        allChangeEmit: function () {
            // 更新数据
            let options = this.$refs.questionOptions.outputOptionObject()
            this.$set(this.questionData.body.stem, 'options', options)
            let answer = this.$refs.questionOptions.outputAnswerObject()
            this.$set(this.questionData.body, 'answer', answer)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        deleteOptionSyncAnalysisEmit: function (index) {
            /** 以下注释掉的 功能： 实现删除第几个选项则删除第几个选项解析 */

            // // 只有是按选项解析的时候才会触发
            // if (this.questionData.body.analysis.type !== QuestionTypeCollection.AnalysisType.Opt) return
            // // index 代表选项删除的是第几个
            // // 为了不影响当前的question对象，深度复制一个
            // let tmpAnalysisDetail = JSON.parse(JSON.stringify(this.questionData.body.analysis.detail))
            // var key = Object.keys(tmpAnalysisDetail).filter((curVal, temIndex) => {
            //     return temIndex === index
            // })
            // // 根据选项是删除的第几个从而删除按选项解析的第几个
            // delete tmpAnalysisDetail[key[0]]
            // let analysis = {
            //     enabled: 1,
            //     type: QuestionTypeCollection.AnalysisType.Opt,
            //     detail: {}
            // }
            // console.log('临时analysis', analysis)

            // 获取当前题型中detail， 并清空
            let detail = {}
            for (let key in this.questionData.body.analysis.detail) {
                detail[key] = ''
            }
            this.$set(this.questionData.body.analysis, 'detail', detail)
            // console.log('单选阿诗丹顿多多多多多多多多多付所', this.questionData.body.analysis)
            this.$bus.$emit('refreshAnalysis', this.questionData.body.analysis)
            // this.$refs.questionAnalysis.refreshAnalysisData(this.questionData.body.analysis.detail)
        },
        /* TalQuestionAnalysis emit */
        anaysisObjectChangeEmit: function () {
            // console.log('analysisObjectChagneEmit')
            let analysis = this.$refs.questionAnalysis.outputAnalysisObject()
            this.$set(this.questionData.body, 'analysis', analysis)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        refresh: function (questionData) {
            this.questionData = questionData
        },
        /* output */
        outputQuestionObject: function () {
            return this.questionData
        },
        /* public */
        // 保存保存接口函数
        checkQuestionError: function () {
            // console.log('我是单选题的校验')
            let questionError = []

            let questionOptionsErrorArray = this.$refs.questionOptions.verifyQuestionOptions()
            let questionAnswerErrorArray = this.$refs.questionOptions.verifyQuestionAnswer()
            let questionStemBodyErrorArray = this.$refs.questionStemBody.verifyQuestionStemBody()
            let questionAnalysisErrorArray = this.$refs.questionAnalysis.verifyQuestionAnalysis()

            questionError = [...questionStemBodyErrorArray,
                             ...questionOptionsErrorArray,
                             ...questionAnswerErrorArray,
                             ...questionAnalysisErrorArray]

            return questionError
        }
    },
    computed: {
        computedOptionsCount: function () {
            // console.log('选项的长度', Object.keys(this.questionData.body.stem.options).length)
            return Object.keys(this.questionData.body.stem.options).length
        }
    },
    watch: {
        inputQuestion: function (newval) {
            // console.log('单选题watch', newval)
            // 深度拷贝， 防止引用
            // 一键复制以后， this.questionData 和this.inputQuestion 相同，但指向的不是同一块地址
            this.questionData = JSON.parse(JSON.stringify(newval))
        }
    }
}
</script>

<style lang="scss" scoped>
.choose {
    // width: 100%;
    // height: 100%;
    // margin: 0 auto;
    .options {
        margin: 30px 0;
    }
}

</style>
