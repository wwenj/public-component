<template>
    <div class="cloze-options-wrapper">
        <div class="option-content">
            <div class="option-item" v-for="(options, index) in optionsArray" :key="options.id">
                <span class="index">{{index + 1}}.</span>
                <div class="option-item-item" v-for="(item, index_index) in options.optionItem"  :key="index_index">
                    <button class="btn" :class="privateGetOptionSelectClassNameByIndex(index_index, index)" @click="answerOnClick(index, index_index)">{{index_index}}</button>
                    <input class='text-input' type="text" v-model="options.optionItem[index_index]" @input="updateTextOnInput">
                </div>
                <img src="@/assets/img/recording/del.png" alt="del" class="btn-del" @click="deleteOnClick(index)">
            </div>
        </div>
        <button class="add-btn" @click="addOnClick" :disabled="!computedCanAddNewOptions" :class="[!computedCanAddNewOptions ? 'btn-disabled' : '']">
            <img src="@/assets/img/recording/add.png" alt="+" v-if="computedCanAddNewOptions">
            <img src="@/assets/img/recording/gray.png" alt="+" v-else>
            <span>更多选项</span>
        </button>
    </div>
</template>

<script>
import { stringIsEmpty } from '@/common/common'
export default {
    props: {
        inputOptionsObject: {
            type: Object,
            default () {
                return {}
            }
        },
        inputAnswerObject: {
            type: Object,
            default () {
                return {}
            }
        },
        inputMaxCount: {
            type: Number,
            default: 30
        },
        inputMinCount: {
            type: Number,
            default: 4
        }
    },
    data () {
        return {
            optionsArray: [],
            answerObject: this.inputAnswerObject,
            nextOptionId: 0
        }
    },
    created () {
        this.priviteInitOptionsData(this.inputOptionsObject)
    },
    methods: {
        /* action */
        addOnClick: function () {
            // 新增一个选项就要新增一个答案
            this.optionsArray.push({
                id: this.nextOptionId++,
                optionItem: {
                    A: '',
                    B: '',
                    C: '',
                    D: ''
                }
            })
            let optionsCount = this.optionsArray.length
            this.$set(this.answerObject, optionsCount, '')
            this.$emit('addOptionObjectEmit', this.outputOptionsObject())
        },
        deleteOnClick: function (index) {
            if (this.optionsArray.length <= this.inputMinCount) {
                alert(`最少剩余${this.inputMinCount}个选项哟`)
                return
            }
            this.optionsArray.splice(index, 1)
            // 答案个数即答案对象的最后一个属性， +1 是因为选项已经被删除了一个
            let answerCount = this.optionsArray.length + 1
            delete this.answerObject[answerCount]
            for (let key in this.answerObject) {
                this.answerObject[key] = ''
            }
            this.$emit('deleteOptionObjectEmit', this.outputOptionsObject())
        },
        answerOnClick: function (index, answerItem) {
            // 这个地方这么写主要是让DOM重新渲染
            let tmpOptionsArray = this.optionsArray
            this.optionsArray = []
            this.optionsArray = tmpOptionsArray
            this.$set(this.answerObject, index + 1, answerItem)
            this.$emit('answerObjectChangeEmit', this.outputAnswerObject())
        },
        updateTextOnInput: function () {
            this.$emit('addOptionObjectEmit', this.outputOptionsObject())
        },
        /* public */
        refreshAnswerObject: function (answerObject) {
            this.answerObject = answerObject
        },
        /* output */
        outputOptionsObject: function () {
            let optionObject = {}
            this.optionsArray.forEach((ele, index) => {
                optionObject[index + 1] = ele.optionItem
            })
            return optionObject
        },
        outputAnswerObject: function () {
            return this.answerObject
        },
        verifyQuestionOptions: function () {
            let optionObject = this.outputOptionsObject()
            console.log('完形填空optionObject', optionObject)
            for (let keyOut in optionObject) {
                for (let keyIn in optionObject[keyOut]) {
                    if (!stringIsEmpty(optionObject[keyOut][keyIn])) {
                        return ['选项内容不能为空,请完善选项内容']
                    }
                }
            }
            return []
        },
        /* private */
        priviteInitOptionsData: function (optionsObject) {
            this.optionsArray = []
            for (let key in optionsObject) {
                this.optionsArray.push({
                    id: this.nextOptionId++,
                    optionItem: optionsObject[key]
                })
            }
        },
        // 得到按钮的样式
        privateGetOptionSelectClassNameByIndex: function (optionItem, index) {
            if (this.answerObject[index + 1] === optionItem) {
                return 'btn btn-active'
            }
            return 'btn'
        }
    },
    computed: {
        computedCanAddNewOptions () {
            return this.optionsArray.length < this.inputMaxCount
        }
    },
    watch: {
        inputOptionsObject: function (newVal) {
            this.priviteInitOptionsData(newVal)
            this.$emit('addOptionObjectEmit', this.outputOptionsObject())
        },
        inputAnswerObject: function (newVal) {
            this.refreshAnswerObject(newVal)
        }
    }
}
</script>

<style lang="scss" scoped>
.cloze-options-wrapper {
    padding-right: 40px;
    padding: 0 40px 0 20px;
    .option-item {
        position: relative;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        margin-top: 15px;
        &:not(:last-child) {
            border-bottom: 1px dashed #dcdcdc;
        }
        .index {
            position: absolute;
            top: 12px;
            left: -18px;
        }
        .btn-del {
            position: absolute;
            top: 12px;
            right: -30px;
        }
        .option-item-item {
            margin-left: 10px;
            margin-bottom: 15px;
            width: 47%;

            .text-input {
                width: calc(100% - 60px);
            }
        }
    }
}
</style>

