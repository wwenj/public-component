<template>
    <!-- 子组件props 直接接收数组类型的数据，选项、解析之类的操作均放在本组件中 -->
    <div class="judgement-wrapper">
        <!-- 题干组件 -->
        <tal-question-stem-body
        ref="questionStemBody"
        :inputText='inputQuestion.body.stem.body'
        @textChangeEmit='textChangeEmit'>
        </tal-question-stem-body>

        <!-- 选项组件 -->
        <tal-question-judgement-options
        ref="questionOptions"
        :inputOptionObject='inputQuestion.body.stem.options'
        :inputAnswerObject='inputQuestion.body.answer'
        :inputCurrentCount='computedOptionsCount'
        @optionObjectChangeEmit='optionObjectChangeEmit'
        @answerObjectChangeEmit='answerObjectChangeEmit'
        @optionAndAnswerObjectChangeEmit='optionAndAnswerObjectChangeEmit'
        @deleteOptionSyncAnalysisEmit='deleteOptionSyncAnalysisEmit'>
        </tal-question-judgement-options>

        <!-- 答案部分 -->
        <tal-question-answer
        :inputAnswer='answerString'>
        </tal-question-answer>

        <!-- 解析组件 -->
        <tal-question-analysis
        ref="questionAnalysis"
        :inputOptionsCount='computedOptionsCount'
        :inputQuestionType='inputQuestion.type'
        :inputAnalysisData='inputQuestion.body.analysis'
        @anaysisObjectChangeEmit='anaysisObjectChangeEmit'>
        </tal-question-analysis>
    </div>
</template>

<script>
import { Question, QuestionTypeCollection, JudgementDisplayType } from '@/common/constant'
import TalQuestionStemBody from '@/components/tal/TalQuestionStemBody'
import TalQuestionJudgementOptions from '@/components/tal/TalQuestionJudgementOptions'
import TalQuestionAnswer from '@/components/tal/TalQuestionAnswer'
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'
export default {
    components: {
        TalQuestionStemBody,
        TalQuestionJudgementOptions,
        TalQuestionAnswer,
        TalQuestionAnalysis
    },
    props: {
        inputQuestion: {
            type: Object,
            default () {
                return {
                    type: Question.Judgement.type,
                    body: {
                        stem: {
                            body: '',
                            options: {
                                1: '',
                                2: '',
                                3: '',
                                4: ''
                            }
                        },
                        answer: {
                            type: QuestionTypeCollection.AnswerType.Judge,
                            displayType: JudgementDisplayType.RightWrongSymbol.type,
                            items: {
                                1: '',
                                2: '',
                                3: '',
                                4: ''
                            }
                        },
                        analysis: {
                            enabled: 1,
                            type: QuestionTypeCollection.AnalysisType.Content,
                            detail: {
                                1: ''
                            }
                        }
                    }
                }
            }
        }
    },
    data () {
        return {
            answerString: '',
            // question对象，通过它连接各个小组件和最外层页面
            questionData: {
                type: Question.Judgement.type,
                body: {
                    stem: {
                        body: '',
                        options: {
                            1: '',
                            2: '',
                            3: '',
                            4: ''
                        }
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Judge,
                        displayType: JudgementDisplayType.RightWrongSymbol.type,
                        items: {
                            1: '',
                            2: '',
                            3: '',
                            4: ''
                        }
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {
                            1: ''
                        }
                    }
                }
            }
        }
    },
    created () {
        console.log('asdfada', this.inputQuestion)
        this.$emit('initQuestionEmit', this.outputQuestionObject())
    },
    methods: {
        /* action */
        /* TalQuestionStemBody emit */
        textChangeEmit: function () {
            let body = this.$refs.questionStemBody.outputText()
            this.$set(this.questionData.body.stem, 'body', body)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionOptions emit */
        optionObjectChangeEmit: function () {
            // 通过获取 选项组件中 选项的个数 来更新 解析组件中 按选项解析的个数
            // this.optionsCount = this.$refs.questionOptions.outputCount()
            // this.$refs.questionAnalysis.refreshOptionsCount(this.optionsCount)
            // 从选项组件中获取 选项option对象
            let options = this.$refs.questionOptions.outputOptionObject()
            this.$set(this.questionData.body.stem, 'options', options)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        answerObjectChangeEmit: function () {
            // 从选项组将中获取 答案 answer对象
            let answer = this.$refs.questionOptions.outputAnswerObject()
            this.$set(this.questionData.body, 'answer', answer)
            this.privateGetAnswerString()
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        optionAndAnswerObjectChangeEmit: function () {
            let answer = this.$refs.questionOptions.outputAnswerObject()
            let options = this.$refs.questionOptions.outputOptionObject()

            this.$set(this.questionData.body.stem, 'options', options)
            this.$set(this.questionData.body, 'answer', answer)

            this.privateGetAnswerString()
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        deleteOptionSyncAnalysisEmit: function (index) {
            // 只有是按选项解析的时候才会触发
            if (this.questionData.body.analysis.type !== QuestionTypeCollection.AnalysisType.Opt) return
            // index 代表选项删除的是第几个
            // 为了不影响当前的question对象，深度复制一个
            let tmpAnalysisDetail = JSON.parse(JSON.stringify(this.questionData.body.analysis.detail))
            var key = Object.keys(tmpAnalysisDetail).filter((curVal, temIndex) => {
                return temIndex === index
            })
            console.log(`删除第${key}项`)
            // 根据选项是删除的第几个从而删除按选项解析的第几个
            console.log('delete before', tmpAnalysisDetail)
            delete tmpAnalysisDetail[key[0]]
            console.log('delete after', tmpAnalysisDetail)
            let analysis = {
                enabled: 1,
                type: QuestionTypeCollection.AnalysisType.Opt,
                detail: tmpAnalysisDetail
            }
            // 使用bus, 通知解析组件更新
            this.$bus.$emit('refreshAnalysis', analysis)
            this.$set(this.questionData.body, 'analysis', analysis)
        },
        /* TalQuestionAnalysis emit */
        anaysisObjectChangeEmit: function () {
            let analysis = this.$refs.questionAnalysis.outputAnalysisObject()
            this.$set(this.questionData.body, 'analysis', analysis)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* private */
        privateGetAnswerString: function () {
            let answerObject = this.questionData.body.answer
            this.answerString = ''
            Object.keys(answerObject.items).forEach((key, index) => {
                this.answerString += key + ', ' + answerObject.items[key] + '       '
            })
        },
        /* output */
        outputQuestionObject: function () {
            return this.questionData
        },
        /* public */
        checkQuestionError: function (question) {
            console.log('判断题校验')
            let questionErrorArray = []
            let questionStemBodyErrorArray = this.$refs.questionStemBody.verifyQuestionStemBody()
            let questionOptionsErrorArray = this.$refs.questionOptions.verifyQuestionOptions()
            let questionAnswerErrorArray = this.$refs.questionOptions.verifyQuestionAnswer()
            let questionAnalysisErrorArray = this.$refs.questionAnalysis.verifyQuestionAnalysis()

            questionErrorArray = [...questionStemBodyErrorArray,
                                  ...questionOptionsErrorArray,
                                  ...questionAnswerErrorArray,
                                  ...questionAnalysisErrorArray]
            return questionErrorArray
        },
        refresh: function (question) {
            this.questionData = question
            this.$refs.questionOptions.refresh(this.questionData.body.stem.options, this.questionData.body.answer)
        }
    },
    computed: {
        computedOptionsCount: function () {
            return Object.keys(this.questionData.body.stem.options).length
        }
    },
    watch: {
        inputQuestion: function (newVal) {
            this.questionData = JSON.parse(JSON.stringify(newVal))
            this.privateGetAnswerString()
        }
    }
}
</script>

<style lang="scss" scoped>
// .judgement-wrapper {
//     box-sizing: border-box;
//     height: 100%;
//     width: 100%;
//     padding-right: 30px;
// }
</style>
