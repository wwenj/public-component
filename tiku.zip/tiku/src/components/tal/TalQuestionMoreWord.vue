<template>
    <div class="stem">
        <div class="title">请在此处输入连词成句的词语</div>
        <editor :inputIndex="0" @editorEmit='editorEmit'
        :inputText='inputText'></editor>
        <span class="info-text">说明：请将每个词语之间用3个以上空格分开，方便系统进行词语的拆分，如若拆分错误，可重新输入进行调整。</span>
    </div>

</template>
<script>
import { stringIsEmpty } from '@/common/common'
export default {
    props: {
        inputMoreWord: {
            type: Object,
            default: function () {
                return {}
            }
        }
    },
    data () {
        return {
            text: Object.values(this.inputMoreWord).join('&nbsp;&nbsp;&nbsp;&nbsp;'),
            inputText: ''
        }
    },
    computed: {
    },
    created () {
        let tmpArray = Object.values(this.inputMoreWord).map((item) => {
            return item.replace('<p>', '').replace('</p>', '')
        })
        let tmpText = tmpArray.join('&nbsp;&nbsp;&nbsp;&nbsp;')
        this.inputText = tmpText
    },
    methods: {
        /* action */
        /* editor emit */
        // 富文本编辑器失焦返回
        editorEmit: function (data) {
            let tmpArray = [...data.text.replace(/&nbsp;/g, ' ').replace(/\s{3,}/g, '%').split('%')]
            let tmpMidArray = tmpArray.map((item, index) => {
                let tmpItem = item.replace('<p>', '').replace('</p>', '').replace('<br>', '')
                return tmpItem
            })
            let tmpObject = {...tmpMidArray}
            this.text = tmpObject
            // 每次富文本编辑器失焦就向父组件返回操作
            this.$emit('moreWordChangeEmit', data)
        },
        /* public */
        refresh: function (text) {
            this.privateInitData(text)
        },
        verifyQuestionMoreWord: function () {
            let questionErrorArray = []
            let tmpText = Object.values(this.text).join('&nbsp;&nbsp;&nbsp;&nbsp;')
            if (!stringIsEmpty(tmpText)) {
                questionErrorArray.push('连词成句的词语不能为空，请完善词语内容')
            }
            return questionErrorArray
        },
        /* output */
        // 父组件预留操作函数，便于获取子组件数据
        outputText: function () {
            return this.text
        },
        /* private */
        privateInitData: function (text) {
            this.text = Object.values(text).join('&nbsp;&nbsp;&nbsp;&nbsp;')
        }
    },
    watch: {
        inputMoreWord: function (newval, oldval) {
            this.text = Object.values(newval).join('&nbsp;&nbsp;&nbsp;&nbsp;')
            this.inputText = Object.values(newval).join('&nbsp;&nbsp;&nbsp;&nbsp;')
        }
    }
}
</script>

<style lang="scss" scoped>
    .stem {
        margin-bottom: 33px;
        // .title {
        //     height: 16px;
        //     margin-bottom: 20px;
        //     font-size: 16px;
        //     font-family: 'MicrosoftYaHei', sans-serif;
        //     color: #3e4c89;
        // }
        // .title::before {
        //     content: url(../../assets/img/recording/title-icon.png);
        //     margin-right: 6px;
        //     vertical-align: middle;
        // }
        // .info-text {
        //   font-size: 12px;
        //   color: #999;
        // }
    }
</style>
