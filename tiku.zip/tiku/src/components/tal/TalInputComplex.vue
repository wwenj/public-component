<template>
    <div class="complex-wrapper">
        <!-- 题干组件 ß-->
        <tal-question-stem-body
        :inputText='inputQuestion.body.stem.body'
        @textChangeEmit='textChangeEmit'>
        </tal-question-stem-body>

        <!-- 复合题的小题部分 -->
        <div class="question-wrapper">
            <div v-for="(item, index) in questionArray" :key="item.id" class="small-question-item">
                <!-- 复合题的小题组件 -->
                <tal-small-question
                ref="smallQuestion"
                :inputIndex='index'
                :inputQuestion='item.question'
                :inputQuestionType='item.questionType'
                :inputCurrentQuestionCount='questionCount'
                @changeSmallQuestionEmit='changeSmallQuestionEmit'
                @initSmallQuestionEmit='initSmallQuestionEmit'
                @delQuestionEmit='delQuestionEmit'
                @upEmit='upEmit'
                @downEmit='downEmit'>
                </tal-small-question>
            </div>
        </div>

        <button @click="addSmallQuestionOnClick" class="add-btn">
            <img src="@/assets/img/recording/add.png" alt="+">
            <span>新增小题{{questionCount+1}}</span>
        </button>
    </div>
</template>

<script>
import { Question } from '@/common/constant'
import TalQuestionStemBody from '@/components/tal/TalQuestionStemBody'
import TalSmallQuestion from '@/components/tal/TalSmallQuestion'

export default {
    components: {
        TalQuestionStemBody,
        TalSmallQuestion
    },
    props: {
        inputQuestion: {
            type: Object,
            default () {
                return {
                    type: Question.Complex.type,
                    body: {
                        stem: {
                            body: ''
                        },
                        questions: []
                    }
                }
            }
        }
    },
    data () {
        return {
            // 小题数组中的id，主要作用是防止 vue的就地复用策略
            nextQuestionId: 0,
            // 存放小题的数组
            questionArray: [],
            // 小题个数
            questionCount: 0,
            questionData: {
                type: Question.Complex.type,
                body: {
                    stem: {
                        body: ''
                    },
                    questions: []
                }
            }
        }
    },
    mounted () {
        console.log('复合题的mounted')
        this.$emit('initQuestionEmit', this.questionData)
    },
    methods: {
        /* action */
        /* 新增小题 */
        addSmallQuestionOnClick: function () {
            this.questionArray.push({id: this.nextQuestionId++, questionType: '', question: undefined})
            this.questionData.body.questions[this.questionCount] = void 0
            this.questionCount++
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionStemBody emit */
        textChangeEmit: function (data) {
            this.$set(this.questionData.body.stem, 'body', data.text)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalSmallQuestion emit */
        // 修改小题的时候执行
        changeSmallQuestionEmit: function (data) {
            console.log('changeSmallQuestionEmit', data)
            let question = this.privateBuildComplexQuestion(data)
            this.$set(this.questionData.body.questions, data.index, question)
            this.$set(this.questionArray, data.index, {
                id: this.questionArray[data.index].id,
                questionType: this.privateGetQuestionTypeName(data.question.type),
                question: data.question
            })
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* 初始化小题 */
        initSmallQuestionEmit: function (data) {
            console.log('小题初始化')
            let question = this.privateBuildComplexQuestion(data)
            this.$set(this.questionData.body.questions, data.index, question)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* 删除小题 */
        delQuestionEmit: function (index) {
            this.questionArray.splice(index, 1)
            this.questionData.body.questions.splice(index, 1)
            this.questionCount--
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* 小题上移 */
        upEmit: function (index) {
            console.log('上箭头', index, this.questionArray)
             if (!this.questionArray[index].question || !this.questionArray[index - 1].question) {
                this.$message({
                    message: '当前小题或上一小题未选择题型，不予交换，请选择题型后交换',
                    type: 'warning'
                })
                return
            }
            // 下列三行代码控制数据
            let tmpQuestionData = this.questionData.body.questions[index]
            this.$set(this.questionData.body.questions, index, this.questionData.body.questions[index - 1])
            this.$set(this.questionData.body.questions, index - 1, tmpQuestionData)

            this.$set(this.questionArray, index, {
                id: this.nextQuestionId++,
                questionType: this.privateGetQuestionTypeName(this.questionData.body.questions[index].type),
                question: this.privateBuildBasicQuestion(this.questionData.body.questions[index])
            })
            this.$set(this.questionArray, index - 1, {
                id: this.nextQuestionId++,
                questionType: this.privateGetQuestionTypeName(this.questionData.body.questions[index - 1].type),
                question: this.privateBuildBasicQuestion(this.questionData.body.questions[index - 1])
            })
            console.log('-----', this.questionArray)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
            this.privateClearQuestionArray()
        },
        /* 小题下移 */
        downEmit: function (index) {
            console.log('下箭头', index)
            if (!this.questionArray[index].question || !this.questionArray[index + 1].question) {
                this.$message({
                    message: '当前小题或下一小题未选择题型，不予交换，请选择题型后交换',
                    type: 'warning'
                })
                return
            }
            let that = this
            // 下列三行控制数据
            let tmpQuestionData = that.questionData.body.questions[index]
            that.$set(that.questionData.body.questions, index, that.questionData.body.questions[index + 1])
            that.$set(that.questionData.body.questions, index + 1, tmpQuestionData)


            that.$set(that.questionArray, index, {
                id: that.nextQuestionId++,
                questionType: that.privateGetQuestionTypeName(that.questionData.body.questions[index].type),
                question: that.privateBuildBasicQuestion(that.questionData.body.questions[index])
            })

            that.$set(that.questionArray, index + 1, {
                id: that.nextQuestionId++,
                questionType: that.privateGetQuestionTypeName(that.questionData.body.questions[index + 1].type),
                question: that.privateBuildBasicQuestion(that.questionData.body.questions[index + 1])
            })

            that.$emit('questionChangeEmit', that.outputQuestionObject())
            this.privateClearQuestionArray()
        },
        /* public */
        refresh: function (copyQuestion) {
            let that = this
            this.questionData = copyQuestion
            let tmpQuestionArray = []
            this.questionCount = 0
            this.questionData.body.questions.forEach((item, index) => {
                console.log('item', item)
                if (item === void 0) return
                this.questionCount++
                for (let value in Question) {
                    if (Question[value].type === item.type) {
                        tmpQuestionArray.push({
                            id: that.nextQuestionId++,
                            questionType: Question[value].component,
                            question: this.privateBuildBasicQuestion(item)
                        })
                    }
                }
            })
            this.questionArray = tmpQuestionArray
        },
        checkQuestionError: function () {
            let question = this.outputQuestionObject().body.questions
            console.log('复合题格式校验', question)
            let that = this
            let questionError = []
            question.forEach((element, index) => {
                console.log('element', element)
                console.log('index', index)
                console.log('refs', that.$refs.smallQuestion)
                let smallQuestionError = {}
                if (element) {
                    smallQuestionError['errorMessage'] = [...that.$refs.smallQuestion[index].$refs.smallQuestionItemRef.checkQuestionError()]

                    console.log('小题错误长度', smallQuestionError['errorMessage'].length)
                    if (smallQuestionError['errorMessage'].length !== 0) {
                        smallQuestionError['title'] = `第${index + 1}小题`
                        questionError.push(smallQuestionError)
                    }
                } else {
                    smallQuestionError['title'] = `第${index + 1}小题`
                    smallQuestionError['errorMessage'] = ['未选择小题，请选择']
                    questionError.push(smallQuestionError)
                }
            })
            return questionError
        },
        /* output */
        outputQuestionObject: function () {
            return this.questionData
        },
        /* private */
        // 组装 复合题的question
        privateBuildComplexQuestion: function (data) {
            // 处理数据格式
            let question = {
                type: data.question.type,
                stem: data.question.body.stem,
                answer: data.question.body.answer,
                analysis: data.question.body.analysis
            }
            return question
        },
        // 组装基本题型
        privateBuildBasicQuestion: function (data) {
            let question = {
                type: data.type,
                body: {
                    stem: data.stem,
                    answer: data.answer,
                    analysis: data.analysis
                }
            }
            return question
        },
        privateGetQuestionTypeName: function (type) {
            for (let value in Question) {
                if (Question[value].type === type) {
                    return Question[value].component
                }
            }
            return undefined
        },
        privateClearQuestionArray: function () {
            this.questionArray.forEach(ele => {
                ele = undefined
            })
        }
    }
}
</script>

<style lang="scss" scoped>
.complex-wrapper {
    .small-question-item {
        &:last-child {
            margin-bottom: 15px;
            border-bottom: 1px solid #dcdcdc;
        }
    }
}
</style>


