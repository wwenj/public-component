<template>
    <div class="mul-choice-mul-wrapper">
        <!-- 题干组件 -->
        <tal-question-stem-body-with-blank
        ref="questionStemBody"
        :inputText='inputQuestion.body.stem.body'
        @editorEmit='editorEmit'
        @countBlankEmit='countBlankEmit'>
        </tal-question-stem-body-with-blank>

        <!-- 选项组件 -->
        <tal-question-options
        ref="questionOptions"
        :inputQuestionType='inputQuestion.type'
        :inputOptionObject='inputQuestion.body.stem.options'
        :inputCurrentCount='computedOptionsCount'
        @optionObjectChangeEmit='optionObjectChangeEmit'
        @deleteOptionSyncAnalysisEmit='deleteOptionSyncAnalysisEmit'
        @allChangeEmit='allChangeEmit'>
        </tal-question-options>

        <!-- 答案组件 -->
        <tal-question-mul-choice-mul-answer
        ref="questionMulChoiceMulAnswer"
        :inputOptionsCount='computedOptionsCount'
        :inputAnswerObject='questionData.body.answer.items'
        @choiceAnswerEmit='choiceAnswerEmit'>
        </tal-question-mul-choice-mul-answer>

        <!-- 解析组件 -->
        <tal-question-analysis
        ref="questionAnalysis"
        :inputQuestionType='inputQuestion.type'
        :inputAnalysisData='inputQuestion.body.analysis'
        :inputOptionsCount='computedAnswerCount'
        @anaysisObjectChangeEmit='anaysisObjectChangeEmit'>
        </tal-question-analysis>
    </div>
</template>

<script>
import { Question, QuestionTypeCollection } from '@/common/constant'
import TalQuestionStemBodyWithBlank from '@/components/tal/TalQuestionStemBodyWithBlank'
import TalQuestionOptions from '@/components/tal/TalQuestionOptions'
import TalQuestionMulChoiceMulAnswer from '@/components/tal/TalQuestionMulChoiceMulAnswer'
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'
export default {
    components: {
        TalQuestionStemBodyWithBlank,
        TalQuestionOptions,
        TalQuestionMulChoiceMulAnswer,
        TalQuestionAnalysis
    },
    props: {
        // 题目信息数据，父组件传递
        inputQuestion: {
            type: Object,
            default () {
                return {
                    type: Question.MulChoiceMul.type,
                    body: {
                        stem: {
                            body: '',
                            options: {
                                A: '',
                                B: '',
                                C: '',
                                D: ''
                            }
                        },
                        answer: {
                            type: QuestionTypeCollection.AnswerType.Pair,
                            items: {
                            }
                        },
                        analysis: {
                            enabled: 1,
                            type: QuestionTypeCollection.AnalysisType.Content,
                            detail: {
                                1: ''
                            }
                        }
                    }
                }
            }
        }
    },
    data () {
        return {
            questionData: {
                type: Question.MulChoiceMul.type,
                body: {
                    stem: {
                        body: '',
                        options: {
                            A: '',
                            B: '',
                            C: '',
                            D: ''
                        }
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Pair,
                        items: {
                        }
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {
                            1: ''
                        }
                    }
                }
            }
        }
    },
    mounted () {
        this.$emit('initQuestionEmit', this.outputQuestionObject())
    },
    methods: {
        /* TalQuestionStemBodyWithBlank */
        editorEmit: function (data) {
            let body = this.$refs.questionStemBody.outputText()
            this.$set(this.questionData.body.stem, 'body', body)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        countBlankEmit: function (count) {
            // count 横线的条数
            console.log('横线的条数', count)
            let tmpAnswerItem = {}
            for (var i = 0; i < count; i++) {
                tmpAnswerItem[i + 1] = this.questionData.body.answer.items[i + 1] === undefined ? '' : this.questionData.body.answer.items[i + 1]
            }
            this.$set(this.questionData.body.answer, 'items', tmpAnswerItem)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionOptions emit */
        optionObjectChangeEmit: function () {
            let options = this.$refs.questionOptions.outputOptionObject()
            this.$set(this.questionData.body.stem, 'options', options)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        allChangeEmit: function () {
            let options = this.$refs.questionOptions.outputOptionObject()
            this.$set(this.questionData.body.stem, 'options', options)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        deleteOptionSyncAnalysisEmit: function () {
            console.log('多选多选项')
            // 清空答案和解析
            // 通过bus 清空解析组件
            let detail = {}
            for (let key in this.questionData.body.analysis.detail) {
                detail[key] = ''
            }
            this.$set(this.questionData.body.analysis, 'detail', detail)
            // this.$refs.questionAnalysis.refreshAnalysisData(this.questionData.body.analysis.detail)
            this.$bus.$emit('refreshAnalysis', this.questionData.body.analysis)

            let answerItems = this.questionData.body.answer.items
            for (let key in answerItems) {
                answerItems[key] = ''
            }
            this.$set(this.questionData.body.answer, 'items', answerItems)
        },
        /* TalQuestionMulChoiceMulAnswer emit */
        choiceAnswerEmit: function () {
            let answerObject = this.$refs.questionMulChoiceMulAnswer.outputAnswerObject()
            this.$set(this.questionData.body.answer, 'items', answerObject)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        anaysisObjectChangeEmit: function () {
            let analysis = this.$refs.questionAnalysis.outputAnalysisObject()
            this.$set(this.questionData.body, 'analysis', analysis)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* output */
        outputQuestionObject: function () {
            return this.questionData
        },
        /* public */
        checkQuestionError: function (question) {
            // this.questionError = {
            //     isError: false,
            //     message: []
            // }
            // this.privateVerifyQuestionStem(this.questionData.body.stem.body)
            // this.privateVerifyQuestionOptions(this.questionData.body.stem.options)
            // this.privateVerifyQuestionAnswer(this.questionData.body.answer.items)
            // this.privateVerifyQuestionAnalysis(this.questionData.body.analysis)
            console.log('我是多选题的校验')
            let questionError = []

            let questionOptionsErrorArray = this.$refs.questionOptions.verifyQuestionOptions()
            let questionAnswerErrorArray = this.$refs.questionMulChoiceMulAnswer.verifyQuestionAnswer()
            let questionStemBodyErrorArray = this.$refs.questionStemBody.verifyQuestionStemBody()
            let questionAnalysisErrorArray = this.$refs.questionAnalysis.verifyQuestionAnalysis()

            questionError = [...questionStemBodyErrorArray,
                             ...questionOptionsErrorArray,
                             ...questionAnswerErrorArray,
                             ...questionAnalysisErrorArray]

            return questionError

            // return this.questionError
        }
    },
    computed: {
        computedOptionsCount: function () {
            return Object.keys(this.questionData.body.stem.options).length
        },
        computedAnswerCount: function () {
            console.log('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', Object.keys(this.questionData.body.answer.items).length)
            return Object.keys(this.questionData.body.answer.items).length
        }
    },
    watch: {
        inputQuestion: function (newVal) {
            this.questionData = JSON.parse(JSON.stringify(newVal))
        }
    }
}
</script>

<style lang="scss" scoped>
// .mul-choice-mul-wrapper {
//     box-sizing: border-box;
//     height: 100%;
//     width: 100%;
//     padding-right: 30px;
// }
</style>
