<template>
    <div class="answer-wrapper">
        <div class="title">答案</div>
        <span class="info-text">tips: 点击选项前的按钮选择答案</span>
        <div class="answer">
            <input type="text" name="" :value="inputAnswer" disabled class="text-input">
        </div>
    </div>
</template>

<script>
export default {
    props: {
        inputAnswer: {
            type: String,
            default: ''
        }
    }
}
</script>

<style lang="scss" scoped>
.answer-wrapper {
    margin-bottom: 42px;
}
</style>

