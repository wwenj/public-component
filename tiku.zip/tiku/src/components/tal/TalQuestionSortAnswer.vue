<template>
    <div class="sort-answer-wrapper">
        <div class="title">答案</div>
        <div class="answer-input-box">
            <input type="text" @blur="answerOnBlur" v-model="answerString" :placeholder="placeholderMessage" class="text-input">
        </div>
    </div>
</template>

<script>
import { stringIsEmpty } from '@/common/common'
export default {
    props: {
        inputAnswerString: {
            type: String,
            default: ''
        },
        // 选项的个数，通过选项个数展示ABCDEFG, 并界定选项的边界
        inputOptionsCount: {
            type: Number,
            default: 4
        }
    },
    data () {
        return {
            answerString: this.inputAnswerString,
            placeholderMessage: '正确排序'
        }
    },
    created () {

    },
    methods: {
        /* action */
        answerOnBlur: function () {
            // 字母界限，即最后一个的key
            let letterBoundary = this.privateGetOptionTitleWithIndex(this.inputOptionsCount - 1)
            console.log('字母边界', letterBoundary)
            // 获取答案的个数
            let answerCount = this.inputOptionsCount
            // // 输入框要展示的临时字符串
            let tmpAnswerString = ''
            // // 计数器，放进this.answerObject 的个数
            let count = 0
            // 正则输入的字符串，保留所有的字母并全部大写
            this.answerString = this.answerString.replace(/[^a-zA-Z]/g, '').toUpperCase()
            // 遍历字符串，放弃超过边界的字母
            for (let i = 0; i < this.answerString.length; i++) {
                // 如果当前字母小于边界值，则将其放进 this.answerObject
                if (this.answerString[i] <= letterBoundary) {
                    if (count < answerCount) {
                        // this.answerObject[++count] = this.answerString[i]
                        ++count
                        tmpAnswerString += this.answerString[i]
                    }
                }
            }
            this.answerString = tmpAnswerString
            this.placeholderMessage = '正确排序'
            if (this.privateIsRepeat(tmpAnswerString)) {
                // 清空答案
                this.placeholderMessage = '答案中有重复字母，请重新输入'
                this.answerString = ''
            }
            if (this.answerString.length !== this.inputOptionsCount) {
                this.answerString = ''
            }
            this.$emit('answerObjectChangeEmit', this.outputAnswerObject)
        },
        /* public */
        refresh: function (answerString) {
            this.answerString = answerString
        },
        verifyQuestionAnswer: function () {
            let questionErrorArray = []
            if (!stringIsEmpty(this.answerString)) {
                questionErrorArray.push('答案不能为空，请完善答案内容')
            } else {
                if (this.answerString.length !== this.inputOptionsCount) {
                    questionErrorArray.push('答案不全，请完善答案内容')
                }
            }
            return questionErrorArray
        },
        /* output */
        outputAnswerObject: function () {
            return this.answerString
        },
        /* private */
        privateGetOptionTitleWithIndex: function (index) {
            return String.fromCharCode(65 + index)
        },
        // 检查字符串中是否有重复字母
        privateIsRepeat: function (str) {
            let reg = /(?:^|)(\S{1}).*\1/g
            return reg.test(str)
        }
    },
    watch: {
        inputAnswerString: function (newVal) {
            this.answerString = newVal
            this.$emit('answerObjectChangeEmit', this.outputAnswerObject)
        }
    }
}
</script>

<style lang="scss" scoped>
.sort-answer-wrapper {
    margin-bottom: 30px;
    .answer-input-box {
        margin-top: 32px;
        white-space: nowrap;
    }
}
</style>

