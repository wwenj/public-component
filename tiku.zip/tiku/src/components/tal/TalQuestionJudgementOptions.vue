<template>
    <div class="options">
        <div class="options-header">
            <label>作答类型:</label>
            <span v-for="(val, key) in JudgementDisplayType" :key="key">
                <input type="radio" :value="val" :name="random" v-model="displayTypeObject" :checked="displayTypeObject.type === val.type">
                {{val.nameArray.join('')}}
            </span>
        </div>
        <ul>
            <li class="options-list" v-for="(option, index) in optionArray" :key="option.id">
                <!-- v-show 与 v-if的区别 https://www.cnblogs.com/Rexxar/p/5578441.html -->
                <div class="option-item" v-if="index < currentCount">
                    <span style="width: 15px;">{{ privateGetOptionTitleWithIndex(index) }}</span>
                    <div class="btn-group">
                        <span v-for="(val, answerIndex) in displayTypeObject.nameArray" :key="answerIndex">
                            <button class='btn' :class="[privateGetOptionSelectClassNameByIndex(index, answerIndex)]" @click="judgementButtonOnClick(index, answerIndex)">{{ displayTypeObject.nameArray[answerIndex] }}</button>
                        </span>
                    </div>
                    <div class="editor-container">
                        <editor :inputIndex="index" @editorEmit='editorEmit' :inputText='option.textInput'></editor>
                    </div>
                    <img src="@/assets/img/recording/del.png" alt="del" @click="deleteOnClick(index)">
                </div>
            </li>
        </ul>
        <button class="add-btn" @click="addOnClick" :disabled="!computedCanAddNewOptions" :class="[!computedCanAddNewOptions ? 'btn-disabled' : '']">
            <!-- <img src="@/assets/img/recording/add.png" alt=""> -->
            <img src="@/assets/img/recording/add.png" alt="+" v-if="computedCanAddNewOptions">
            <img src="@/assets/img/recording/gray.png" alt="+" v-else>
            <span>更多选项</span>
        </button>
    </div>

</template>
<script>
import { QuestionTypeCollection, JudgementDisplayType } from '@/common/constant'
import { stringIsEmpty } from '@/common/common'
export default {
    props: {
        // 控制初始显示选项个数，从0开始默认为4个
        inputCurrentCount: {
            type: Number,
            default: 4
        },
        // 选项能增加的最大数量，默认为10
        inputMaxCount: {
            type: Number,
            default: 10
        },
        // 选项删除剩余的最小数量，默认为2
        inputMinCount: {
            type: Number,
            default: 2
        },

        // 录入的选项
        inputOptionObject: {
            type: Object,
            default () {
                return {}
            }
        },
        // 输入的答案
        // 这个最终被拆分成了:answerObject和displayTypeObject
        inputAnswerObject: {
            type: Object,
            default () {
                return {
                    displayType: JudgementDisplayType.RightWrongSymbol.type,
                    type: QuestionTypeCollection.AnswerType.Judge,
                    items: {
                    }
                }
            }
        }
    },
    data () {
        return {
            currentCount: this.inputCurrentCount, // 选项显示个数
            optionArray: [], // 渲染选项的数组结构
            answerArray: [], // 选择的答案列表,这里与input是不一致的,注意区分
            displayTypeObject: JudgementDisplayType.RightWrongSymbol,
            JudgementDisplayType,
            random: 'judgement' + Math.random() * 100000000000000000 // 防止同一个页面有多个该组件，单选按钮混乱
        }
    },
    created () {
        this.privateInitData(this.inputOptionObject, this.inputAnswerObject)
    },
    methods: {
        /* action */
        // 增加选项
        addOnClick: function () {
            let optionArrayLength = this.optionArray.length
            if (this.currentCount === optionArrayLength) {
                alert(`最多添加${this.inputMaxCount}个选项哦！`)
            } else {
                this.currentCount += 1
            }
            this.$emit('optionAndAnswerObjectChangeEmit')
        },
        // 删除选项
        deleteOnClick: function (index) {
            if (this.currentCount === this.inputMinCount) {
                alert(`最少剩余${this.inputMinCount}个选项哦！`)
            } else {
                // 更新选项数据
                let deleteOptionArray = this.optionArray.splice(index, 1)
                let deleteOption = deleteOptionArray[0]
                deleteOption.textInput = ''
                deleteOption.textOutput = ''
                this.optionArray.push(deleteOption)
                this.currentCount -= 1
                // 更新答案数据
                if (this.answerArray.length > index) {
                    this.answerArray.splice(index, 1)
                }
                this.$emit('optionAndAnswerObjectChangeEmit')
                // 为了同步删除按选项解析  eg. 删除第二个选项，则需要删除按选项解析的第二个解析
                this.$emit('deleteOptionSyncAnalysisEmit', index)
            }
        },
        judgementButtonOnClick: function (questionIndex, answerIndex) {
            // https://www.cnblogs.com/zhuzhenwei918/p/6893496.html
            // 数组的响应式
            this.$set(this.answerArray, questionIndex, answerIndex)
            this.$emit('answerObjectChangeEmit')
        },
        /* editor emit */
        // 富文本编辑器失焦返回，存入this.options
        editorEmit: function (data) {
            let text = data.text
            let index = data.index
            let option = this.optionArray[index]
            option.textOutput = text
            // 每次富文本编辑器失焦就向父组件返回操作
            this.$emit('optionObjectChangeEmit')
        },
        /* public */
        refresh: function (optionObject, answerObject) {
            this.currentCount = this.inputCurrentCount
            this.privateInitData(optionObject, answerObject)
        },
        verifyQuestionOptions: function () {
            let optionsObject = this.outputOptionObject()
            console.log(optionsObject)
            for (let key in optionsObject) {
                if (!stringIsEmpty(optionsObject[key])) {
                    return ['题目内容不能为空，请完善题目内容']
                }
            }
            return []
        },
        verifyQuestionAnswer: function () {
            let answerObject = this.outputAnswerObject()
            console.log('answerObject', answerObject)
            for (let key in answerObject.items) {
                if (!stringIsEmpty(answerObject.items[key])) {
                    return ['题目答案不能为空，请完善题目答案']
                }
            }
            return []
        },
        /* output */
        // 父组件预留操作函数，便于获取子组件数据
        outputOptionObject: function () {
            let option = {}
            for (let i = 0; i < this.currentCount; i++) {
                let item = this.optionArray[i]
                let text = item.textOutput
                let key = this.privateGetOptionKeyWithIndex(i)
                option[key] = text
            }
            return option
        },
        outputAnswerObject: function () {
            let answerItemObject = {}
            let answerArrayLength = this.answerArray.length
            // 必须用currentCount循环,因为有可能有题目,但是还没有答案
            for (let i = 0; i < this.currentCount; i++) {
                let key = this.privateGetOptionKeyWithIndex(i)
                let tmpValue = ''
                if (i < answerArrayLength) {
                    tmpValue = this.answerArray[i]
                }
                let value = ''
                if (tmpValue === '' || tmpValue === undefined || tmpValue === -1) {
                    value = ''
                } else {
                    value = this.displayTypeObject.nameArray[tmpValue]
                    // 当从作答类型从TFN切换到其他类型的时候,并且在TFN情况选项选择了N的时候会出现这种情况
                    if (value === undefined) {
                        value = ''
                    }
                }
                answerItemObject[key] = value
            }
            let answer = {
                // displayType: this.inputAnswerObject.displayType,
                displayType: this.displayTypeObject.type,
                type: QuestionTypeCollection.AnswerType.Judge,
                items: answerItemObject
            }
            return answer
        },
        outputCount: function () {
            return this.currentCount
        },
        /* private */
        // 计算选项的标题,
        privateGetOptionTitleWithIndex (index) {
            return (index + 1) + '.'
        },
        privateGetOptionKeyWithIndex (index) {
            return index + 1
        },
        privateGetIndexWithOptionTitle (title) {
            // 将来可以根据类型进行switch,case
            return title - 1
        },
        // 得到按钮的样式
        privateGetOptionSelectClassNameByIndex (questionIndex, answerIndex) {
            let val = this.answerArray[questionIndex]
            if (val === answerIndex) {
                return 'btn btn-active'
            }
            return 'btn'
        },
        privateInitData (optionObject, answerObject) {
            console.log('=============optionObject', optionObject)
            console.log('=============answerObject', answerObject)
            // 先置空
            this.optionArray = []
            this.answerArray = []
            // 获取选项数组
            let tmpOptionArray = []
            for (let key in optionObject) {
                let value = optionObject[key]
                tmpOptionArray.push(value)
            }
            let tmpOptionArrayLength = tmpOptionArray.length
            for (let i = 0; i < this.inputMaxCount; i++) {
                let text = ''
                if (i < tmpOptionArrayLength) {
                    text = tmpOptionArray[i]
                }
                let value = {
                    // 这个id是用于Dom重新加载用的v-key,跟选项的顺序没有对应关系
                    // 因为我们有可能删除选项或者添加选项
                    id: i,
                    textInput: text,
                    textOutput: text
                }
                this.optionArray.push(value)
            }
            for (let key in JudgementDisplayType) {
                let object = JudgementDisplayType[key]
                if (object.type === parseInt(answerObject.displayType)) {
                    this.displayTypeObject = object
                    break
                }
            }
            // 获取答案数组
            let items = answerObject.items
            let nameArray = this.displayTypeObject.nameArray
            let nameArrayLength = nameArray.length
            for (let key in items) {
                let val = items[key]
                let index = this.privateGetIndexWithOptionTitle(key)
                let answerIndex = ''
                for (let i = 0; i < nameArrayLength; i++) {
                    let name = nameArray[i]
                    if (name === val) {
                        answerIndex = i
                        break
                    }
                }
                this.answerArray[index] = answerIndex
            }
             console.log('this.answerArray', this.answerArray)
        }
    },
    computed: {
        // 是否可以添加新的选项
        computedCanAddNewOptions () {
            return this.currentCount < this.inputMaxCount
        }
    },
    watch: {
        displayTypeObject: function (oldVal, newVal) {
            this.$emit('optionAndAnswerObjectChangeEmit')
        },
        // watch 一个属性就可以 监控到所有的prop的变化
        inputOptionObject: function (newVal, oldVal) {
            this.currentCount = this.inputCurrentCount
            this.privateInitData(newVal, this.inputAnswerObject)
        },
        inputCurrentCount: function (newVal) {
            this.currentCount = newVal
        }
    }
}
</script>

<style lang="scss" scoped>
.options {
    margin-bottom: 41px;
    .options-header {
        font-size: 16px;
        label {
            margin-right: 30px;
            font-size: 14px;
            line-height: 32px;
            color: #2f2f2f;
        }
        span {
            margin-right: 40px;
        }
    }
    td {
        padding: 2px;
        word-break: keep-all;
        white-space: nowrap;
    }

    .options-list {
        margin-bottom: 20px;

        .option-item {
            display: flex;
            flex-direction: row;
            align-items: center;

            .btn-group {
                display: flex;
                flex-direction: row;
                margin: 0 5px;
                border: 1px solid #5f7aff;
                border-radius: 4px;
            }

            .editor-container {
                width: 100%;
                word-break: break-all;
                word-wrap: break-word;
            }

            img {
                margin-left: 5px;
                width: 15px;
            }
        }
    }
    .btn {
        border-radius: 0;
        border: solid .5px #5f7aff;
    }
}
</style>



