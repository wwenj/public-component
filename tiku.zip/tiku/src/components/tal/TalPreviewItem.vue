<template>
    <div class="preview-wrapper">
        <div class="header" v-if="inputShowTitle">试题预览</div>
        <div class="section">
            <div class="source">
                <!-- <div v-for="(item, index) in inputSourceDataArray" v-if="item.source_type_id" :key="index"> -->
                    <div>
                    <!-- {{inputSourceDataArray}} -->
                    <p class="header-source">
                        <span v-for="(item,index) in sourceData" v-if="sourceData.length != 0" :key="index">
                            {{item}}
                        </span>
                        <span v-if="sourceData.length === 0">暂无来源信息</span>
                    </p>
                    <!-- <p class="header-source cee" v-if="SourceType.Cee == item.source_type_id">{{item.year}}高考真题{{item.page_tag_id_name}}{{item.ab_exam_id_name}}{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source H30Sim" v-else-if="SourceType.H30Sim == item.source_type_id">{{item.year}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}高考零模{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source H31Sim" v-else-if="SourceType.H31Sim == item.source_type_id">{{item.year}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}高三一模{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source H32Sim" v-else-if="SourceType.H32Sim == item.source_type_id">{{item.year}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}高三二模{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source H33Sim" v-else-if="SourceType.H33Sim == item.source_type_id">{{item.year}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}高三三模{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source MidTerm" v-else-if="SourceType.MidTerm == item.source_type_id">{{item.start_school_year_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}期中{{item.ab_exam_id_name}}{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source FinTerm" v-else-if="SourceType.FinTerm == item.source_type_id">{{item.start_school_year_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}期末{{item.ab_exam_id_name}}{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source MonthlyTest" v-else-if="SourceType.MonthlyTest == item.source_type_id">{{item.start_school_year_name}}{{item.month_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}月考{{item.ab_exam_id_name}}{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source WeeklyTest" v-else-if="SourceType.WeeklyTest == item.source_type_id">{{item.start_school_year_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}周测{{item.ab_exam_id_name}}{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source PreStudy" v-else-if="SourceType.PreStudy == item.source_type_id">{{item.start_school_year_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}课前练习{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source ClassExercise" v-else-if="SourceType.ClassExercise == item.source_type_id">{{item.start_school_year_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}课堂练习{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source Homework" v-else-if="SourceType.Homework == item.source_type_id">{{item.start_school_year_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}课后练习{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source GCSE" v-else-if="SourceType.GCSE == item.source_type_id">{{item.year}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}会考真题{{item.note}}</p>
                    <p class="header-source GCSESim" v-else-if="SourceType.GCSESim == item.source_type_id">{{item.year}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}会考模拟{{item.note}}</p>
                    <p class="header-source SelfEnrollment" v-else-if="SourceType.SelfEnrollment == item.source_type_id">{{item.year}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}自主招生{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source FinSim" v-else-if="SourceType.FinSim == item.source_type_id">{{item.start_school_year_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}期末模拟{{item.ab_exam_id_name}}{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source InterimSim" v-else-if="SourceType.InterimSim == item.source_type_id">{{item.start_school_year_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}期中模拟{{item.ab_exam_id_name}}{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source UnitTest" v-else-if="SourceType.UnitTest == item.source_type_id">{{item.start_school_year_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}单元测{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source OpenExam" v-else-if="SourceType.OpenExam == item.source_type_id">{{item.start_school_year_name}}{{item.province_id_name}}{{item.city_id_name}}{{item.area_id_name}}{{item.school_id_name}}{{item.grade_id_name}}{{item.term_id_name}}开学考试{{item.science_id_name}}{{item.note}}</p>
                    <p class="header-source other" v-else>其它</p> -->
                </div>
            </div>
        </div>
        <!-- 题目部分开始 -->
        <div class="stem section" v-if="inputQuestion.type == Question.Complex.type" v-html="inputQuestion.body.stem.body"></div>
        <div v-for="(questionItem, index) in questions" :key="index">
            <div v-if="inputQuestion.type == Question.Complex.type" class="section title">第{{index + 1}}小题</div>
            <div class="section">
                <div class="stem" v-html='questionItem.body.stem.body' v-if="questionItem.body && questionItem.body.stem"></div>
                <div class="options" v-if="questionItem.body && questionItem.body.stem">
                    <!-- options  -->
                    <!-- 1、 首先判断options 是否为 {}, 如果是{}， 则什么都不做 -->
                    <div v-if="Object.keys(questionItem.body.stem.options).length === 0"></div>
                    <!-- 2、 配对题、完形填空和连词成句的option相对于其他题型比较特殊，需单独处理 配对题和完形填空的 options -->
                    <!-- 配对题 -->
                    <div v-else-if="questionItem.type == Question.Pair.type" class="pair-option">
                        <div class="options-left">
                            <div v-for="(item, index) in questionItem.body.stem.options.left" class="option-item" :key="index">
                                <span>{{index}}.</span>
                                <div v-html="item"></div>
                            </div>
                        </div>
                        <div class="options-right">
                            <div v-for="(item, index) in questionItem.body.stem.options.right" class="option-item" :key="index">
                                <span>{{index}}.</span>
                                <div v-html="item"></div>
                            </div>
                        </div>
                    </div>
                    <!-- 完形填空 -->
                    <div v-else-if="questionItem.type == Question.Cloze.type" class="cloze-option">
                        <div v-for="(item, index) in questionItem.body.stem.options" class="option-item" :key="index">
                            <span>{{index}}. </span>
                            <ul>
                                <li v-for="(item, index) in item" :key="index">
                                    <span>{{index}}.</span>
                                    <div v-html="item"></div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- 连词成句 -->
                    <div v-else-if="questionItem.type == Question.WordStosen.type" class="wordstosen-option">
                        <div v-for="(item, index) in questionItem.body.stem.options" class="option-item" :key="index">
                            <div v-html="item"></div>
                            <span>&nbsp;</span>
                        </div>
                    </div>
                    <!-- 3、 大部分的options 都是单层对象 -->
                    <div v-else>
                        <div v-for="(item, index) in questionItem.body.stem.options" class="option-item" :key="index">
                            <span>{{index}}.</span>
                            <div v-html="item"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section">
                <div class="section-title">答案</div>
                <div class="answer" v-if="questionItem.body && questionItem.body.answer">
                    <!-- 目前的题型，答案只有三种情况，一种是字符串类型，一种是对象类型，一种是填空题类型 -->
                    <div v-if="typeof questionItem.body.answer.items == 'string'" v-html="questionItem.body.answer.items"></div>
                    <div v-else-if="questionItem.type == Question.Filling.type">
                        <div v-for="(item, index) in questionItem.body.answer.items" :key="index" class="answer-item">
                            <span>{{index}}.</span>
                            <div v-html="item.value"></div>
                        </div>
                    </div>
                    <div v-else>
                        <div v-for="(item, index) in questionItem.body.answer.items" :key="index" class="answer-item">
                            <span>{{index}}.</span>
                            <div v-html="item"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section">
                <div class="section-title">解析</div>
                <div class="analysis" v-if="questionItem.body && questionItem.body.analysis">
                    <div v-for="(item, index) in questionItem.body.analysis.detail" class="analysis-item" :key="index">
                        <!-- 按方法解析 -->
                        <div v-if="questionItem.body.analysis.type == QuestionTypeCollection.AnalysisType.Content">
                            <span v-if="Object.keys(questionItem.body.analysis.detail).length > 1">{{methodMap[index-1]}}: </span>
                            <div v-html="item"></div>
                        </div>
                        <!-- 按选项或小题解析 -->
                        <div v-else>
                            <span>{{index}}:</span>
                            <div v-html="item"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- 题目部分结束 -->
        <div class="section" v-if="needTags">
            <div class="section-title">标注</div>
            <div class="tag">
                <ul class="tag-container" v-for="(item, index) in inputTags" :key="index">
                    <li class="tag-item" v-for="(tag, key) in item" :key="key" v-if="tag.primary">
                        <span>{{tag.name}}</span>
                        <button class="btn btn-tag-detail" :data-key="index" @click="onClickTagDetail">详情</button>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script>
import $ from 'jquery'
import { SourceType, Question, QuestionTypeCollection, methodMap } from '@/common/constant'

export default {
    props: {
        inputQuestion: {
            type: Object,
            default: () => {}
        },
        inputSourceDataArray: {
            type: Array,
            default: () => {}
        },
        needTags: {
            type: Boolean,
            default: false
        },
        inputTags: {
            type: Object,
            default: () => {}
        },
        inputShowTitle: {
            type: Boolean,
            default: true
        }
    },
    data () {
        return {
            SourceType,
            Question,
            QuestionTypeCollection,
            methodMap,
            questions: [],
            sourceData: [] // 展示的来源名
        }
    },
    mounted () {
        if (this.inputQuestion.type === Question.Complex.type) {
            // 处理成基本题型的数据格式
            let complexSmallQuestion = []
            this.inputQuestion.body.questions.forEach(element => {
                // 新增小题，题目不选的情况下 element为undefined
                if (element) {
                    complexSmallQuestion.push(this.privateBuildBasicQuestion(element))
                }
            })
            this.questions = complexSmallQuestion
        } else {
            this.questions = []
            this.questions.push(this.inputQuestion)
        }
    },
    methods: {
        onClickTagDetail: function (e) {
            let key = e.target.dataset['key']
            let tagArray = []
            $.each(this.inputTags[key], (index, tag) => {
                tagArray.push(`${index + 1}.${tag.name}`)
            })
            this.$modalMessage({
                title: '标注详情',
                offset: ['400px', '600px'],
                needOperation: false,
                msg: tagArray
            })
        },
        // 组装基本题型
        privateBuildBasicQuestion: function (data) {
            let question = {
                type: data.type,
                body: {
                    stem: data.stem,
                    answer: data.answer,
                    analysis: data.analysis
                }
            }
            return question
        }
    },
    computed: {
        // computedMethodAnalysisObjectKeysLength () {
        //     return Object.keys(this.inputQuestion.body.analysis.detail).length
        // }
    },
    watch: {
        inputSourceDataArray: function (newVal, oldVal) {
            let tmpSource = Object.assign({}, newVal[0])
            let tmpName = []
            for (let item in tmpSource) {
                if (item.split('name').length > 1 || item === 'note') {
                    tmpName.push(tmpSource[item])
                }
            }
            this.sourceData = tmpName.length === 0 ? ['暂无来源信息'] : tmpName
        },
        inputQuestion: {
            handler: function (newVal) {
                // 如果 题型 是复合题
                if (newVal.type === Question.Complex.type) {
                    // 处理成基本题型的数据格式
                    let complexSmallQuestion = []
                    newVal.body.questions.forEach(element => {
                        // 新增小题，题目不选的情况下 element为undefined
                        if (element) {
                            complexSmallQuestion.push(this.privateBuildBasicQuestion(element))
                        }
                    })
                    this.questions = complexSmallQuestion
                } else {
                    this.questions = []
                    this.questions.push(newVal)
                }
            },
            deep: true
        }
    }
}
</script>

<style lang="scss" scoped>
    $font-color: #838a9b;
    .preview-wrapper {
        .section {
            padding-left: 20px;
        }
        .source {
            margin-top: 18px;
        }
        .header {
            padding-left: 20px;
            height: 60px;
            border-bottom: 1px solid #eceff4;
            font-size: 16px;
            color: $font-color;
            line-height: 70px;
        }
        //试题来源
        .header-source {
            display: inline-block;
            margin-top: 5px;
            padding: 5px 15px;
            font-size: 12px;
            color: #b1b8c9;
            text-align: center;
            background-color: #f1f5f8;
            border-radius: 10px;
        }
        //题干样式
        .stem {
            margin: 30px 0 20px 0;
            font-size: 16px;
            color: #2f2f2f;
            word-wrap: break-word;
            word-break: break-all;
        }
        .section-title {
            display: inline-block;
            position: relative;
            width: 62px;
            height: 26px;
            margin-top: 50px;
            margin-bottom: 19px;
            line-height: 26px;
            font-size: 14px;
            color: $font-color;
            border-radius: 5px;
            text-align: center;
            background-color: #f1f5f8;
        }
        .section-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            right: -7px;
            border-width: 0px 10px 10px 0px;
            border-style: solid;
            border-color: #f1f5f8 transparent;
        }
        .option-item, .answer-item {
            // margin-top: 20px;
            display: flex;
            line-height: 36px;
            text-align: left;
            color: #5b6376;
            font-size: 14px;
            word-wrap: break-word;
            word-break: break-all;
            div {
                display: inline-block;
                width: 100%;
            }
        }
        .pair-option {
            display: flex;
            justify-content: space-around;
            word-wrap: break-word;
            word-break: break-all;

            .options-left, .options-right {
                width: 100%;
            }
        }
        .cloze-option {
            word-wrap: break-word;
            word-break: break-all;
            ul {
                display: inline-block;
                width: 90%;
            }
            li {
                display: inline-block;
                width: 25%;
                vertical-align: top;
                div {
                    width: 80%;
                    vertical-align: top;
                }
            }
        }
        .wordstosen-option {
            word-wrap: break-word;
            word-break: break-all;

            div {
                display: inline-block;
            }
        }
        .answer {
            font-size: 16px;
            line-height: 36px;
            color: $font-color;
        }
        .analysis {
            font-size: 14px;
            color: $font-color;
        }
        .analysis-item {
            line-height: 27px;
            word-wrap: break-word;
            word-break: break-all;
            div {
                display: inline-block;
                width: 95%;
                vertical-align: top;
            }
        }
        .tag {
            .tag-container {
                .tag-item {
                    word-wrap: break-word;
                    word-break: break-all;
                    span {
                        font-size: 14px;
                        color: #838a9b;
                        letter-spacing: 1px;
                    }
                    button.btn-tag-detail {
                        font-size: 12px;
                        color: #6e86fd;
                        letter-spacing: 1px;
                    }
                }
            }
        }
    }
</style>
