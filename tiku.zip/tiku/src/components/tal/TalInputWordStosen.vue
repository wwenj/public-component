<template>
    <div>
        <!-- <Datepicker field="myDate"
        placeholder="选择日期"
        v-model="date"
        format="yyyy-mm-dd"
        :backward="true"
        :no-today="true"
        :forward="false">
        </Datepicker> -->
        <!-- 题干组件 -->
        <tal-question-stem-body
        ref="questionStemBody"
        :inputText="inputQuestion.body.stem.body"
        @textChangeEmit='textChangeEmit'>
        </tal-question-stem-body>
        <span class='body-text'>试题说明，可以为空（填入连词成句词语后，此处可不填）</span>
        <!-- 多词组件 -->
        <tal-question-more-word
        ref="questionMoreWord"
        :inputMoreWord="inputQuestion.body.stem.options"
        @moreWordChangeEmit='moreWordChangeEmit'>
        </tal-question-more-word>

        <!-- 答案组件 -->
        <tal-question-subjective-answer
        ref="questionAnswer"
        :inputAnswerData="inputQuestion.body.answer"
        @subjectiveAnswerEmit="subjectiveAnswerEmit">
        </tal-question-subjective-answer>

        <!-- 解析组件 -->
        <tal-question-analysis
        ref="questionAnalysis"
        :inputQuestionType="inputQuestion.type"
        :inputAnalysisData="inputQuestion.body.analysis"
        @anaysisObjectChangeEmit='anaysisObjectChangeEmit'>
        </tal-question-analysis>
    </div>
</template>
<script>
import TalQuestionSubjectiveAnswer from '@/components/tal/TalQuestionSubjectiveAnswer'
import TalQuestionStemBody from '@/components/tal/TalQuestionStemBody'
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'
import TalQuestionMoreWord from '@/components/tal/TalQuestionMoreWord'
import { Question, QuestionTypeCollection } from '@/common/constant'
// import Datepicker from '@/components/datepicker/Datepicker'

export default {
    components: {
        TalQuestionSubjectiveAnswer,
        TalQuestionStemBody,
        TalQuestionMoreWord,
        TalQuestionAnalysis
    },
    props: {
        // 题目信息数据，父组件传递,一键复制vuex
        inputQuestion: {
            type: Object,
            default: function () {
                return {
                    type: Question.WordStosen.type,
                    body: {
                        stem: {
                            body: '',
                            options: {}
                        },
                        answer: {
                            type: QuestionTypeCollection.AnswerType.Content,
                            items: ''
                        },
                        analysis: {
                            enabled: 1,
                            type: QuestionTypeCollection.AnalysisType.Content,
                            detail: {
                                '1': ''
                            }
                        }
                    }
                }
            }
        }
    },
    mounted () {
        this.$emit('initQuestionEmit', this.outputQuestionObject())
    },
    data () {
        return {
            // date: '',
            questionData: {
                type: Question.WordStosen.type,
                body: {
                    stem: {
                        body: '',
                        options: {
                        }
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Content,
                        items: ''
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {
                            '1': ''
                        }
                    }
                }
            }
        }
    },
    methods: {
        /* TalQuestionAnalysis emit */
        anaysisObjectChangeEmit: function () {
            this.questionData.body.analysis = this.$refs.questionAnalysis.outputAnalysisObject()
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionSubjectiveAnswer emit */
        subjectiveAnswerEmit: function (answer) {
            this.questionData.body.answer = answer
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionStemBody emit */
        textChangeEmit: function () {
            this.questionData.body.stem.body = this.$refs.questionStemBody.outputText()
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionMoreWord emit */
        moreWordChangeEmit: function () {
            this.questionData.body.stem.options = this.$refs.questionMoreWord.outputText()
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* output */
        outputQuestionObject: function () {
            let question = {}
            question.type = Question.WordStosen.type
            question.body = {
                stem: {
                    body: this.questionData.body.stem.body,
                    options: this.questionData.body.stem.options
                },
                answer: this.questionData.body.answer,
                analysis: this.questionData.body.analysis
            }
            return question
        },
        /* public */
        // 保存报错接口函数
        checkQuestionError: function () {
            let questionError = []
            let outOptions = Object.values(this.$refs.questionMoreWord.text).map((item) => {
                return item.replace(/<[^>]+>/g, '')
            })
            let outOption = outOptions.join('').split('').sort().join('')
            let outAnswer = this.$refs.questionAnswer.outputText.replace(/<[^>]+>/g, '').replace('</p>', '').split('').sort().join('')
            let questionMoreWordDiff = []
            if (outOption !== outAnswer) {
                questionMoreWordDiff.push('答案中使用词语与备选词语不同')
            }
            let questionMoreWordErrorArray = this.$refs.questionMoreWord.verifyQuestionMoreWord()
            let questionAnswerErrorArray = this.$refs.questionAnswer.verifyQuestionAnswer()
            let questionAnalysisErrorArray = this.$refs.questionAnalysis.verifyQuestionAnalysis()

            questionError = [...questionMoreWordErrorArray,
                             ...questionAnswerErrorArray,
                             ...questionMoreWordDiff,
                             ...questionAnalysisErrorArray]
            return questionError
        }
    },
    watch: {
        inputQuestion: function (newval) {
            // 深度拷贝， 防止引用
            // 一键复制以后， this.questionData 和this.inputQuestion 相同，但指向的不是同一块地址
            this.questionData = JSON.parse(JSON.stringify(newval))
        }
    }
}
</script>
<style lang="scss" scoped>
.body-text {
  position: relative;
  top: -34px;
  font-size: 12px;
  color: #999;
}
</style>
