<template>
    <div class="wrapper-filling-answer">
        <div class="title">答案</div>
        <div class="content">
                <div class="answer-item" v-for="(item, index) in answerArray" :key="index">
                    <span class="answer-index">空{{index + 1}}答案 : </span>
                    <div class="input-line">
                        <editor :inputIndex="parseInt(index)" :inputText="item.textInput" @editorEmit="editorEmit"></editor>
                    </div>
                    <select class="select" v-model="item.type" @change="selectOnChange">
                        <option :value="0">请选择类型</option>
                        <option v-for='(item, index) in fillingAnswerType' :key="index" :value="index">{{item}}</option>
                    </select>
                </div>
        </div>
    </div>
</template>

<script>
import { stringIsEmpty } from '@/common/common'
import { fillingAnswerType } from '@/common/constant'
export default {
    props: {
        inputAnswerItem: {
            type: Object,
            default: () => {
                return {
                }
            }
        }
    },
    data () {
        return {
            answerArray: [],
            fillingAnswerType
        }
    },
    created () {
        this.privateInitData(this.inputAnswerItem)
    },
    methods: {
        /* action */
        selectOnChange: function () {
            this.$emit('answerItemEmit', this.outputAnswerObject())
        },
        /* editor emit */
        editorEmit: function (res) {
            let index = res.index
            let text = res.text

            this.answerArray[index]['textOutput'] = text
            this.$emit('answerItemEmit', this.outputAnswerObject())
        },
        /* public */
        verifyQuestionAnswer: function () {
            let items = this.outputAnswerObject()
            let answerErrorArray = []
            let isAnswerHasError = false
            let isAnswerTypeHasError = false
            for (let key in items) {
                if (!stringIsEmpty(items[key].value) && !isAnswerHasError) {
                    answerErrorArray.push('答案不能为空，请完善答案内容')
                    isAnswerHasError = true
                }
                if (items[key].type === 0 && !isAnswerTypeHasError) {
                    answerErrorArray.push('答案类型未选择，请选择答案类型')
                    isAnswerTypeHasError = true
                }
            }
            return answerErrorArray
        },
        /* private */
        onChangeBlank: function (count, answerItems) {
            let tempItems = {}
            let answer = {}
            if (Object.keys(this.inputAnswerItem).length === 0) {
                answer = answerItems
            } else {
                answer = this.inputAnswerItem
            }
            for (let i = 1; i <= count; i++) {
                tempItems[i] = answer[i] ? answer[i] : {value: '', type: 0}
            }
            console.log('tempItems', tempItems)
            this.privateInitData(tempItems)
            this.$emit('answerItemEmit', this.outputAnswerObject())
        },
        privateInitData: function (answerObject) {
            this.answerArray = []
            for (let key in answerObject) {
                this.answerArray.push({
                    textInput: answerObject[key].value,
                    textOutput: answerObject[key].value,
                    type: answerObject[key].type
                })
            }
        },
        /* End private */
        /* ouput */
        outputAnswerObject: function (data) {
            let items = {}
            this.answerArray.forEach((ele, index) => {
                items[index + 1] = {}
                items[index + 1].value = ele.textOutput
                items[index + 1].type = +ele.type
            })
            return items
        }
        /* End ouput */
    },
    watch: {
        inputAnswerItem: function (newVal) {
            this.privateInitData(newVal)
        }
    }
}
</script>

<style lang="scss" scoped>
.wrapper-filling-answer {
    padding: 20px 0;
    min-height: 60px;

    .content {
        padding-top: 20px;

        .answer-item {
            display: flex;
            flex-direction: row;
            align-items: center;

            .answer-index {
                width: 90px;
                margin-right: 5px;
                font-size: 14px;
                letter-spacing: 1px;
                color: #b1b8c9;
            }

            .input-line {
                width: calc( 100% - 80px)
            }
            .select {
                width: 130px;
                border-radius: 4px;
            }
        }

        .answer-item:not(:last-child) {
            margin-bottom: 10px;
        }
    }
}
</style>


