<template>
    <div class="cloze-answer-wrapper">
        <div class="title">答案</div>
        <div class="answer-input-box">
            <input type="text" @blur="answerOnBlur" v-model="answerString" :placeholder="placeholderMessage" class="text-input">
        </div>
    </div>
</template>

<script>
import { stringIsEmpty } from '@/common/common'
export default {
    props: {
        inputAnswerObject: {
            type: Object,
            default () {
                return {}
            }
        },
        inputOptionsCount: {
            type: Number,
            default: 6
        }
    },
    data () {
        return {
            answerString: '',
            placeholderMessage: '',
            answerObject: this.inputAnswerObject
        }
    },
    created () {
        this.privateInitData(this.inputAnswerObject)
    },
    methods: {
        /* action */
        answerOnBlur: function () {
            // 字母界限，即最后一个的key
            let letterBoundary = 'D'
            console.log('字母边界', letterBoundary)
            // 获取答案的个数
            let answerCount = Object.keys(this.answerObject).length
            console.log('答案个数', answerCount)
            // 输入框要展示的临时字符串
            let tmpAnswerString = ''
            // 计数器，放进this.answerObject 的个数
            let count = 0
            // 正则输入的字符串，保留所有的字母并全部大写
            this.answerString = this.answerString.replace(/[^a-zA-Z]/g, '').toUpperCase()
            // 遍历字符串，放弃超过边界的字母
            for (let i = 0; i < this.answerString.length; i++) {
                // 如果当前字母小于边界值，则将其放进 this.answerObject
                if (this.answerString[i] <= letterBoundary) {
                    if (count < answerCount) {
                        // this.answerObject[++count] = this.answerString[i]
                        ++count
                        tmpAnswerString += this.answerString[i]
                    }
                }
            }
            this.placeholderMessage = '请输入答案'
            this.answerString = tmpAnswerString
            console.log('答案个数', this.answerString.length)
            console.log('选项个数', this.inputOptionsCount)
            if (this.answerString.length !== this.inputOptionsCount) {
                this.answerString = ''
            }
            this.$emit('clozeAnswerObjectChangeEmit', this.outputAnswerObject)
        },
        /* public */
        verifyQuestionAnswer: function () {
            let answerObject = this.outputAnswerObject()
            for (let key in answerObject) {
                if (!stringIsEmpty(answerObject[key])) {
                    return ['答案不能为空，请完善答案内容']
                }
            }
            return []
        },
        refresh: function (answerObject) {
            console.log('refresh answerObject', answerObject)
            this.answerObject = answerObject
            this.privateInitData(answerObject)
        },
        /* output */
        outputAnswerObject: function () {
            let answerObject = {}
            let length = Object.keys(this.answerObject).length
            for (let i = 0; i < length; i++) {
                if (this.answerString[i]) {
                    answerObject[i + 1] = this.answerString[i]
                } else {
                    answerObject[i + 1] = ''
                }
            }
            console.log('answerObject', answerObject)
            return answerObject
        },
        /* private */
        privateInitData: function (answerObject) {
            this.answerString = ''
            for (let key in answerObject) {
                this.answerString += answerObject[key]
            }
        }
    },
    watch: {
        inputAnswerObject: function (newVal) {
            // watch 只针对一键复制
            this.privateInitData(newVal)
            this.answerObject = newVal
            this.$emit('clozeAnswerObjectChangeEmit', this.outputAnswerObject)
        }
    }
}
</script>

<style lang="scss" scoped>
.cloze-answer-wrapper {
    margin-top: 41px;
    margin-bottom: 40px;
    .answer-input-box {
        margin-top: 32px;
        white-space: nowrap;
    }
}
</style>

