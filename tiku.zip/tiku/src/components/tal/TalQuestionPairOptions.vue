<template>
    <div class="pair-options-wrapper">
        <div class="title">选项</div>
        <div class="options-wrapper">
            <div class="options-left">
                <div class="options-item" v-for="(item, index) in leftOptionsArray" :key="item.id">
                    <span>{{index + 1}}.</span> <input type="text" v-model="item.text" @input="updateTextOnInput" class="text-input">
                </div>
            </div>
            <div class="options-right">
                <div class="options-item" v-for="(item, index) in rightOptionsArray" :key="item.id">
                    <span>{{privateGetOptionTitleWithIndex(index)}}.</span> <input type="text" v-model="item.text" @input="updateTextOnInput" class="text-input">
                    <img src="@/assets/img/recording/del.png" alt="del" @click="deleteOnClick(index)">
                </div>
            </div>
        </div>
        <button class="add-btn" @click="addOnClick" :disabled="!computedCanAddNewOptions" :class="[!computedCanAddNewOptions ? 'btn-disabled' : '']">
            <img src="@/assets/img/recording/add.png" alt="+" v-if="computedCanAddNewOptions">
            <img src="@/assets/img/recording/gray.png" alt="+" v-else>
            <span>更多选项</span>
        </button>
    </div>
</template>

<script>
import { stringIsEmpty } from '@/common/common'
export default {
    props: {
        // 最多选项个数, 默认10
        inputMaxCount: {
            type: Number,
            default: 10
        },
        // 选项对象
        inputOptions: {
            type: Object,
            default () {
                return {
                    left: {
                        1: '',
                        2: '',
                        3: '',
                        4: ''
                    },
                    right: {
                        A: '',
                        B: '',
                        C: '',
                        D: ''
                    }
                }
            }
        }
    },
    data () {
        return {
            leftOptionsArray: [],
            rightOptionsArray: [],
            // option 的id, 防止vue对dom的就地复用
            // 两个id始终保持一致， 同增同减
            nextLeftOptionId: 10,
            nextRightOptionId: 10
        }
    },
    created () {
        this.privateInitData(this.inputOptions)
    },
    methods: {
        /* action */
        addOnClick: function () {
            this.leftOptionsArray.push({id: this.nextLeftOptionId++, text: ''})
            this.rightOptionsArray.push({id: this.nextRightOptionId++, text: ''})
            this.$emit('optionObjectChangeEmit')
        },
        deleteOnClick: function (index) {
            this.leftOptionsArray.splice(index, 1)
            this.rightOptionsArray.splice(index, 1)
            this.$emit('optionObjectChangeEmit')
        },
        updateTextOnInput: function () {
            this.$emit('optionObjectChangeEmit')
        },
        /* public */
        verifyQuestionOptions: function () {
            let optionObject = this.outputOptionsObject()
            let optionLeftObject = optionObject.left
            let optionRightObject = optionObject.right
            for (let key in optionLeftObject) {
                if (!stringIsEmpty(optionLeftObject[key])) {
                    return ['题目内容不能为空，请完善题目内容']
                }
            }
            for (let key in optionRightObject) {
                if (!stringIsEmpty(optionRightObject[key])) {
                    return ['题目内容不能为空，请完善题目内容']
                }
            }
            return []
        },
        /* private */
        privateInitData: function (inputOptions) {
            this.leftOptionsArray = []
            this.rightOptionsArray = []
            // 处理选项左半部分
            for (let leftKey in inputOptions.left) {
                this.leftOptionsArray.push({id: this.nextLeftOptionId++, text: this.inputOptions.left[leftKey]})
            }
            // 处理选项右半部分
            for (let rightKey in inputOptions.right) {
                this.rightOptionsArray.push({id: this.nextRightOptionId++, text: this.inputOptions.right[rightKey]})
            }
        },
        privateGetOptionTitleWithIndex: function (index) {
            return String.fromCharCode(65 + index)
        },
        /* output */
        outputOptionsObject: function () {
            let that = this
            let options = {}
            options.left = {}
            options.right = {}
            this.leftOptionsArray.forEach((item, index) => {
                options['left'][index + 1] = item.text
            })
            this.rightOptionsArray.forEach((item, index) => {
                options['right'][that.privateGetOptionTitleWithIndex(index)] = item.text
            })
            return options
        }
    },
    computed: {
        computedCanAddNewOptions: function () {
            return this.leftOptionsArray.length < this.inputMaxCount
        }
    },
    watch: {
        inputOptions: {
            handler: function (newVal) {
                this.privateInitData(newVal)
            },
            deep: true
        }
    }
}
</script>

<style lang="scss" scoped>
.pair-options-wrapper {
    margin-bottom: 30px;
    .options-wrapper {
        display: flex;
        flex-direction: row;
        margin-bottom: 32px;
        .text-input {
            width: 80%;
        }
        .options-left {
            flex: 1;
        }
        .options-right {
            flex: 1;
        }
        .options-item {
            margin-top: 22px;
            span {
                display: inline-block;
                width: 17px;
                font-size: 16px;
                color: #2f2f2f;
            }
        }
    }
}
</style>

