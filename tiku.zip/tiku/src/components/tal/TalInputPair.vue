<template>
    <div class="pair-wrapper">
        <!-- 题干组件 -->
        <tal-question-stem-body
        ref='questionStemBody'
        :inputText='inputQuestion.body.stem.body'
        @textChangeEmit='textChangeEmit'>
        </tal-question-stem-body>

        <!-- 选项组件 -->
        <tal-question-pair-options
        ref="questionOptions"
        :inputOptions='inputQuestion.body.stem.options'
        @optionObjectChangeEmit='optionObjectChangeEmit'>
        </tal-question-pair-options>

        <!-- 答案组件 -->
        <tal-question-pair-answer
        ref="questionAnswer"
        :inputAnswerObject='inputQuestion.body.answer.items'
        :inputOptionsCount='computedOptionsCount'
        @answerObjectChangeEmit='answerObjectChangeEmit'>
        </tal-question-pair-answer>

        <!-- 解析组件 -->
        <tal-question-analysis
        ref="questionAnalysis"
        :inputQuestionType='inputQuestion.type'
        :inputOptionsCount='computedOptionsCount'
        :inputAnalysisData='inputQuestion.body.analysis'
        @anaysisObjectChangeEmit='anaysisObjectChangeEmit'>
        </tal-question-analysis>
    </div>
</template>

<script>
// TODO 配对题的校验规则、 配对题查重时 查重校验规则
import { QuestionTypeCollection, Question } from '@/common/constant'
import TalQuestionStemBody from '@/components/tal/TalQuestionStemBody'
import TalQuestionPairOptions from '@/components/tal/TalQuestionPairOptions'
import TalQuestionPairAnswer from '@/components/tal/TalQuestionPairAnswer'
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'
export default {
    components: {
        TalQuestionStemBody,
        TalQuestionPairOptions,
        TalQuestionPairAnswer,
        TalQuestionAnalysis
    },
    props: {
        inputQuestion: {
            type: Object,
            default () {
                return {
                    type: Question.Pair.type,
                    body: {
                        stem: {
                            body: '',
                            options: {
                                left: {
                                    1: '',
                                    2: '',
                                    3: '',
                                    4: ''
                                },
                                right: {
                                    A: '',
                                    B: '',
                                    C: '',
                                    D: ''
                                }
                            }
                        },
                        answer: {
                            type: QuestionTypeCollection.AnswerType.Pair,
                            items: {
                                1: '',
                                2: '',
                                3: '',
                                4: ''
                            }
                        },
                        analysis: {
                            enabled: 1,
                            type: QuestionTypeCollection.AnalysisType.Content,
                            detail: {
                                1: ''
                            }
                        }
                    }
                }
            }
        }
    },
    data () {
        return {
            questionData: {
                type: Question.Pair.type,
                body: {
                    stem: {
                        body: '',
                        options: {
                            left: {
                                1: '',
                                2: '',
                                3: '',
                                4: ''
                            },
                            right: {
                                A: '',
                                B: '',
                                C: '',
                                D: ''
                            }
                        }
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Pair,
                        items: {
                            1: '',
                            2: '',
                            3: '',
                            4: ''
                        }
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {
                            1: ''
                        }
                    }
                }
            }
        }
    },
    created () {
        this.$emit('initQuestionEmit', this.outputQuestionObject())
    },
    methods: {
        /* TalQuestionStemBody */
        textChangeEmit: function () {
            let body = this.$refs.questionStemBody.outputText()
            this.$set(this.questionData.body.stem, 'body', body)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionPairOptions emit */
        optionObjectChangeEmit: function () {
            let options = this.$refs.questionOptions.outputOptionsObject()
            this.$set(this.questionData.body.stem, 'options', options)
            // 比较选项和答案的个数，通过判断他们的大小，来决定下一步的操作
            if (this.computedOptionsCount > this.computedAnswerCount) {
                // 让答案增加一个
                this.$set(this.questionData.body.answer.items, this.computedOptionsCount, '')
                this.$refs.questionAnswer.refresh(this.questionData.body.answer.items)
            } else if (this.computedOptionsCount < this.computedAnswerCount) {
                // 删除一个答案并清空答案和解析
                this.$delete(this.questionData.body.answer.items, this.computedAnswerCount)
                for (let key in this.questionData.body.answer.items) {
                    this.$set(this.questionData.body.answer.items, key, '')
                }
                for (let key in this.questionData.body.analysis.detail) {
                    this.$set(this.questionData.body.analysis.detail, key, '')
                }
                this.$refs.questionAnswer.refresh(this.questionData.body.answer.items)
                this.$refs.questionAnalysis.refreshAnalysisData(this.questionData.body.analysis.detail)
            }
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionPairAnswer */
        answerObjectChangeEmit: function () {
            console.log('answerObject', this.$refs.questionAnswer)
            let answerObject = this.$refs.questionAnswer.outputAnswerObject()
            this.$set(this.questionData.body.answer, 'items', answerObject)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionAnalysis emit */
        anaysisObjectChangeEmit: function () {
            let analysis = this.$refs.questionAnalysis.outputAnalysisObject()
            this.$set(this.questionData.body, 'analysis', analysis)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* public */
        checkQuestionError: function () {
            console.log('配对题校验')
            let questionError = []

            let questionOptionsErrorArray = this.$refs.questionOptions.verifyQuestionOptions()
            let questionAnswerErrorArray = this.$refs.questionAnswer.verifyQuestionAnswer()
            let questionStemBodyErrorArray = this.$refs.questionStemBody.verifyQuestionStemBody()
            let questionAnalysisErrorArray = this.$refs.questionAnalysis.verifyQuestionAnalysis()

            questionError = [...questionStemBodyErrorArray,
                             ...questionOptionsErrorArray,
                             ...questionAnswerErrorArray,
                             ...questionAnalysisErrorArray]

            return questionError
            // return ['配对题校验未完成']
        },
        /* output */
        outputQuestionObject: function () {
            return this.questionData
        }
    },
    computed: {
        computedOptionsCount: function () {
            return Object.keys(this.questionData.body.stem.options.left).length
        },
        computedAnswerCount: function () {
            return Object.keys(this.questionData.body.answer.items).length
        }
    },
    watch: {
        inputQuestion: function (newVal) {
            this.questionData = JSON.parse(JSON.stringify(newVal))
        }
    }
}
</script>

<style lang="scss" scoped>

</style>

