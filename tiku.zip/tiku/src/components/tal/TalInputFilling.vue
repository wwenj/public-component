<template>
    <div class="wrapper-filling">
        <!-- 题干组件 -->
        <tal-question-stem-body-with-blank
        ref="questionStemBody"
        :inputText='inputQuestion.body.stem.body'
        @editorEmit='stemEmit'
        @countBlankEmit='onChangeBlank'>
        </tal-question-stem-body-with-blank>

        <!-- 答案组件 -->
        <div class="section section-answer">
            <tal-question-filling-answer
            ref="questionFillingAnswer"
            :inputAnswerItem="inputQuestion.body.answer.items"
            @answerItemEmit="answerItemEmit">
            </tal-question-filling-answer>
        </div>
        <!-- 解析组件 -->
        <div class="section section-analysis">
            <tal-question-analysis
            ref="questionAnalysis"
            :inputOptionsCount="computedOptionsCount"
            :inputAnalysisData="inputQuestion.body.analysis"
            :inputQuestionType="inputQuestion.type"
            @anaysisObjectChangeEmit="anaysisObjectChangeEmit">
            </tal-question-analysis>
        </div>
        <!-- <button class="btn-toggle-mathjax" @click="onClickToggleMathJax">Toggle</button> -->
    </div>
</template>

<script>
import $ from 'jquery'
import TalQuestionFillingAnswer from '@/components/tal/TalQuestionFillingAnswer'
import TalQuestionStemBodyWithBlank from '@/components/tal//TalQuestionStemBodyWithBlank'
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'

import { Question, AnswerType, AnalysisType } from '@/common/constant'


export default {
    components: {
        TalQuestionFillingAnswer,
        TalQuestionStemBodyWithBlank,
        TalQuestionAnalysis
    },
    props: {
        inputQuestion: {
            type: Object,
            default: () => {
                return {
                    type: Question.Filling.type,
                    body: {
                        stem: {
                            body: '',
                            options: {}
                        },
                        answer: {
                            type: AnswerType.Blanks,
                            items: {}
                        },
                        analysis: {
                            enabled: 1,
                            type: AnalysisType.Content,
                            detail: {
                                '1': ''
                            }
                        }
                    }
                }
            }
        }
    },
    data () {
        return {
            Question,
            fillingQuestionData: {
                type: Question.Filling.type,
                body: {
                    stem: {
                        body: '',
                        options: {}
                    },
                    answer: {
                        type: AnswerType.Blanks,
                        items: {}
                    },
                    analysis: {
                        enabled: 1,
                        type: AnalysisType.Content,
                        detail: {
                            '1': ''
                        }
                    }
                }
            }
        }
    },
    created () {
        this.$emit('initQuestionEmit', this.inputQuestion)
    },
    methods: {
        /* action */
        onChangeBlank: function (count) {
            this.$refs.questionFillingAnswer.onChangeBlank(count, this.fillingQuestionData.body.answer.items)
        },
        /* End action */

        /* emit */
        stemEmit: function (res) {
            this.$set(this.fillingQuestionData.body.stem, 'body', res.text)
            this.$emit('questionChangeEmit', this.fillingQuestionData)
        },

        answerItemEmit: function (res) {
            console.log('填空题答案', res)
            this.$set(this.fillingQuestionData.body.answer, 'items', res)
            this.$emit('questionChangeEmit', this.fillingQuestionData)
        },

        anaysisObjectChangeEmit: function (res) {
            this.$set(this.fillingQuestionData.body, 'analysis', res)
            this.$emit('questionChangeEmit', this.fillingQuestionData)
        },
        /* End emit */

        /* public */
        checkQuestionError: function () {
            let questionsError = []
            let questionAnswerErrorArray = []
            let questionStemBodyErrorArray = this.$refs.questionStemBody.verifyQuestionStemBody()

            if (this.computedOptionsCount > 0) {
                questionAnswerErrorArray = this.$refs.questionFillingAnswer.verifyQuestionAnswer()
            }

            let questionAnalysisErrorArray = this.$refs.questionAnalysis.verifyQuestionAnalysis()

            questionsError = [...questionStemBodyErrorArray,
                              ...questionAnswerErrorArray,
                              ...questionAnalysisErrorArray]

            return questionsError
        },
        /* End public */
        /* output */
        outputQuestionObject: function () {
            return this.fillingQuestionData
        },
        onClickToggleMathJax: function () {
            /* eslint-disable */
            var self = this
            self.typeText = self.isTypeset ? 'Typeset Math' : 'Remove Typeset Math'
            MathJax.Hub.Queue(
                (self.isTypeset ? self.removeMathJax : ["Typeset", MathJax.Hub]),
                function () {
                    self.isTypeset = ! self.isTypeset
                }
            )
            /* eslint-enable */
        },

        removeMathJax: function () {
            /* eslint-disable */
            let jax = MathJax.Hub.getAllJax()
            $.each(jax, (index, item) => {
                let tex = item.originalText
                let isDisplay = (item.root.Get("display") === "block")
                if (isDisplay) tex = `$$${tex}$$`
                else tex = `$${tex}$`
                let script = item.SourceElement()
                item.Remove()
                let preview = script.previousSibling
                if (preview && preview.className === "MathJax_Preview") preview.parentNode.removeChild(preview)
                script.parentNode.insertBefore(document.createTextNode(tex), script)
                script.parentNode.removeChild(script)
            })
            /* eslint-enable */
        }
    },
    computed: {
        computedOptionsCount: function () {
            return Object.keys(this.fillingQuestionData.body.answer.items).length
        }
    },
    watch: {
        inputQuestion: function (newVal) {
            // handler: function (newVal) {
                console.log('填空题watch', newVal)
                this.fillingQuestionData = JSON.parse(JSON.stringify(newVal))
            // },
            // deep: true
        }
    }
}
</script>

<style lang="scss" scoped>
// .wrapper-filling {
//     padding-right: 30px;
//     width: 100%;
//     height: auto;
//     min-height: calc(100% - 132px);
//     box-sizing: border-box;
// }
</style>


