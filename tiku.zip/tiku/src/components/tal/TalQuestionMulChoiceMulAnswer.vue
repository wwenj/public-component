<template>
    <div class="mul-choice-mul-answer">
        <div class="title">答案</div>
        <div class="answer-content">
            <div v-for="(answerItem, index) in answerObject" :key="index" class="answer-item">
               <span>空 {{index}} :</span>
               <span v-for="item in inputOptionsCount" :key="item" class="answer-radio">
                   <!-- 单选按钮name为index，即一行为一个radiogroup -->
                   {{privateGetOptionTitleWithIndex(item - 1)}}<input type="radio" :name="random + index" v-model="answerObject[index]" :value="privateGetOptionTitleWithIndex(item - 1)" @change="choiceAnswerOnChange()">
               </span>
            </div>
        </div>
        <div class="answer-input-box">
            <input type="text" @blur="answerOnBlur" v-model="answerString" placeholder="请输入答案" class="text-input">
        </div>
    </div>
</template>

<script>
import { stringIsEmpty } from '@/common/common'
export default {
    props: {
        // answer中的items
        inputAnswerObject: {
            type: Object,
            default () {
            }
        },
        // 选项的个数，通过选项个数展示ABCDEFG
        inputOptionsCount: {
            type: Number,
            default: 4
        }
    },
    data () {
        return {
            answerObject: {},
            answerString: '',
            random: 'mulChoMul' + Math.random() * 100000000000000000 // 防止同一个页面有多个该组件，单选按钮混乱
        }
    },
    created () {
        this.privateInitData()
    },
    methods: {
        /* action */
        choiceAnswerOnChange: function () {
            this.privateAnswerObjectChangeToString()
            this.$emit('choiceAnswerEmit')
        },
        answerOnBlur: function () {
            // 字母界限，即最后一个的key
            let letterBoundary = this.privateGetOptionTitleWithIndex(this.inputOptionsCount - 1)
            console.log('字母边界', letterBoundary)
            // 获取答案的个数
            let answerCount = Object.keys(this.answerObject).length
            // 输入框要展示的临时字符串
            let tmpAnswerString = ''
            // 计数器，放进this.answerObject 的个数
            let count = 0
            // 正则输入的字符串，保留所有的字母并全部大写
            this.answerString = this.answerString.replace(/[^a-zA-Z]/g, '').toUpperCase()
            // 遍历字符串，放弃超过边界的字母
            for (let i = 0; i < this.answerString.length; i++) {
                // 如果当前字母小于边界值，则将其放进 this.answerObject
                if (this.answerString[i] <= letterBoundary) {
                    if (count < answerCount) {
                        this.answerObject[++count] = this.answerString[i]
                        tmpAnswerString += this.answerString[i]
                    }
                }
            }
            this.answerString = tmpAnswerString
            this.$emit('choiceAnswerEmit')
        },
        /* output */
        outputAnswerObject: function () {
            return this.answerObject
        },
        verifyQuestionAnswer: function () {
            // 答案没有被填写的个数
            let i = 0
            let questionErrorArray = []
            for (let key in this.answerObject) {
                if (!stringIsEmpty(this.answerObject[key])) {
                    i++
                }
            }
            // 答案为空的情况
            if (i === Object.keys(this.answerObject).length) {
                questionErrorArray.push('答案不能为空，请完善答案内容')
            } else if (i > 0) {
                // 答案没有全部填写的情况
                questionErrorArray.push('答案不完整，请给出全部空格的答案')
            }
            return questionErrorArray
        },
        /* private */
        privateGetOptionTitleWithIndex: function (index) {
            return String.fromCharCode(65 + index)
        },
        privateInitData: function () {
            this.answerObject = JSON.parse(JSON.stringify(this.inputAnswerObject))
            this.privateAnswerObjectChangeToString()
        },
        privateAnswerObjectChangeToString: function () {
            this.answerString = ''
            for (let key in this.answerObject) {
                console.log(this.answerObject[key])
                this.answerString += this.answerObject[key]
            }
        }
    },
    watch: {
        inputAnswerObject: {
            handler: function () {
                this.privateInitData()
            },
            deep: true
        }
    }
}
</script>

<style lang="scss" scoped>
.mul-choice-mul-answer {
    margin-bottom: 41px;
    .answer-content {
        // display: flex;
    }
    .answer-item {
        display: flex;
        align-items: center;
        margin-top: 23px;
        white-space: nowrap;
        color: #2f2f2f;
        span:first-child {
            width: 43px;
            font-size: 14px;
        }
        .answer-radio {
            flex: 1;
            text-align: center;
            font-size: 18px;
            input[type='radio'] {
                margin-left: 8px;
                vertical-align: 20%;
            }
        }
    }
    .answer-input-box {
        margin-top: 32px;
        white-space: nowrap;
    }
}
</style>


