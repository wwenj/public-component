<template>
    <div class="stme-body-wrapper">
        <div class="title">题干 <span> ( 添加 "_______" )</span></div>
        <span class="info-text">说明:富文本编辑器支持截图图片粘贴上传，图片文件拖拽上传</span>
        <editor
        :needBlank='true'
        :inputText='inputText'
        @editorEmit='editorEmit'
        @countBlankEmit='countBlankEmit'>
        </editor>
    </div>
</template>

<script>
import { stringIsEmpty } from '@/common/common'
export default {
    props: {
        inputText: {
            type: String,
            default: ''
        }
    },
    data () {
        return {
            text: ''
        }
    },
    methods: {
        /* emit */
        editorEmit: function (data) {
            this.text = data.text
            this.$emit('editorEmit', data)
        },
        countBlankEmit: function (count) {
            // 通过bus同步题干空格数与答案个数
            // this.$bus.$emit('refreshFillingAnswerData', this.fillingQuestionData.body.answer.items)
            this.$emit('countBlankEmit', count)
        },
        /* output */
        outputText: function () {
            return this.text
        },
        verifyQuestionStemBody: function () {
            let questionError = []
            if (!stringIsEmpty(this.text)) {
                questionError.push(`题干内容不能为空，请完善题干内容`)
            }
            // 第一个正则校验的是从本录题项目中录进去的题
            // 第二个正则校验的是一键复制的题，他的横线使用10个或10个以上的nbsp组成的
            if (!((/▁+/.test(this.text) || (/(&nbsp;){10,}/.test(this.text))))) {
                questionError.push(`填空题题干必须包含'▁▁▁▁▁'，请完善题干内容`)
            }
            return questionError
        }
    }
    // watch: {
    //     inputText: function () {
    //         console.log('stem change')
    //     }
    // }
}
</script>

<style lang="scss" scoped>
.stme-body-wrapper {
    margin-bottom: 23px;
    .title {
        margin-bottom: 21px;
        span {
            font-size: 12px;
            line-height: 32px;
            color: #838a9b;
        }
    }
}
</style>

