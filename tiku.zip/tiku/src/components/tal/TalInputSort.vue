<template>
    <div class="sort-wrapper">
        <!-- 题干组件 -->
        <tal-question-stem-body
        ref='questionStemBody'
        :inputText='inputQuestion.body.stem.body'
        @textChangeEmit='textChangeEmit'>
        </tal-question-stem-body>

        <!-- 选项组件 -->
        <tal-question-options
        ref="questionOptions"
        :inputQuestionType='inputQuestion.type'
        :inputOptionObject='inputQuestion.body.stem.options'
        :inputCurrentCount='computedOptionsCount'
        @optionObjectChangeEmit='optionObjectChangeEmit'
        @allChangeEmit='allChangeEmit'
        @deleteOptionSyncAnalysisEmit='deleteOptionSyncAnalysisEmit'>
        </tal-question-options>

        <!-- 答案组件 -->
        <tal-question-sort-answer
        ref="questionAnswer"
        :inputAnswerString='inputQuestion.body.answer.items'
        :inputOptionsCount='computedOptionsCount'
        @answerObjectChangeEmit='answerObjectChangeEmit'>
        </tal-question-sort-answer>

        <!-- 解析组件 -->
        <tal-question-analysis
        ref="questionAnalysis"
        :inputQuestionType='inputQuestion.type'
        :inputOptionsCount='computedOptionsCount'
        :inputAnalysisData='inputQuestion.body.analysis'
        @anaysisObjectChangeEmit='anaysisObjectChangeEmit'>
        </tal-question-analysis>
    </div>
</template>

<script>
// TODO 排序题校验规则，提示文案、
import { QuestionTypeCollection, Question } from '@/common/constant'
import TalQuestionStemBody from '@/components/tal/TalQuestionStemBody'
import TalQuestionOptions from '@/components/tal/TalQuestionOptions'
import TalQuestionSortAnswer from '@/components/tal/TalQuestionSortAnswer'
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'
export default {
    components: {
        TalQuestionStemBody,
        TalQuestionOptions,
        TalQuestionSortAnswer,
        TalQuestionAnalysis
    },
    props: {
        inputQuestion: {
            type: Object,
            default () {
                return {
                    type: Question.Sort.type,
                    body: {
                        type: 7,
                        stem: {
                            body: '',
                            options: {
                                A: '',
                                B: '',
                                C: '',
                                D: '',
                                E: ''
                            }
                        },
                        answer: {
                            type: QuestionTypeCollection.AnswerType.Letters,
                            items: ''
                        },
                        analysis: {
                            enabled: 1,
                            type: QuestionTypeCollection.AnalysisType.Content,
                            detail: {
                                1: ''
                            }
                        }
                    }
                }
            }
        }
    },
    data () {
        return {
            questionData: {
                type: Question.Sort.type,
                body: {
                    type: 7,
                    stem: {
                        body: '',
                        options: {
                            A: '',
                            B: '',
                            C: '',
                            D: '',
                            E: ''
                        }
                    },
                    answer: {
                        type: QuestionTypeCollection.AnswerType.Letters,
                        items: ''
                    },
                    analysis: {
                        enabled: 1,
                        type: QuestionTypeCollection.AnalysisType.Content,
                        detail: {
                            1: ''
                        }
                    }
                }
            }
        }
    },
    created () {
        this.$emit('initQuestionEmit', this.outputQuestionObject())
    },
    methods: {
        /* TalQuestionStemBody emit */
        textChangeEmit: function () {
            let body = this.$refs.questionStemBody.outputText()
            this.$set(this.questionData.body.stem, 'body', body)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionOption emit */
        optionObjectChangeEmit: function () {
            let options = this.$refs.questionOptions.outputOptionObject()
            this.$set(this.questionData.body.stem, 'options', options)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        allChangeEmit: function () {
            let options = this.$refs.questionOptions.outputOptionObject()
            this.$set(this.questionData.body.stem, 'options', options)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        deleteOptionSyncAnalysisEmit: function () {
            // 清空答案和解析(答案组件和解析组件)
            this.questionData.body.answer.items = ''
            this.$refs.questionAnswer.refresh(this.questionData.body.answer.items)
            for (let key in this.questionData.body.analysis.detail) {
                this.$set(this.questionData.body.analysis.detail, key, '')
            }
            this.$refs.questionAnalysis.refreshAnalysisData(this.questionData.body.analysis.detail)
        },
        /* TalQuestionSortAnswer emit */
        answerObjectChangeEmit: function () {
            let answerString = this.$refs.questionAnswer.outputAnswerObject()
            this.$set(this.questionData.body.answer, 'items', answerString)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* TalQuestionAnalysis emit */
        anaysisObjectChangeEmit: function () {
            let analysis = this.$refs.questionAnalysis.outputAnalysisObject()
            this.$set(this.questionData.body, 'analysis', analysis)
            this.$emit('questionChangeEmit', this.outputQuestionObject())
        },
        /* public */
        checkQuestionError: function () {
            // TODO 校验待完成
            console.log('我是排序题的校验')
            let questionError = []

            let questionOptionsErrorArray = this.$refs.questionOptions.verifyQuestionOptions()
            let questionAnswerErrorArray = this.$refs.questionAnswer.verifyQuestionAnswer()
            let questionStemBodyErrorArray = this.$refs.questionStemBody.verifyQuestionStemBody()
            let questionAnalysisErrorArray = this.$refs.questionAnalysis.verifyQuestionAnalysis()

            questionError = [...questionStemBodyErrorArray,
                             ...questionOptionsErrorArray,
                             ...questionAnswerErrorArray,
                             ...questionAnalysisErrorArray]

            return questionError
        },
        /* output */
        outputQuestionObject: function () {
            return this.questionData
        }
    },
    computed: {
        computedOptionsCount: function () {
            return Object.keys(this.questionData.body.stem.options).length
        }
    },
    watch: {
        inputQuestion: function (newval) {
            // 深度拷贝， 防止引用
            // 一键复制以后， this.questionData 和this.inputQuestion 相同，但指向的不是同一块地址
            this.questionData = JSON.parse(JSON.stringify(newval))
        }
    }
}
</script>

<style lang="scss" scoped>

</style>
