<template>
    <div class="options-wrapper">
        <ul>
            <li class="optionsList" v-for="(option, index) in optionArray" :key="option.id">
                <!-- v-show 与 v-if的区别 https://www.cnblogs.com/Rexxar/p/5578441.html -->
                <div v-if="index < currentCount">
                    <button :class="[privateGetOptionSelectClassNameByIndex(index)]" :disabled="!computedCanOptionTitleButtonEnable" @click="answerOnClick(index)">{{ privateGetOptionTitleWithIndex(index) }}</button>
                    <!-- // TODO -->
                    <editor class="editor" :inputIndex="index" @editorEmit='editorGetHtml' :inputText='option.textInput'></editor>
                    <img src="@/assets/img/recording/del.png" alt="del" @click="deleteOnClick(index)">
                </div>
            </li>
        </ul>
        <button class="add-btn" @click="addOnClick" :disabled="!computedCanAddNewOptions" :class="[!computedCanAddNewOptions ? 'btn-disabled' : '']">
            <img src="@/assets/img/recording/add.png" alt="+" v-if="computedCanAddNewOptions">
            <img src="@/assets/img/recording/gray.png" alt="+" v-else>
            <span>更多选项</span>
        </button>
    </div>

</template>
<script>
import { QuestionTypeCollection, Question } from '@/common/constant'
import { stringIsEmpty } from '@/common/common'
export default {
    props: {
        // 控制初始显示选项个数，从0开始默认为4个
        inputCurrentCount: {
            type: Number,
            default: 4
        },
        // 选项能增加的最大数量，默认为15
        inputMaxCount: {
            type: Number,
            default: 15
        },
        // 选项删除剩余的最小数量，默认为2
        inputMinCount: {
            type: Number,
            default: 2,
            validator: function (value) {
                // 这个会报错
                // return value <= this.inputMaxCount
                return value <= 100
            }
        },
        // 题目类型
        // 目前支持如下4种
        // 单选,多选,多选多,排序
        inputQuestionType: {
            type: Number,
            default: Question.SingleChoice.type,
            validator: function (value) {
                return (
                    value === Question.SingleChoice.type ||
                    value === Question.MulChoice.type ||
                    value === Question.MulChoiceMul.type ||
                    value === Question.Sort.type
                )
            }
        },
        // 录入的选项
        inputOptionObject: {
            type: Object,
            default () {
                return {}
            }
        },
        // 输入的答案
        inputAnswerObject: {
            type: Object,
            default () {
                return {
                    type: QuestionTypeCollection.AnswerType.Letters,
                    items: ''
                }
            }
        }
    },
    data () {
        return {
            currentCount: this.inputCurrentCount, // 选项显示个数
            answerArray: [], // 选择的答案列表
            optionArray: [] // 渲染选项的数组结构
        }
    },
    created () {
        this.privateInitOptionData(this.inputOptionObject)
        this.privateInitAnswerData(this.inputAnswerObject)
        // this.privateInitData(this.inputOptionObject, this.inputAnswerObject)
    },
    mounted () {},
    methods: {
        /* action */
        // 增加选项
        addOnClick: function () {
            let optionArrayLength = this.optionArray.length
            if (this.currentCount === optionArrayLength) {
                alert(`最多添加${this.inputMaxCount}个选项哦！`)
            } else {
                this.currentCount += 1
            }
            this.$emit('allChangeEmit')
        },
        // 删除选项
        deleteOnClick: function (index) {
            if (this.currentCount === this.inputMinCount) {
                alert(`最少剩余${this.inputMinCount}个选项哦！`)
            } else {
                // 更新选项数据
                let deleteOptionArray = this.optionArray.splice(index, 1)
                let deleteOption = deleteOptionArray[0]
                deleteOption.textInput = ''
                deleteOption.textOutput = ''
                this.optionArray.push(deleteOption)
                this.currentCount -= 1
                // 更新答案数据,每当删除一条数据的时候,清空所有答案
                this.answerArray = []

                // 产品定的 -- 当删除某一个选项时，清空答案和解析
                this.$emit('deleteOptionSyncAnalysisEmit')
                this.$emit('allChangeEmit')
            }
        },
        // 点击选项前字符返回选中答案
        answerOnClick: function (index) {
            if (this.inputQuestionType === Question.SingleChoice.type) {
                this.answerArray = [index]
            } else if (this.inputQuestionType === Question.MulChoice.type) {
                // 多选题， 首先检查在answerArray中是否已经存在，如果存在，则删除掉，如果不存在，则push进去
                let answerString = this.answerArray.join('')
                if (answerString.indexOf(index) !== -1) {
                    let tmpIndex = answerString.indexOf(index)
                    answerString = answerString.substr(0, tmpIndex) + answerString.substr(tmpIndex + 1, answerString.length)
                    // 将answerString.split()分割后的数组中的字符串格式的转成数字格式
                    this.answerArray = answerString.split('').map((curVal) => {
                        return parseInt(curVal)
                    })
                } else {
                    this.answerArray.push(index)
                    // 为了让答案按ABCD顺序输出
                    this.answerArray.sort()
                }
            }
            // 每次改变答案都会向父组件返回操作
            this.$emit('answerObjectChangeEmit')
        },
        /* emit */
        // 富文本编辑器失焦返回
        editorGetHtml: function (data) {
            let text = data.text
            let index = data.index
            let option = this.optionArray[index]
            option.textOutput = text
            // 每次富文本编辑器失焦就向父组件返回操作
            this.$emit('optionObjectChangeEmit')
        },
        /* public */
        refresh: function (optionObject, answerObject) {
            this.privateInitData(optionObject, answerObject)
        },
        // 校验选项
        verifyQuestionOptions: function () {
            let optionsObject = this.outputOptionObject()
            let questionErrorArray = []
            for (let key in optionsObject) {
                if (!stringIsEmpty(optionsObject[key])) {
                    questionErrorArray.push(`选项${key}不能为空,请完善选项内容`)
                }
            }
            return questionErrorArray
        },
        // 校验答案 此处校验分为 单选题答案校验和多选题答案校验
        verifyQuestionAnswer: function () {
            let answerObject = this.outputAnswerObject()
            let questionErrorArray = []
            if (this.inputQuestionType === Question.SingleChoice.type) {
                this.privateVerifySingleChoiceAnswer(questionErrorArray, answerObject)
            } else if (this.inputQuestionType === Question.MulChoice.type) {
                this.privateVerifyMulChoiceAnswer(questionErrorArray, answerObject)
            }
            return questionErrorArray
        },
        /* output */
        // 父组件预留操作函数，便于获取子组件数据
        outputOptionObject: function () {
            let option = {}
            for (let i = 0; i < this.currentCount; i++) {
                let item = this.optionArray[i]
                let text = item.textOutput
                let key = this.privateGetOptionKeyWithIndex(i)
                option[key] = text
            }
            return option
        },
        outputAnswerObject: function () {
            let answerTitleArray = []
            let answerArrayLength = this.answerArray.length
            for (let i = 0; i < answerArrayLength; i++) {
                let index = this.answerArray[i]
                let title = this.privateGetOptionKeyWithIndex(index)
                answerTitleArray.push(title)
            }
            let answerItems = answerTitleArray.join('')
            let answer = {
                type: this.inputAnswerObject.type,
                items: answerItems
            }
            return answer
        },
        outputCount: function () {
            return this.currentCount
        },
        /* private */
        // 校验单选题的答案
        privateVerifySingleChoiceAnswer: function (questionErrorArray, answerObject) {
            if (!stringIsEmpty(answerObject.items)) {
                questionErrorArray.push('答案不能为空，请完善答案内容')
            }
        },
        // 校验多选题的答案
        privateVerifyMulChoiceAnswer: function (questionErrorArray, answerObject) {
             // 直接检验字符串的长度，如果为0,则答案为空，如果为1，则只选择了一个答案
            if (answerObject.items.length === 0) {
                questionErrorArray.push('答案不能为空，请完善答案内容')
            } else if (answerObject.items.length === 1) {
                questionErrorArray.push('答案个数不足，请至少选择2个答案')
            }
        },
        // 计算选项的标题,
        privateGetOptionTitleWithIndex: function (index) {
            let title = String.fromCharCode(65 + index)
            if (!this.computedCanOptionTitleButtonEnable) {
                title = title + '.'
            }
            return title
        },
        privateGetOptionKeyWithIndex: function (index) {
            return String.fromCharCode(65 + index)
        },
        privateGetIndexWithOptionTitle: function (title) {
            // 将来可以根据类型进行switch,case
            return title.charCodeAt() - 65
        },
        // 得到按钮的样式
        privateGetOptionSelectClassNameByIndex: function (index) {
            if (!this.computedCanOptionTitleButtonEnable) {
                return 'btn-disable'
            }
            let answerArrayLength = this.answerArray.length
            for (let i = 0; i < answerArrayLength; i++) {
                let value = this.answerArray[i]
                if (value === index) {
                    return 'btn btn-active'
                }
            }
            return 'btn'
        },
        privateInitOptionData: function (optionObject) {
            this.optionArray = []
            let tmpOptionArray = []
            for (let key in optionObject) {
                let value = optionObject[key]
                tmpOptionArray.push(value)
            }
            let tmpOptionArrayLength = tmpOptionArray.length
            for (let i = 0; i < this.inputMaxCount; i++) {
                let text = ''
                if (i < tmpOptionArrayLength) {
                    text = tmpOptionArray[i]
                }
                let value = {
                    // 这个id是用于Dom重新加载用的v-key,跟选项的顺序没有对应关系
                    // 因为我们有可能删除选项或者添加选项
                    id: i,
                    // 这个还是一个问题,需要调查
                    textInput: text,
                    textOutput: text
                }
                this.optionArray.push(value)
            }
        },
        privateInitAnswerData: function (answerObject) {
            this.answerArray = []
            let items = answerObject.items
            // console.log('单选题答案', items)
            let answerTitleArray = items.split('')
            let answerTitleArrayLength = answerTitleArray.length
            for (let i = 0; i < answerTitleArrayLength; i++) {
                let title = answerTitleArray[i]
                let index = this.privateGetIndexWithOptionTitle(title)
                this.answerArray.push(index)
            }
        }
    },
    computed: {
        // 是否可以添加新的选项
        computedCanAddNewOptions () {
            return this.currentCount < this.inputMaxCount
        },
        // 选项标题按钮是否可被点击
        computedCanOptionTitleButtonEnable () {
            let result =
                this.inputQuestionType === Question.SingleChoice.type ||
                this.inputQuestionType === Question.MulChoice.type
            return result
        }
    },
    watch: {
        // 监听一键复制的改变并重新赋值
        inputAnswerObject: function (newval) {
            this.privateInitAnswerData(newval)
            // this.privateInitData(this.inputOptionObject, newval)
        },
        inputOptionObject: function (newval) {
            // console.log('选项的watch')
            this.privateInitOptionData(newval)
            // this.privateInitData(newval, this.inputAnswerObject)
        },
        inputCurrentCount: function (newval) {
            this.currentCount = this.inputCurrentCount
        }
    }
}
</script>
<style lang="scss" scoped>
.options-wrapper {
    margin-bottom: 41px;
    .optionsList {
        margin-bottom: 20px;
    }
    .btn-disable {
        width: 36px;
        height: 36px;
        font-size: 16px;
        color: #5f7aff;
        background-color: #f5f6f8;
        border-radius: 4px;
        border: solid 0px #5f7aff;
    }
    .editor {
        width: calc(100% - 100px);
        padding: 0 15px;
    }
}

</style>



