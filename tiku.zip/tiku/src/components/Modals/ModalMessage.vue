<template>
    <div class="component-modal-message">
        <div class="mask"></div>
        <div class="modal-message-container" :style="{width: offset[0], height: offset[1]}">
            <div class="title-area">
                <p class="close-line">
                    <button class="btn btn-close" @click='onClickClose'><img src="@/assets/img/common/icon-modal-close.png"></button>
                </p>
                <p class="title-line">{{title}}</p>
            </div>
            <div class="message-area" :style="{'text-align': align}">
                <p v-if="typeof(msg) == 'string'">{{msg}}</p>
                <p v-else-if="Object.prototype.toString.call(msg) == '[object Array]'" v-for="(item, index) in msg" :key="index">
                    <!-- <span v-if="needIndex">{{index+1}}.</span> -->
                    <!-- {{item}} -->

                    <span v-if="Object.prototype.toString.call(item) == '[object Object]'">
                        {{item.title}}
                        <p v-for="(item1, index) in item.errorMessage" :key="index">
                            {{index + 1}}.{{item1}}
                        </p>
                    </span>
                    <span v-else>
                        <span v-if="needIndex">{{index+1}}.</span>{{item}}
                    </span>
                </p>
                <p v-else-if="Object.prototype.toString.call(msg) == '[object Object]'" v-for="(item, index) in msg" :key="index">{{index}}.{{item}}</p>
            </div>
            <div class="operation-area" v-if="needOperation">
                <button class="btn"
                :class="{'btn-cancel': btn.length > 1 && index == 0, 'btn-confirm': btn.length == 1 || index == 1}"
                v-for="(item, index) in btn"
                :key="index"
                :data-index="index"
                @click="onClickButton">
                    {{item}}
                </button>
                <!-- <button class="btn btn-cancel" @click="onClickClose">取消</button>
                <button class="btn btn-confirm" @click="onClickConfirm">确定</button> -->
            </div>
        </div>
    </div>
</template>

<script>
import $ from 'jquery'
export default {
    data () {
        return {
            showMask: false,
            needIndex: false,
            offset: ['400px', '400px'],
            title: '提示',
            align: 'left',
            btn: ['取消', '确定'],
            msg: '',
            needOperation: true,
            confirm: function () {}
        }
    },
    methods: {
        onClickButton: function (e) {
            let index = e.target.dataset['index']
            if (this.btn.length === 1 || index === '1') {
                this.confirm(true)
            } else if (this.btn.length > 1 && index === '0') {
                $('.component-modal-message').remove()
            }
        },

        onClickClose: function () {
            $('.component-modal-message').remove()
        },

        onClickConfirm: function () {
            this.confirm(true)
        }
    }
}
</script>

<style lang="scss" scoped>
.component-modal-message {
    position: absolute;
    width: 100%;
    height: 100%;
    z-index: 100000;

    .mask {
        width: 100%;
        height: 100%;
        background: #333;
        opacity: 0.5;
    }

    .modal-message-container {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        margin: auto;
        border-radius: 15px;
        background: #fff;

        .title-area {
            position: absolute;
            top: 0;
            width: 100%;
            height: 80px;
            background: url("../../assets/img/common/modal-title-background.png");

            .close-line {
                height: 30px;
                line-height: 30px;
                text-align: right;

                .btn-close {
                    margin-right: 10px;
                    width: 30px;
                    height: 20px;
                    border: none;

                    img {
                        width: 100%;
                        height: 100%;
                        vertical-align: top;
                    }
                }
            }

            .title-line {
                line-height: 24px;
                font-family: "PingFangSC-Semibold";
                font-size: 24px;
                text-align: center;
                letter-spacing: 1px;
                color: #fff;
            }
        }

        .message-area {
            overflow-y: auto;
            position: absolute;
            top: 80px;
            bottom: 85px;
            margin: 20px auto;
            padding: 0 40px;
            width: 100%;
            box-sizing: border-box;

            p {
                margin-top: 10px;
                line-height: 30px;
                font-family: 'MicrosoftYaHei';
                font-size: 18px;
                letter-spacing: 1px;
                color: #2f2f2f;;
            }
        }

        .operation-area {
            position: absolute;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            width: 100%;
            height: 85px;

            button:not(:last-child) {
                margin-right: 20px;
            }

            .btn-cancel {
                width: 160px;
                height: 36px;
                font-size: 14px;
                letter-spacing: 1px;
                color: #6e86fd;
                border: 1px solid #6e86fd;
                border-radius: 18px;
            }
            .btn-confirm {
                width: 160px;
                height: 36px;
                font-size: 14px;
                letter-spacing: 1px;
                color: #fff;
                background-image: linear-gradient(
                    90deg,
                    #5f7aff 0%,
                    #6bc1fe 100%
                );
                border: none;
                border-radius: 18px;
            }
        }
    }
}
</style>


