import Vue from 'vue'
import $ from 'jquery'
import ModalMessage from '@/components/Modals/ModalMessage'
import ModalCorrect from '@/components/Modals/ModalCorrect'

ModalMessage.installModalMessage = function (options) {
    var Modalmessage = Vue.extend(ModalMessage)

    var component = new Modalmessage({
        data: options
    }).$mount()
    $('#app').append(component.$el)
}

ModalMessage.closeModalMessage = function () {
    $('.component-modal-message').remove()
}

ModalCorrect.installModalCorrect = function (options) {
    var Mdoalcorrect = Vue.extend(ModalCorrect)

    var component = new Mdoalcorrect({
        data: options
    }).$mount()

    $('#app').append(component.$el)
}

ModalCorrect.closeModalCorrect = function () {
    $('.component-modal-correct').remove()
}

export var Modal = {
    ModalMessage,
    ModalCorrect
}
