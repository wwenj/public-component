<template>
    <div class="component-modal-correct">
        <div class="mask"></div>
        <div class="modal-correct-container" :style="{width: offset[0], height: offset[1]}">
            <div class="title-area">
                <p class="close-line">
                    <button class="btn btn-close" @click='onClickClose'><img src="@/assets/img/common/icon-modal-close.png"></button>
                </p>
                <p class="title-line">{{title}}</p>
            </div>
            <div class="correct-area">
                <el-radio :class="correctType == '' && warning ? 'warning' : '' " v-model="correctType" label='录入有误'>录入有误</el-radio>
                <div class="text-area">
                    <textarea placeholder="请输入错误原因" v-model="correctReason" @keyup="onKeyUpReason"></textarea>
                    <span class="count-container" :class="currentCount >= 300 ? 'warning': ''">{{currentCount}}/{{totalCount}}</span>
                </div>
                <transition name='fade'>
                    <p class="warning-info" v-show="warning">错误原因不能为空</p>
                </transition>
            </div>
            <div class="operation-area">
                <button class="btn btn-confirm" @click="onClickConfirm">完成</button>
                <button class="btn btn-cancel" @click="onClickClose">取消</button>
            </div>
        </div>
    </div>
</template>

<script>
import $ from 'jquery'
// import request from '@/common/request'

export default {
    data () {
        return {
            showMask: false,
            offset: ['400px', '400px'],
            title: '提示',
            msg: '',
            correctType: '',
            correctReason: '',
            warning: false,
            totalCount: 300,
            confirm: function () {}
        }
    },
    methods: {
        onClickClose: function () {
            $('.component-modal-correct').remove()
        },

        onClickConfirm: function () {
            var self = this
            if (this.verifyCorrect()) {
                let obj = {
                    qid: this.qid,
                    description: this.correctReason,
                    subject_id: 2,
                    report_type_id: 3
                }
                this.$api['questionTag/tagQuestionReport'](obj)
                // request.reportQuestion(obj)
                .then(res => {
                    self.confirm(true)
                })
                .catch(err => {
                    console.log(err)
                })
            }
        },

        onKeyUpReason: function () {
            if (this.currentCount > 300) this.correctReason = this.correctReason.substring(0, 300)
        },

        verifyCorrect: function () {
            this.correctReason = this.correctReason.replace(/^\s+|\s+$/g, '')
            console.log(this.correctReason)
            if (this.correctType === '' || this.correctReason === '') {
                this.warning = true
                return false
            } else return true
        }
    },
    computed: {
        currentCount: function () {
            return this.correctReason.length
        }
    },
    watch: {
        correctType: function (newVal, oldVal) {
            if (newVal !== '') this.warning = false
        },

        correctReason: function (newVal, oldVal) {
            if (newVal !== '') this.warning = false
        }
    }
}
</script>

<style lang="scss">
.component-modal-correct {
    position: absolute;
    width: 100%;
    height: 100%;
    z-index: 100000;

    .mask {
        width: 100%;
        height: 100%;
        background: #333;
        opacity: 0.5;
    }

    .modal-correct-container {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        margin: auto;
        border-radius: 15px;
        background: #fff;

        .title-area {
            position: absolute;
            top: 0;
            width: 100%;
            height: 80px;
            background: url("../../assets/img/common/modal-title-background.png");

            .close-line {
                height: 30px;
                line-height: 30px;
                text-align: right;

                .btn-close {
                    margin-right: 10px;
                    width: 30px;
                    height: 16px;
                    border: none;

                    img {
                        width: 100%;
                        height: 100%;
                        vertical-align: top;
                    }
                }
            }

            .title-line {
                line-height: 24px;
                font-family: "PingFangSC-Semibold";
                font-size: 24px;
                text-align: center;
                letter-spacing: 1px;
                color: #fff;
            }
        }

        .correct-area {
            overflow-y: auto;
            position: absolute;
            top: 80px;
            bottom: 85px;
            margin: 30px auto 0;
            padding: 0 40px;
            width: 100%;
            box-sizing: border-box;

            .warning .el-radio__inner {
                border: 1px solid #ff0000;
            }

            .text-area {
                position: relative;
                margin-top: 15px;
                padding: 10px;
                padding-bottom: 20px;
                width: 100%;
                height: 120px;
                background: #f5f6f8;
                border: 1px solid #d4d9e1;
                border-radius: 4px;
                box-sizing: border-box;

                textarea {
                    width: 100%;
                    height: 80px;
                    overflow: scroll;
                    resize: none;
                    color: #2f2f2f;
                    background: #f5f6f8;
                    border: none;
                    outline: none;

                }

                .count-container {
                    position: absolute;
                    bottom: 5px;
                    right: 10px;
                    font-size: 12px;
                    color: #2f2f2f;
                }

                .count-container.warning {
                    color: #ff0000;
                }
            }

            .warning-info {
                margin-top: 10px;
                font-family: 'MicrosoftYaHei';
                font-size: 12px;
                letter-spacing: 1px;
                color: #ff0000;
            }

            .warning-info::before {
                content: '';
                display: inline-block;
                width: 18px;
                height: 18px;
                background: url('~@/assets/img/common/icon-tips.png') no-repeat center;
                vertical-align: bottom;
            }

            .fade-enter-active, .fade-leave-active {
                transition: opacity .5s;
            }
            .fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
                opacity: 0;
            }
        }

        .operation-area {
            position: absolute;
            bottom: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            width: 100%;
            height: 85px;

            button:not(:last-child) {
                margin-right: 20px;
            }

            .btn-cancel {
                width: 160px;
                height: 36px;
                font-size: 14px;
                letter-spacing: 1px;
                color: #6e86fd;
                border: 1px solid #6e86fd;
                border-radius: 18px;
            }
            .btn-confirm {
                width: 160px;
                height: 36px;
                font-size: 14px;
                letter-spacing: 1px;
                color: #fff;
                background-image: linear-gradient(
                    90deg,
                    #5f7aff 0%,
                    #6bc1fe 100%
                );
                border: none;
                border-radius: 18px;
            }
        }
    }
}
</style>


