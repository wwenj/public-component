/* 题型公共组件 */
// 富文本编辑器
import Editor from '@/components/editor/Editor'

// 单项选择题
import TalInputSingleChoice from '@/components/tal/TalInputSingleChoice'

// 多项选择题
import TalInputMulChoice from '@/components/tal/TalInputMulChoice'

// 多选多题
import TalInputMulChoiceMul from '@/components/tal/TalInputMulChoiceMul'

// 填空题
import TalInputFilling from '@/components/tal/TalInputFilling'

// 解答题
import TalInputSubjective from '@/components/tal/TalInputSubjective'

// 判断题
import TalInputJudgement from '@/components/tal/TalInputJudgement'

// 配对题
import TalInputPair from '@/components/tal/TalInputPair'

// 排序题
import TalInputSort from '@/components/tal/TalInputSort'

// 复合题
import TalInputComplex from '@/components/tal/TalInputComplex'

// 连词成句题
import TalInputWordStosen from '@/components/tal/TalInputWordStosen'

// 完形填空
import TalInputCloze from '@/components/tal/TalInputCloze'

// 未知题型
import TalInputUnKnown from '@/components/tal/TalInputUnKnown'

// 题干组件
import TalQuestionStemBody from '@/components/tal/TalQuestionStemBody'

// 选择题选项组件
import TalQuestionOptions from '@/components/tal/TalQuestionOptions'

// 判断题选项组件
import TalQuestionJudgementOptions from '@/components/tal/TalQuestionJudgementOptions'

// 题目答案组件
import TalQuestionAnswer from '@/components/tal/TalQuestionAnswer'

// 题目解析组件
import TalQuestionAnalysis from '@/components/tal/TalQuestionAnalysis'

// 多词组件
import TalQuestionMoreWord from '@/components/tal/TalQuestionMoreWord'
/* End 题型公共组件 */

/* 预览公共组件 */
import TalPreviewItem from '@/components/tal/TalPreviewItem'
/* End 预览公共组件 */

/* 插件类公共组件 */
//弹出框-信息类型
import { Modal } from '@/components/Modals/index'
// 选择学校弹出层
import ChoiceSchool from '@/views/Compose/composeBase/ChoiceSchool'


//弹出框-标签树
import TagTree from '@/components/TagTree/index'
import ChapterTree from '@/components/TagTree/ChapterTree'

// 搜索框
import SearchBar from '@/components/SearchBar'
// 顶部导航栏你
import headerSlot from '@/views/Compose/composeBase/HeaderSlot'
/* End 插件类公共组件 */

//登录文本框输入错误提示信息
import TalErrorInput from "@/views/Login/TalErrorInput"

export default ( Vue ) => {
    /* 题型公共组件 */
    // 富文本编辑器
    Vue.component( 'Editor', Editor )
    // 题目解析组件
    // Vue.component( 'TalQuestionAnalysis', TalQuestionAnalysis )
    // 题干组件
    // Vue.component( 'TalQuestionStemBody', TalQuestionStemBody )
    // 选择题选项组件
    // Vue.component( 'TalQuestionOptions', TalQuestionOptions )
    // 判断题选项组件
    // Vue.component( 'TalQuestionJudgementOptions', TalQuestionJudgementOptions )
    // 答案组件
    // Vue.component( 'TalQuestionAnswer', TalQuestionAnswer )
    // 单项选择题
    Vue.component( 'TalInputSingleChoice', TalInputSingleChoice )
    // 多项选择题
    Vue.component( 'TalInputMulChoice', TalInputMulChoice )
    // 多选多题
    Vue.component( 'TalInputMulChoiceMul', TalInputMulChoiceMul )
    // 填空题
    Vue.component( 'TalInputFilling', TalInputFilling )
    // 判断题
    Vue.component( 'TalInputJudgement', TalInputJudgement )
    // 解答题
    Vue.component( 'TalInputSubjective', TalInputSubjective )
    // 配对题
    Vue.component( 'TalInputPair', TalInputPair )
    // 排序题
    Vue.component( 'TalInputSort', TalInputSort )
    // 复合题
    Vue.component( 'TalInputComplex', TalInputComplex )
    // 连词成句题
    Vue.component( 'TalInputWordStosen', TalInputWordStosen )
    // 完形填空题
    Vue.component( 'TalInputCloze', TalInputCloze)
    // 多词组件
    // Vue.component( 'TalQuestionMoreWord', TalQuestionMoreWord )
    // 未知题型
    Vue.component( 'UnKnown', TalInputUnKnown)
    /* End 题型公共组件 */

    /* 预览公共组件 */
    Vue.component( 'TalPreviewItem', TalPreviewItem )
    /* End 预览公共组件 */

    /* 插件类公共组件 */
    // 弹出框-信息类型
    Vue.component('ModalMessage', Modal.ModalMessage)
    Vue.prototype.$modalMessage = Modal.ModalMessage.installModalMessage
    Vue.prototype.$modalMessageClose = Modal.ModalMessage.closeModalMessage
    // 弹出框-纠错
    Vue.component('ModalCorrect', Modal.ModalCorrect)
    Vue.prototype.$modalCorrect = Modal.ModalCorrect.installModalCorrect
    Vue.prototype.$modalCorrectClose = Modal.ModalCorrect.closeModalCorrect
    // 弹出框-标签树
    Vue.component('TagTree', TagTree)
    Vue.prototype.$TagTree = TagTree.installTagTree
    Vue.prototype.$TagTreeClose = TagTree.closeTagTree

    Vue.component('ChapterTree', ChapterTree)
    // 搜索框
    Vue.component( 'SearchBar', SearchBar )
    // 选择学校
    Vue.component( 'ChoiceSchool', ChoiceSchool )
    Vue.component( 'headerSlot', headerSlot )
    /* End 插件类公共组件 */
    //登录文本框输入错误提示信息
    Vue.component( 'TalErrorInput', TalErrorInput )
}
