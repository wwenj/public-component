<template>
    <div class="search-bar" >
        <input type="text" v-model="searchInfo" :placeholder="placeholder" @keyup.enter="onClickSearch">
        <button class="btn btn-clear" v-if="searchInfo != ''" @click="onClickClear"></button>
        <button class="btn btn-search" @click="onClickSearch"></button>
        <div class="dropdown-list-container" v-if="showDropDownList">
            <ul class="dropdown-list">
                <li v-if="searchResult.length == 0"><span>暂无数据</span></li>
                <li v-for="(item, index) in searchResult" v-else>
                    <button class="btn-search-result-item" :data-index="index" :data-id="item.tag_node_id" @click="onClickSearchResultItem">{{item.word_path}}</button>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
import request from '@/common/request'

export default {
    props: {
        'placeholder': {
            type: String,
            default: '请输入标签关键词进行检索'
        },
        'qid': {
            type: String,
            default: ''
        }
    },
    data () {
        return {
            searchInfo: '',
            showDropDownList: false,
            searchResult: []
        }
    },
    created () {
        var self = this
        $(document).on('click', (e) => {
            if (!self.$el.contains(e.target)) self.showDropDownList = false
        })
    },
    methods: {
        onClickSearch: function () {
            var self = this
            let keyword = this.searchInfo.replace(/^\s+|\s+$/g, '')
            let obj = {
                keyword: keyword,
                qid: self.qid,
                subject_id: 2
            }
            this.$api['questionTag/tagSearchKeyword'](obj)
            .then((res) => {
                self.searchResult = res
                self.showDropDownList = true
            })
            .catch((err) => {
                self.searchResult = []
                self.showDropDownList = true
            })
        },

        onClickClear: function () {
            this.searchInfo = ''
        },

        onClickSearchResultItem: function (e) {
            let index = e.target.dataset['index']
            this.$emit('emitSearchItem', this.searchResult[index])
            this.searchResult = []
            this.showDropDownList = false
        }
    }
}
</script>

<style lang="scss" scoped>
.search-bar {
    position: relative;
    display: flex;
    flex-direction: row;
    align-items: center;
    width: 100%;
    height: 40px;

    input[type=text] {
        padding-left: 15px;
        padding-right: 25px;
        width: 100%;
        height: 38px;
        color: #b1b8c9;
        letter-spacing: 1px;
        border: solid 1px rgba(160, 171, 188, 0.22);
        border-radius: 4px 0 0 4px;
        box-sizing: border-box;
    }

    button.btn-clear {
        position: absolute;
        right: 50px;
        width: 10px;
        height: 10px;
        background: url('~@/assets/img/common/icon-close.png') no-repeat center center;
        transition: all .5s;
    }

    button.btn-clear:hover {
        transform: rotate(90deg)
    }

    button.btn-search {
        width: 40px;
        height: 40px;
        border-radius: 0 4px 4px 0;
        background: #6e86fd url(../assets/img/common/icon-search.png) center center no-repeat;
    }

    .dropdown-list-container {
        position: absolute;
        top: 50px;

        .dropdown-list {
            overflow: auto;
            padding: 10px 0;
            width: auto;
            max-width: 500px;
            max-height: 200px;
            background: #fff;
            border-radius: 4px;
            box-shadow: 0 1px 5px 2px #b1b8c9;

            span {
                display: inline-block;
                width: 100%;
                min-width: 200px;
                text-align: center;
                font-size: 12px;
                color: #2f2f2f;
            }

            button.btn-search-result-item {
                padding: 0 10px;
                width: auto;
                line-height: 32px;
                font-size: 12px;
                letter-spacing: 1px;
                text-align: left;
                color: #2f2f2f;
                border: none;
                box-sizing: border-box;
                cursor: pointer;
            }

            button.btn-search-result-item:hover {
                background: #f5f6f8;
            }
        }
    }

    .dropdown-list-container::before {
        content: '';
        position: absolute;
        top: -6px;
        left: 10px;
        display: block;
        width: 10px;
        height: 10px;
        background: #fff;
        transform: rotate(45deg);
        border-left: 1px solid #b1b8c9;
        border-top: 1px solid #b1b8c9;
    }
}
</style>


