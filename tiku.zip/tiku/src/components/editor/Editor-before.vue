<template>
    <div class="editor-wrapper">
        <!-- <div class="editor-container" :style="inputBoxStyle">
            <div class="toolbar" ref='toolbar' v-show="showToolBar"></div>
            <div class="text" ref='text' :style="{'z-index': showToolBar ? 101 : 100}"></div>
        </div> -->
    </div>
</template>

<script>
import $ from 'jquery'
export default {
    // props: {
    //     // 控制富文本编辑器框的样式，例：父组件计算属性中修改传入即可
    //     inputBoxStyle: {
    //         type: Object
    //     },
    //     // 父组件通过v-for渲染，传入index，每触发失焦事件时返回当前触发的index
    //     inputIndex: {
    //         type: Number,
    //         default: 0
    //     },
    //     // 一键复制时，父组件传来的数据，渲染在富文本编辑器中
    //     inputText: {
    //         type: String,
    //         default: ''
    //     },
    //     // 是否需要格式化富文本中的‘______’并计算个数
    //     needBlank: {
    //         type: Boolean,
    //         default: false
    //     }
    // },
    // data () {
    //     return {
    //         showToolBar: false,
    //         editor: null
    //     }
    // },
    // mounted () {
    //     var that = this
    //     var toolbar = this.$refs.toolbar
    //     var text = this.$refs.text
    //     var editor = new this.$wangEditor(toolbar, text)
    //     editor.customConfig.menus = [
    //         'bold', // 粗体
    //         'justify', // 对齐方式
    //         'image', // 插入图片
    //         'table', // 表格
    //         'code', // 插入代码
    //         'space' // 插入下划线(填空)
    //     ],
    //     editor.customConfig.zIndex = 100
    //     editor.customConfig.onfocus = function () {
    //         console.log('editor onfocus')
    //         that.removeMj()
    //         that.showToolBar = true
    //     }
    //     editor.customConfig.onblur = function (html) {
    //         console.log('editor onblur')
    //         that.showToolBar = false
    //         if (that.needBlank) that.refillBlank(html)
    //         else {
    //             let data = {
    //                 text: html,
    //                 index: that.inputIndex
    //             }
    //             that.$emit('editorEmit', data)
    //         }
    //     }
    //     editor.customConfig.onchange = function (html) {
    //         let data = {
    //             text: html,
    //             index: that.inputIndex
    //         }
    //         that.$emit('editorEmit', data)
    //     }

    //     editor.create()

    //     if (this.inputText) {
    //         editor.txt.html(`<p>${this.inputText}</p>`)
    //     }

    //     that.editor = editor

    //     $(editor.$textElem).blur()
    // },
    // methods: {
    //     refillBlank: function (html) {
    //         let _html = html
    //         $.each($(html).find('.blank'), (i, ele) => {
    //             let c = $($(html).find('.blank')[i]).html()
    //             _html = _html
    //                 .replace(
    //                     `<u class="blank">${c}</u>`,
    //                     `<u class="blank">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>`
    //                 )
    //                 .replace(`<br>`, ``)
    //         })
    //         $(this.editor.$textElem).html(_html)
    //         // this.editor.txt.html(_html)
    //         let data = {
    //             text: _html,
    //             index: this.inputIndex
    //         }
    //         this.$emit('editorEmit', data)
    //         this.$emit('countBlankEmit', this.countBlank(_html))
    //     },

    //     countBlank: function (html) {
    //         // 判断空格数量
    //         var blank = `<u class="blank">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>`
    //         var regex = new RegExp(blank, 'g')
    //         var result = html.match(regex)
    //         var count = !result ? 0 : result.length

    //         return count
    //     },
    //     removeMj: function (html) {
    //         var jax = MathJax.Hub.getAllJax()
    //         for (var i = 0, m = jax.length; i < m; i++) {
    //             var tex = jax[i].originalText
    //             var isDisplay = (jax[i].root.Get('display') === 'block')
    //             if (isDisplay) tex = '$$' + tex + '$$'; else tex = '$' + tex + '$'
    //             var script = jax[i].SourceElement()
    //             jax[i].Remove()
    //             var preview = script.previousSibling
    //             if (preview && preview.className === 'MathJax_Preview') { preview.parentNode.removeChild(preview)}
    //             script.parentNode.insertBefore(document.createTextNode(tex), script)
    //             script.parentNode.removeChild(script)
    //         }
    //         console.log('转换完以后的字符串', tex)
    //     }
    // },
    // watch: {
    //     inputText: function (newVal, oldVal) {
    //         console.log('watch: ', newVal)
    //         let currentVal = this.editor.txt.html()
    //         if (newVal !== oldVal && newVal !== currentVal) this.editor.txt.html(newVal)
    //     }
    // }
}
</script>

<style lang="scss" scoped>
.editor-wrapper {
    display: inline-block;
    width: 100%;

    .editor-container {
        position: relative;

        .toolbar {
            position: absolute;
            top: -40px;
            width: auto;
            max-width: 400px;
            height: 40px;
            background: #fff;
            z-index: 102;
        }

        .text {
            display: inline-block;
            min-height: 36px;
            width: 100%;
            font-size: 14px;
            font-family: 'MicrosoftYaHei' sans-serif;
            color: #2f2f2f;
            border: 1px solid #dcdcdc;
            border-radius: 4px;
            background-color: #fff;
            vertical-align: middle;
        }
    }

    img {
        margin-left: 10px;
    }
}
</style>


