<template>
    <div @click="clickEvent" class="editor-container">
        <script :id="randomId" name="content" type="text/plain"></script>
    </div>
</template>

<script>
import 'static/utf8-php/ueditor.config.js'
import 'static/utf8-php/ueditor.all.min.js'
import 'static/utf8-php/lang/zh-cn/zh-cn.js'
import 'static/utf8-php/ueditor.parse.min.js'

import 'static/utf8-php/kityformula-plugin/addKityFormulaDialog.js'
import 'static/utf8-php/kityformula-plugin/getKfContent.js'
import 'static/utf8-php/kityformula-plugin/defaultFilterFix.js'

import $ from 'jquery'
export default {
    props: {
        inputText: {
            type: String,
            default: ''
        },
        inputIndex: {
            type: Number,
            default: 0
        },
        // 是否需要格式化富文本中的‘______’并计算个数
        needBlank: {
            type: Boolean,
            default: false
        },
        ueditorPath: {
            // UEditor 代码的路径
            type: String,
            default: '/tiku/static/utf8-php/'
        },
        ueditorConfig: {
            // UEditor 配置项
            type: Object,
            default: function () {
                return {
                    toolbars: [
                        [
                            // 'undo',
                            // 'redo',
                            // '|',
                            'kityformula', // 公式编辑器
                            // 'fullscreen', // 全屏
                            // 'source', // HTML代码
                            // '|',
                            'bold', // 粗体
                            'italic', // 斜体
                            'underline', // 下划线
                            // '|',
                            // 'fontsize', // 字体大小
                            '|',
                            // 'preview', // 预览功能
                            'insertimage', // 图片上传
                            '|',
                            'horizontal', // 分割线
                            // 'pagebreak', // 分页符
                            '|',
                            'inserttable', // 插入表格
                            '|'
                            // 'scrawl'      // 涂鸦功能
                        ]
                    ],
                    autoFloatEnabled: false,
                    elementPathEnabled: false, // 删除元素路径
                    wordCount: false, // 删除计数器
                    initialFrameWidth: '100%', // 初始化编辑器宽度,默认1000
                    initialFrameHeight: 40, // 初始化编辑器的高度，默认40
                    // pageBreakTag: `_答案分割线_`, // 分页标识符
                    allowDivTransToP: false, // 允许进入编辑器的div标签自动变成p标签
                    // allHtmlEnabled: true, // 提交到后台的数据是否包含整个html
                    autoHeightEnabled: true,
                    // pasteplain: true // 纯文本粘贴
                    retainOnlyLabelPasted: true // 只保留标签，去除标签属性
                    // iframeCssUrl: '/themes/iframe.css'
                    // codeMirrorJsUrl: '/tiku/static/utf8-php/third-party/codemirror/codemirror.js',
                    // codeMirrorCssUrl: '/tiku/static/utf8-php/third-party/codemirror/codemirror.css'

                    // topOffset: 30,
                    // toolbarTopOffset: 32
                    // initialFrameHeight: '40' // 初始化编辑器高度,默认320
                }
            }
        }
    },
    data () {
        return {
            // 为了避免麻烦，每个编辑器实例都用不同的 id
            randomId: 'editor_' + Math.random() * 100000000000000000,
            instance: null,
            // scriptTagStatus -> 0:代码未加载，1:两个代码依赖加载了一个，2:两个代码依赖都已经加载完成
            scriptTagStatus: 0,
            timer: null // 定时器
        }
    },
    created () {
        if (window.UE !== undefined) {
            // 如果全局对象存在，说明编辑器代码已经初始化完成，直接加载编辑器
            this.scriptTagStatus = 2
            this.initEditor()
        } else {
            // 如果全局对象不存在，说明编辑器代码还没有加载完成，需要加载编辑器代码
            this.insertScriptTag()
        }
    },
    beforeDestroy () {
        // 组件销毁的时候，要销毁 UEditor 实例
        if (this.instance !== null && this.instance.destroy) {
            try {
                // 这个地方只有在复合题上下交换的时候，销毁报错
                this.instance.destroy()
            } catch (e) {
            }
        }
    },
    methods: {
        insertScriptTag () {
            let editorScriptTag = document.getElementById('editorScriptTag')
            let configScriptTag = document.getElementById('configScriptTag')

            // 如果这个tag不存在，则生成相关代码tag以加载代码
            if (editorScriptTag === null) {
                configScriptTag = document.createElement('script')
                configScriptTag.type = 'text/javascript'
                configScriptTag.src = this.ueditorPath + 'ueditor.config.js'
                configScriptTag.id = 'configScriptTag'

                editorScriptTag = document.createElement('script')
                editorScriptTag.type = 'text/javascript'
                editorScriptTag.src = this.ueditorPath + 'ueditor.all.js'
                editorScriptTag.id = 'editorScriptTag'
                let s = document.getElementsByTagName('head')[0]
                s.appendChild(configScriptTag)
                s.appendChild(editorScriptTag)
            }

            // 等待代码加载完成后初始化编辑器
            if (configScriptTag.loaded) {
                this.scriptTagStatus++
            } else {
                configScriptTag.addEventListener('load', () => {
                    this.scriptTagStatus++
                    configScriptTag.loaded = true
                    this.initEditor()
                })
            }

            if (editorScriptTag.loaded) {
                this.scriptTagStatus++
            } else {
                editorScriptTag.addEventListener('load', () => {
                    this.scriptTagStatus++
                    editorScriptTag.loaded = true
                    this.initEditor()
                })
            }

            this.initEditor()
        },
        initEditor () {
            var that = this
            // scriptTagStatus 为 2 的时候，说明两个必需引入的 js 文件都已经被引入，且加载完成
            if (this.scriptTagStatus === 2 && this.instance === null) {
                // Vue 异步执行 DOM 更新，这样一来代码执行到这里的时候可能 template 里面的 script 标签还没真正创建
                // 所以，我们只能在 nextTick 里面初始化 UEditor
                this.$nextTick(() => {
                    try {
                        that.instance = window.UE.getEditor(
                            that.randomId,
                            that.ueditorConfig
                        )
                        // ready 编辑器准备就绪后初始化该事件
                        that.instance.addListener('ready', () => {
                            // that.instance.setHeight(40)
                            that.instance.setContent(that.inputText)
                            let selector = '#' + that.randomId + ' .edui-editor-toolbarbox'
                            $(selector).css({
                                visibility: 'hidden',
                                height: '1px'
                            })
                        })
                        that.instance.addListener('contentChange', () => {
                            let data = {
                                text: that.instance.getContent(),
                                index: that.inputIndex
                            }
                            that.$emit('editorEmit', data)
                        })
                    } catch (e) {
                        console.log('error')
                    }

                    // 监听富文本编辑器获取到焦点事件
                    window.UE.getEditor(that.randomId).addListener(
                        'focus',
                        function (editor) {
                            let selector = '#' + that.randomId + ' .edui-editor-toolbarbox'
                            $(selector).css({
                                visibility: 'visible',
                                height: '32px'
                            })
                        }
                    )
                    // 监听富文本编辑器失去焦点函数
                    window.UE.getEditor(this.randomId).addListener(
                        'blur',
                        function (e1, e2, e3) {
                            clearTimeout(that.timer)
                            that.timer = setTimeout(() => {
                                console.log('200毫秒后失焦')
                                let selector =
                                    '#' +
                                    that.randomId +
                                    ' .edui-editor-toolbarbox'
                                $(selector).css({
                                    visibility: 'hidden',
                                    height: '1px'
                                })
                                that.countBlank()
                            }, 200)
                        }
                    )
                })
            }
        },
        clickEvent (event) {
            this.instance.focus()
            clearTimeout(this.timer)
        },
        countBlank () {
            let that = this
            that.$nextTick(() => {
                // 匹配答案分割线与填空横线，被破坏自动还原
                // 注：这里插入的横线都是搜狗输入法的特殊字符，与用户输入重复率小
                var reg = new RegExp(/▁{1,5}/, 'g')
                var reg1 = new RegExp(/[═]+/, 'g')
                var tmpText1 = that.instance.getContent().replace(reg, '▁▁▁▁▁')
                var tmpText = tmpText1.replace(reg1, '═══════════════════')
                // 只有两种匹配的线被破坏时才重新插入修改的内容
                if (tmpText !== that.instance.getContent()) {
                    that.instance.setContent(tmpText)
                }
                // 获得填空的个数用作填空组件
                if (that.needBlank) {
                    console.log('tmpText1.match', tmpText1.match(/▁+/g))
                    // match 方法返回包含匹配到的字符串的数组， 未匹配到则返回null
                    if (tmpText1.match(/▁+/g)) {
                        var temIndex = tmpText1.match(/▁+/g).length
                        that.$emit('countBlankEmit', temIndex)
                    } else {
                        that.$emit('countBlankEmit', 0)
                    }
                }
            })
        }
    },
    watch: {
        inputText: function (newVal) {
            console.log('editor watch')
            this.$nextTick(() => {
                this.instance.ready(() => {
                    this.instance.setContent(newVal)
                })
            })
        }
    }
}
</script>
<style lang="scss">
a {
    overflow: visible;
}
/*内容框高度*/

.editor-container {
    display: inline-block;
    vertical-align: middle;
    width: 100%;

    .edui-editor-iframeholder {
        height: 40px;
    }
}
</style>


