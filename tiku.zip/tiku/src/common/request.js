import axios from 'axios'
import { urls } from '@/common/urls'
import { NetworkCode } from '@/common/constant'
import router from '@/plugins/router'
// 这里不能这么去引用，要不然会出现循环引用问题
// import store from '../store/index'

import user from '@/store/modules/user'

// 创建axios实例 预设所有axios请求参数
var request = axios.create({
    baseURL: urls.SERVER_TEST_HOST,
    headers: {
        'Authorization': `${user.state.auth_token}`,
        'Accept': 'application/json'
    }
})

// 请求时拦截
request.interceptors.request.use(config => {
    // config包含axios请求时全部基本信息
    return config
}, error => {
    return Promise.reject(error)
})
// 响应时拦截
request.interceptors.response.use(response => {
    switch (response.data.code) {
        case NetworkCode.Success:
            return response
        case NetworkCode.CertificationFailed:
            router.push({
                name: 'Login'
            })
        default:
            return response
    }
    // if (response.code == NetworkCode.CertificationFailed) {}
    // response等于axios请求时的res
    // return response
}, error => {
    return Promise.reject(error)
})

var login = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_LOGIN}`,
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var refreshToken = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_REFRESH_TOKEN}`,
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var getUserList = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_USER_LIST}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var getUserDetail = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_USER_DETAIL}${obj.id}/`
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var editUser = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'PATCH',
            url: `${urls.URL_EDIT_USER}${obj.id}/`
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var addUser = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_ADD_USER}`,
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var editPassword1 = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_EDITPASSWORD1}/`,
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var editPassword2 = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_EDITPASSWORD2}/`,
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var editPassword3 = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_EDITPASSWORD3}/`,
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var getPermissionByTree = function () {
    return new Promise((resolve, reject) => {
        request({
            url: `${urls.URL_PERMISSION}`
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var getPermissionByList = function () {
    return new Promise((resolve, reject) => {
        request({
            url: `${urls.URL_PERMISSION}?list=1`
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}




var getQuestion = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_QUESTION}${obj.uuid}/`
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var addQuestion = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_ADD_QUESTION}`,
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var searchQuestion = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_SEARCH_QUESTION}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var getQiniuToken = function () {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_QINIU_TOKEN}`
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var currentUserInfo = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_CURRENT_USER_INFO}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

// var getProvince = function () {
//     return new Promise((resolve, reject) => {
//         request({
//             method: 'GET',
//             url: `${urls.URL_GET_PROVINCES}`
//         })
//         .then((res) => {
//             resolve(res)
//         })
//         .catch((res) => {
//             reject(err)
//         })
//     })
// }
// 来源type
var getSourceType = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_SOURCE_TYPE}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}
// 来源选择题型后
var getSourceParams = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_SOURCE_PARAMS}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}
// 查找学校
var getSourceSchool = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_SEARCH_SCHOOL}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

// 省请求市
var getSourceCity = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_PROVINCE_CITY}${obj.id}/city/`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

// 市请求区县
var getSourceArea = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_CITY_AREA}${obj.id}/area/`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}
// 获取教材
var getSourceMaterials = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_MATERIALS}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}
// 获取章节
var getSourceChapter = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_CHAPTERS}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}
// 确定与该题重复
var addSource = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_ADD_SOURCE}`,
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var getNextQuestion = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_NEXT_QUESTION}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var getPrevQuestion = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_PREV_QUESTION}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var getBaseTag = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'GET',
            url: `${urls.URL_GET_TAG_DIMENSIONS}`,
            params: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var getTagTree = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_GET_TAG_TREE}`,
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var reportQuestion = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_REPORT_QUESTION}`,
            params: {
                uid: sessionStorage.getItem('uid')
            },
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var searchTag = function (obj) {
    return new Promise((resolve, reject) => {
        request({
            method: 'POST',
            url: `${urls.URL_SEARCH_TAG}`,
            data: obj
        })
        .then((res) => {
            resolve(res)
        })
        .catch((err) => {
            reject(err)
        })
    })
}

var submitTag = function (obj) {
    return new Promise((resolve, reject) => {
        request({
                method: 'POST',
                url: `${urls.URL_SUBMIT_TAG}`,
                data: obj
            })
            .then((res) => {
                resolve(res)
            })
            .catch((err) => {
                reject(err)
            })
    })
}

// 组卷模块
var gitComposeType = function () {
    return new Promise((resolve, reject) => {
        request({
                method: 'GET',
                url: `${urls.URL_GET_COMPOSE_TYPE}`
            })
            .then((res) => {
                resolve(res)
            })
            .catch((err) => {
                reject(err)
            })
    })
}

var gitMaterialsType = function (obj) {
    return new Promise((resolve, reject) => {
        request({
                method: 'GET',
                url: `${urls.URL_GET_MATERIALS_TYPE}`,
                params: obj
            })
            .then((res) => {
                resolve(res)
            })
            .catch((err) => {
                reject(err)
            })
    })
}

var gitChaptersType = function (obj) {
    return new Promise((resolve, reject) => {
        request({
                method: 'GET',
                url: `${urls.URL_GET_CHAPTERS_TYPE}`,
                params: obj
            })
            .then((res) => {
                resolve(res)
            })
            .catch((err) => {
                reject(err)
            })
    })
}
// 请求组卷2查找参数
var getComposeParams = function (obj) {
    return new Promise((resolve, reject) => {
        request({
                method: 'GET',
                url: `${urls.URL_GET_COMPOSE_PARAMS}`,
                params: obj
            })
            .then((res) => {
                resolve(res)
            })
            .catch((err) => {
                reject(err)
            })
    })
}

// 请求组卷知识点树
var getKownledgeData = function (obj) {
    return new Promise((resolve, reject) => {
        request({
                method: 'GET',
                url: `${urls.URL_GET_KOWNLEDGE_DATA}`,
                params: obj
            })
            .then((res) => {
                resolve(res)
            })
            .catch((err) => {
                reject(err)
            })
    })
}

// 请求组卷查询题型结果
var getComposeQuestions = function (obj) {
    return new Promise((resolve, reject) => {
        request({
                method: 'POST',
                url: `${urls.URL_GET_COMPOSE_QUESTIONS}`,
                data: obj
            })
            .then((res) => {
                resolve(res)
            })
            .catch((err) => {
                reject(err)
            })
    })
}

export default {
    request,

    login: login,
    refreshToken: refreshToken,
    getUserList: getUserList,
    getUserDetail: getUserDetail,
    editUser: editUser,
    addUser: addUser,
    editPassword1: editPassword1,
    editPassword2: editPassword2,
    editPassword3: editPassword3,
    getPermissionByTree: getPermissionByTree,
    getPermissionByList: getPermissionByList,

    getQuestion: getQuestion,
    addQuestion: addQuestion,
    searchQuestion: searchQuestion,
    getQiniuToken: getQiniuToken,

    currentUserInfo: currentUserInfo,

    getSourceType: getSourceType,

    getNextQuestion,
    getPrevQuestion,
    getBaseTag,
    getTagTree,
    reportQuestion,
    searchTag,
    submitTag,
    getSourceParams,
    getSourceSchool,
    getSourceCity,
    getSourceArea,
    getSourceMaterials,
    getSourceChapter,
    addSource,

    gitComposeType,
    gitMaterialsType,
    gitChaptersType,
    getComposeParams,
    getKownledgeData,
    getComposeQuestions
}
