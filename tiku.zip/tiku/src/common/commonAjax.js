import request from '@/common/request'
import {
    NetworkCode
} from '@/common/constant'

// 根据省请求市
// 回调方式解决异步
export function toCityAjax( province_id, fun ) {
    var obj = {
        id: province_id
    }
    request
        .getSourceCity( obj )
        .then( response => {
            if ( response.data.code !== NetworkCode.Success ) {
                console.log( '省请求市错误' + response.data.message )
            } else {
                console.log( '省请求市请求成功' )
                // 把获取到的市数组放到整个数据中去
                fun( response.data.data.city )
            }
        } )
        .catch( error => {
            console.log( error )
            alert( '省请求市请求过程出错' )
        } )
}

// 根据市请求区
export function toAreaAjax( city_id, fun ) {
    var obj = {
        id: city_id
    }
    request
        .getSourceArea( obj )
        .then( response => {
            if ( response.data.code !== NetworkCode.Success ) {
                console.log( '市请求区错误' + response.data.message )
            } else {
                console.log( '市请求区请求成功' )
                console.log( response.data.data )
                // 把获取到的市数组放到整个数据中去
                fun( response.data.data.area )
            }
        } )
        .catch( error => {
            console.log( error )
            alert( '市请求区请求过程出错' )
        } )
}

// 请求章节
export function getChapterData( obj, fun ) {
    request
        .gitChaptersType( obj )
        .then( response => {
            if ( response.data.code !== NetworkCode.Success ) {
                console.log( '章节信息请求错误' + response.data.message )
            } else {
                console.log( '章节信息请求成功' )
                console.log( response.data.data )
                fun( response.data.data )
            }
        } )
        .catch( error => {
            console.log( error )
            alert( '章节信息请求过程出错' )
        } )
}
// 搜索学校,来源，组卷1，组卷2
export function findSchool( obj, fun ) {
    request
        .getSourceSchool( obj )
        .then( response => {
            if ( response.data.code !== NetworkCode.Success ) {
                console.log(
                    '学校搜索请求错误：' + response.data.message
                )
            } else {
                console.log( '学校搜索请求成功' )
                console.log( response.data.data )
                fun( response.data.data )
            }
        } )
        .catch( error => {
            console.log( error )
            alert( '学校搜索请求过程出错' )
        } )
}

// 请求知识点树，组卷2知识点
export function KownledgeTree( obj, fun ) {
    request
        .getKownledgeData( obj )
        .then( response => {
            if ( response.data.code !== NetworkCode.Success ) {
                console.log(
                    '知识点树请求错误：' + response.data.message
                )
            } else {
                console.log( '知识点树请求成功' )
                console.log( response.data.data )
                fun( response.data.data )
            }
        } )
        .catch( error => {
            console.log( error )
            alert( '知识点树请求过程出错' )
        } )
}

// 根据搜索参数查询题型，组卷2
export function getComposeSearchQuestions( obj, fun ) {
    console.log('查询试题的参数')
    console.log(obj)
    request
        .getComposeQuestions( obj )
        .then( response => {
            if ( response.data.code !== NetworkCode.Success ) {
                console.log(
                    '查询试题结果请求错误：' + response.data.message
                )
            } else {
                console.log( '查询试题结果请求成功' )
                console.log( response.data.data )
                fun( response.data.data )
            }
        } )
        .catch( error => {
            console.log( error )
            alert( '查询试题结果请求过程出错' )
        } )
}
