// editor编辑器填空插件按钮

export function editorRegisterUI() {
    window.UE.registerUI('blankLine', function(editor, uiName) {
        // 创建一个button
        var btn = new window.UE.ui.Button({
            // 按钮的名字
            name: uiName,
            // 提示
            title: '添加填空',
            // 添加额外样式，指定icon图标，这里默认使用一个重复的icon
            // cssRules: 'background-position: -360px 0;',
            cssRules: "background:url('static/utf8-php/themes/default/images/insert_blank_icon.png') !important;",
            // 点击时执行的命令
            onclick: function() {
                editor.execCommand('inserthtml', '▁▁▁▁▁')
            }
        })
        return btn
    })

    window.UE.registerUI('underline1', function(editor, uiName) {
        // 创建一个button
        var btn = new window.UE.ui.Button({
            // 按钮的名字
            name: uiName,
            // 提示
            title: '答案分割线',
            // title: '答案分割线',
            // 添加额外样式，指定icon图标，这里默认使用一个重复的icon
            cssRules: "background:url('static/utf8-php/themes/default/images/pagebreak.gif') center no-repeat !important;",
            // 点击时执行的命令
            onclick: function() {
                editor.execCommand(
                    'inserthtml',
                    "<p class='_segmentLine'>═══════════════════</p>"
                )
            }
        })
        //因为你是添加button,所以需要返回这个button
        return btn
    },[7])
}
