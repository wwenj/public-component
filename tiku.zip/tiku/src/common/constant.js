


// 题目： question
// 题型： questionType
// 题干： stem
// 答案： answer
// 答案解析：analysis
// 答案类型：answerType



/*
[1]单选题:singlechoice,
[2]多选题:mulchoice,
[3]多选多题:mulchoicemul,
[4]填空题:filling,
[5]解答题:subjective,
[6]判断题:judgment,
[7]配对题:pair,
[8]排序题:sort,
[9]完形填空:cloze,
[10]连词成句:wordstosen,
[90]复合题:complex
*/
export const Question = {
    Unknown: {
        type: 0,
        name: 'Unknown',
        component: 'Unknown',
        chineseName: '未知题'
    },

    SingleChoice: {
        type: 1,
        name: 'SingleChoice',
        component: 'tal-input-single-choice',
        chineseName: '单选题'
    },

    MulChoice: {
        type: 2,
        name: 'MulChoice',
        component: 'tal-input-mul-choice',
        chineseName: '多选题'
    },

    MulChoiceMul: {
        type: 3,
        name: 'MulChoiceMul',
        component: 'tal-input-mul-choice-mul',
        chineseName: '多选多题'
    },

    Filling: {
        type: 4,
        name: 'Filling',
        component: 'tal-input-filling',
        chineseName: '填空题'
    },

    Judgement: {
        type: 5,
        name: 'Judgment',
        component: 'tal-input-judgement',
        chineseName: '判断题'
    },

    Pair: {
        type: 6,
        name: 'Pair',
        component: 'tal-input-pair',
        chineseName: '配对题'
    },

    Sort: {
        type: 7,
        name: 'Sort',
        component: 'tal-input-sort',
        chineseName: '排序题'
    },

    Subjective: {
        type: 8,
        name: 'Subjective',
        component: 'tal-input-subjective',
        chineseName: '解答题'
    },

    Complex: {
        type: 9,
        name: 'Complex',
        component: 'tal-input-complex',
        chineseName: '复合题'
    },

    Cloze: {
        type: 10,
        name: 'Cloze',
        component: 'tal-input-cloze',
        chineseName: '完形填空题'
    },

    WordStosen: {
        type: 13,
        name: 'WordStosen',
        component: 'tal-input-word-stosen',
        chineseName: '连词成句'
    },


}
// 年部列表
const GradeLevel = {
    BeforePrimarySchool: {
        name: '小学之前',
        id: 0
    },
    PrimarySchool: {
        name: '小学',
        id: 1
    },
    JuniorHighSchool: {
        name: '初中',
        id: 2
    },
    HighSchool: {
        name: '高中',
        id: 3
    }
}
// 年级列表
export const Grade = {
    BottomClass: {
        name: '小班',
        id: 17,
        gradeLevelId: GradeLevel.BeforePrimarySchool.id
    },
    MiddleClass: {
        name: '中班',
        id: 18,
        gradeLevelId: GradeLevel.BeforePrimarySchool.id
    },
    TopClass: {
        name: '大班',
        id: 19,
        gradeLevelId: GradeLevel.BeforePrimarySchool.id
    },
    Prescholl: {
        name: '学前班',
        id: 0,
        gradeLevelId: GradeLevel.PrimarySchool.id
    },
    FirstGrade: {
        name: '一年级',
        id: 1,
        gradeLevelId: GradeLevel.PrimarySchool.id
    },
    SecondGrade: {
        name: '二年级',
        id: 2,
        gradeLevelId: GradeLevel.PrimarySchool.id
    },
    ThirdGrade: {
        name: '三年级',
        id: 3,
        gradeLevelId: GradeLevel.PrimarySchool.id
    },
    FourthGrade: {
        name: '四年级',
        id: 4,
        gradeLevelId: GradeLevel.PrimarySchool.id
    },
    FifthGrade: {
        name: '五年级',
        id: 5,
        gradeLevelId: GradeLevel.PrimarySchool.id
    },
    SixthGrade: {
        name: '六年级',
        id: 6,
        gradeLevelId: GradeLevel.PrimarySchool.id
    },
    GradeOneJuniorHighSchool: {
        name: '初一',
        id: 7,
        gradeLevelId: GradeLevel.JuniorHighSchool.id
    },
    GradeTwoJuniorHighSchool: {
        name: '初二',
        id: 8,
        gradeLevelId: GradeLevel.JuniorHighSchool.id
    },
    GradeThreeJuniorHighSchool: {
        name: '初三',
        id: 9,
        gradeLevelId: GradeLevel.JuniorHighSchool.id
    },
    GradeOneHighSchool: {
        name: '高一',
        id: 10,
        gradeLevelId: GradeLevel.HighSchool.id
    },
    GradeTwoHighSchool: {
        name: '高二',
        id: 11,
        gradeLevelId: GradeLevel.HighSchool.id
    },
    GradeThreeHighScholl: {
        name: '高三',
        id: 12,
        gradeLevelId: GradeLevel.HighSchool.id
    }
}
// 学科类型
export const SubjectType = {
    Art: {
        name: '文科',
        id: 2
    },
    Science: {
        name: '理科',
        id: 1
    }
}
// 学科列表
const Subject = {
    Chinese: {
        id: 1,
        code: 'yw',
        subjectTypeId: SubjectType.Art.id
    },
    Math: {
        id: 2,
        code: 'sx',
        subjectTypeId: SubjectType.Science.id
    },
    English: {
        id: 3,
        code: 'yy',
        subjectTypeId: SubjectType.Art.id
    },
    Physics: {
        id: 4,
        code: 'wl',
        subjectTypeId: SubjectType.Science.id
    },
    Chemistry: {
        id: 5,
        code: 'hx',
        subjectTypeId: SubjectType.Science.id
    },
    Biology: {
        id: 6,
        code: 'sw',
        subjectTypeId: SubjectType.Science.id
    },
    // 培优没有7
    History: {
        id: 8,
        code: 'ls',
        subjectTypeId: SubjectType.Art.id
    },
    Geography: {
        id: 9,
        code: 'dl',
        subjectTypeId: SubjectType.Art.id
    },
    Politics: {
        id: 10,
        code: 'zz',
        subjectTypeId: SubjectType.Art.id
    },
    Science: {
        id: 11,
        code: 'kx',
        subjectTypeId: SubjectType.Science.id
    },
    Biochemistry: {
        id: 12,
        code: 'sh',
        subjectTypeId: SubjectType.Science.id
    }
}

// 季度列表
const Quarter = {
    Spring: {
        name: '春季',
        id: 1
    },
    Summer: {
        name: '暑期',
        id: 2
    },
    Autumn: {
        name: '秋季',
        id: 3
    },
    Winter: {
        name: '寒假',
        id: 4
    }
}
// Paper类型列表
const PaperType = {}
// 元素类型列表
const ElementType = {
    Title: {
        name: '一级标题',
        id: 1
    },
    SecondaryHeadline: {
        name: '二级标题',
        id: 2
    },
    Paragraph: {
        name: '段落',
        id: 3
    },
    DIYTest: {
        name: 'DIY试题',
        id: 4
    },
    RecoringBankTest: {
        name: '题库试题',
        id: 5
    },
    Subtitle: {
        name: '小标题',
        id: 6
    },
    NOBOOKTest: {
        name: 'NOBOOK',
        id: 7
    },
    Testlet: {
        name: '题组',
        id: 8
    },
    Order: {
        name: '订单',
        id: 9
    },
    Game: {
        name: '游戏',
        id: 10
    }
}
// 元素用途列表
const ElementUses = {}
// 游戏配置列表
const GameConfig = {}
// Paper来源列表
const PaperSource = {

}
// 课件播放端列表
const CoursewarePlayEnd = {}




/*
[1]letters:答案为英文字母,
[2]content:答案为长文本,
[3]judge:判断题的答案,
[4]pair:配对题、完形填空的答案
*/
export const AnswerType = {
    Letters: 1,
    Content: 2,
    Judge: 3,
    Pair: 4,
    Blanks: 5
}

export const AnalysisType = {
    Opt: 1, // 按选项解析
    Content: 2 // 按文本解析,方法解析
}

/**
 * 来源类型
 * MidTerm 期中考试
 * FinalTerm 期末考试
 * Msee 中考
 * Cee 高考
 */
export const SourceType = {
    Cee: 301, // 高考真题
    H30Sim: 302, // 高三零模
    H31Sim: 303, // 高三一模
    H32Sim: 304, // 高三二模
    H33Sim: 305, // 高三三模
    MidTerm: 306, // 期中
    FinTerm: 307, // 期末
    MonthlyTest: 308, // 月考
    WeeklyTest: 309, // 周测
    PreStudy: 310, // 课前预习
    ClassExercise: 311, // 课堂练习
    Homework: 312, // 课后练习
    GCSE: 313, // 会考真题
    GCSESim: 314, // 会考模拟
    SelfEnrollment: 315, // 自主招生
    FinSim: 316, // 期末模拟
    InterimSim: 317, // 期中模拟
    UnitTest: 318, // 单元测试
    OpenExam: 319, // 开学考试
    Other: 320 // 其它
}
export const Term = {
    LastTerm: {
        id: 1,
        name: '上学期'
    },
    NextTerm: {
        id: 2,
        name: '下学期'
    }
}
export const QuestionTypeCollection = {
    AnswerType,
    AnalysisType
}


export const NetworkCode = {
    Success: 200,
    CertificationFailed: 40100000000,
    noRegisterError: 42200200001, // 未注册
    noNumberError: 42200000007, // 验证码不足6位
    likeLatelyError: 42200200002 // 修改密码与近期密码相同
}

export const JudgementDisplayType = {
    TrueFalse: {
        type: 0,
        nameArray: ['T', 'F']
    },
    TrueFalseUnknown: {
        type: 1,
        nameArray: ['T', 'F', 'N']
    },
    RightWrongSymbol: {
        type: 2,
        nameArray: ['✓', '×']
    },
    RightWrong: {
        type: 3,
        nameArray: ['R', 'W']
    },
    RightWrongChinese: {
        type: 4,
        nameArray: ['对', '错']
    }
}

export const methodMap = {
    0: '方法一',
    1: '方法二',
    2: '方法三',
    3: '方法四',
    4: '方法五',
    5: '方法六',
    6: '方法七',
    7: '方法八',
    8: '方法九',
    9: '方法十'
}

export const fillingAnswerType = {
    1: '数字',
    2: '分数',
    11: '对错、判断',
    12: '大于小于等于',
    21: '公式',
    31: '包含英文',
    41: '包含中文',
    99: '其他'
}