import {
    tmpdir
} from "os"
import { Question } from '@/common/constant'

/* 判断 富文本编辑器返回的字符串是否为空 */
export function stringIsEmpty( html ) {
    // 去除html中的空格符&nbsp; 再去除字符串首尾空格
    if(html.indexOf('img')!= -1){
        return true
    }
    let isEmpty = html.replace( /<("[^"]*"|'[^']*'|[^'">])*>/g, "" ).replace(/&nbsp;/gi, "").trim()
    return Boolean( isEmpty )
}

// 检查选项，解析错误信息
// options检验的字符串或对象，questiosError保存错误信息对象，text显示错误文案
export function checkError( options, questiosError, text ) {
    if ( typeof options === "object" ) {
        for ( let i in options ) {
            if ( !stringIsEmpty( options[ i ] ) ) {
                questiosError.isError = true
                questiosError.message.push( `${text}${i}未填写信息` )
            }
        }
    } else {
        if ( !stringIsEmpty( options ) ) {
            questiosError.isError = true
            questiosError.message.push( `${text}未填写信息` )
        }
    }
}

export function verifyQuestionStem (stem, questionType) {
    let res = {
        isError: true
    }
    if ( stringIsEmpty( stem.body ) ) res.isError = false
    // 配对题 和 完型填空 相比其他题型的选项比较特殊， 需分别处理
    if (questionType === Question.Pair.type) {
        // 配对题
        $.each(stem.options.left, (index, item) => {
            if (stringIsEmpty(item)) res.isError = false
        })
        $.each(stem.options.right, (index, item) => {
            if (stringIsEmpty(item)) res.isError = false
        })
    } else if (questionType === Question.Cloze.type) {
        // 完型填空
        $.each(stem.options, (index, items) => {
            $.each(items, (index, item) => {
                if (stringIsEmpty(item)) res.isError = false
            })
        })
    } else if (questionType === Question.WordStosen.type) {
        if ( stringIsEmpty( stem.body ) ) res.isError = true
        $.each(stem.options, (index, item) => {
            if ( stringIsEmpty(item) ) res.isError = false
        })
    } else {
        // 其他题型
        $.each(stem.options, (index, item) => {
            if ( stringIsEmpty(item) ) res.isError = false
        })
    }
    return res
}

export function verifyFillingstem (stem, questionsError) {
    if (!stringIsEmpty(stem)) {
        questionsError.isError = true
        questionsError.message.push(`题干内容不能为空，请完善题干内容`)
    }
    if (stem.indexOf(`<u class="blank">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>`) == -1) {
        questionsError.isError = true
        questionsError.message.push(`填空题题干必须包含'______'，请完善题干内容`)
    }
}

export function verifyQuestionAnswer( answer, questionsError ) {
    if ( answer.type == 1 || answer.type == 2 ) {
        if (
            answer.items == undefined ||
            answer.items == null ||
            !stringIsEmpty( answer.items )
        ) {
            questionsError.isError = true
            questionsError.message.push( `答案不能为空，请完善答案内容` )

        }
    } else if ( answer.type == 3 || answer.type == 4 ) {
        $.each( answer.items, ( index, item ) => {
            if ( !stringIsEmpty( item ) ) {
                questionsError.isError = true
                questionsError.message.push( `答案不能为空，请完善答案内容` )
                return false
            }
        } )
    }
}

export function verifyQuestionAnalysis( analysis, questionsError ) {
    if (
        analysis.enabled != undefined &&
        analysis.enabled != null &&
        analysis.enabled == 1 ) {
        if ( analysis.type == 1 ) {
            $.each( analysis.detail, ( index, item ) => {
                if ( !stringIsEmpty( item ) ) {
                    questionsError.isError = true
                    questionsError.message.push( `解析不能为空，请完善答案内容` )
                    return false
                }
            } )
        } else if ( analysis.type == 2 ) {
            $.each( analysis.detail, ( index, item ) => {
                if ( !stringIsEmpty( item ) ) {
                    questionsError.isError = true
                    questionsError.message.push( `空格解析不能为空，请完善答案内容` )
                    return false
                }
            } )
        }
    }
}

