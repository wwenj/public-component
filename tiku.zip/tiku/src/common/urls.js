// 服务器地址
// const SERVER_TEST_HOST = 'http://yapi.talbrain.com/mock/10/'  // 虚拟测试地址
const SERVER_TEST_HOST = 'http://60.205.111.102/' //测试地址
const SERVER_TEST_HOST_PORT = 'ws://60.205.111.102/ws' //测试地址

// 2号测试环境
// const SERVER_TEST_HOST = 'http://60.205.111.102:8902/'
// const SERVER_TEST_HOST_PORT = 'ws://60.205.111.102:8901/'

// 图片服务器地址
const SERVER_UEDITOR_HOST = "http://60.205.111.102/ueditor/php/controller.php"

//API接口地址
/* 登录 && 用户信息相关 */
const URL_LOGIN = 'user/login'
const URL_REFRESH_TOKEN = 'api-token-refresh/'
const URL_USER_LIST = 'accounts/users/'
const URL_USER_DETAIL = 'accounts/users/'
const URL_EDIT_USER = 'accounts/users/'
const URL_ADD_USER = 'accounts/users/'
const URL_EDITPASSWORD1 = '/user/send_verify_code/'
const URL_EDITPASSWORD2 = '/user/check_verify_code/'
const URL_EDITPASSWORD3 = '/user/change_password/'
const URL_PERMISSION = 'accounts/permission/'
/* End 登录 && 用户信息相关 */

const URL_GET_QUESTION = `question/`
const URL_ADD_QUESTION = 'question/'
const URL_SEARCH_QUESTION = 'question/search/'
const URL_GET_QINIU_TOKEN = 'question/qiniu/'

const URL_CURRENT_USER_INFO = 'user/info'

/* 来源相关 */
const URL_GET_SOURCE_TYPE = 'question/source/type/'
const URL_GET_SOURCE_PARAMS = 'question/source/params/'
const URL_GET_SEARCH_SCHOOL = 'base/search_school/'
const URL_GET_PROVINCE_CITY = 'question/province/'
const URL_GET_CITY_AREA = 'question/city/'
const URL_GET_MATERIALS = 'base/get_materials/'
const URL_GET_CHAPTERS = 'base/chapters/'

const URL_ADD_SOURCE = 'question/source/' // 确实与该题重复
/* End 来源相关 */

/* 题目打标签相关 */
const URL_GET_NEXT_QUESTION = 'tag/next'
const URL_GET_PREV_QUESTION = 'tag/prev'
const URL_GET_TAG_DIMENSIONS = 'tag/dimensions/'
const URL_GET_TAG_TREE = 'tag/get_tree'
const URL_REPORT_QUESTION = 'question/report'
const URL_SEARCH_TAG = 'tag/search_by_keyword'
const URL_SUBMIT_TAG = 'tag/submit_tag'
/* End 题目打标签相关 */

/* 组卷模块相关 */
const URL_GET_COMPOSE_TYPE = 'compose/type/'
const URL_GET_MATERIALS_TYPE = 'base/get_materials/'
const URL_GET_CHAPTERS_TYPE = 'base/chapters/'
const URL_GET_COMPOSE_PARAMS = 'compose/search/params/'
const URL_GET_KOWNLEDGE_DATA = 'base/get_kownledge_tree/'
const URL_GET_COMPOSE_QUESTIONS = 'compose/search/'
/* End 组卷模块相关 */

export var urls = {
    SERVER_TEST_HOST,
    SERVER_TEST_HOST_PORT,
    SERVER_UEDITOR_HOST,
    URL_LOGIN,
    URL_REFRESH_TOKEN,
    URL_USER_LIST,
    URL_USER_DETAIL,
    URL_EDIT_USER,
    URL_ADD_USER,
    URL_EDITPASSWORD1,
    URL_EDITPASSWORD2,
    URL_EDITPASSWORD3,
    URL_PERMISSION,

    URL_GET_QUESTION,
    URL_ADD_QUESTION,
    URL_SEARCH_QUESTION,
    URL_GET_QINIU_TOKEN,

    URL_CURRENT_USER_INFO,

    URL_GET_SOURCE_TYPE,
    URL_GET_SOURCE_PARAMS,

    URL_GET_NEXT_QUESTION,
    URL_GET_PREV_QUESTION,
    URL_GET_TAG_DIMENSIONS,
    URL_GET_TAG_TREE,
    URL_REPORT_QUESTION,
    URL_SEARCH_TAG,
    URL_SUBMIT_TAG,
    URL_GET_SEARCH_SCHOOL,
    URL_GET_PROVINCE_CITY,
    URL_GET_CITY_AREA,
    URL_GET_MATERIALS,
    URL_GET_CHAPTERS,
    URL_ADD_SOURCE,

    URL_GET_COMPOSE_TYPE,
    URL_GET_MATERIALS_TYPE,
    URL_GET_CHAPTERS_TYPE,
    URL_GET_COMPOSE_PARAMS,
    URL_GET_KOWNLEDGE_DATA,
    URL_GET_COMPOSE_QUESTIONS
}
