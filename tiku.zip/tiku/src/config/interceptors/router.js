// config/interceptors/router.js
import user from '@/store/modules/user'
import request from '@/common/request'

export function routerBeforeEachFunc (to, from, next) {
    // 当跳转到的路由是受保护的路由时，加上关闭/刷新浏览器事件 // 取消事件
    if (to.fullPath === '/questionEntry/directEntry' || to.fullPath === '/tag') {
        window.addEventListener('beforeunload', beforeUnload)
    } else {
        window.removeEventListener('beforeunload', beforeUnload)
    }
    // 做路由切换时，如果当前是受保护的路由，则在用户确认后继续跳转
    if (from.fullPath === '/questionEntry/directEntry') {
        if (confirm('离开页面会丢失当前录入信息哦！')) {
            next()
        } else {
            next(false)
            window.addEventListener('beforeunload', beforeUnload)
        }
    } else {
        // 这里可以做页面拦截，很多后台系统中也非常喜欢在这里面做权限处理
        let authToken = sessionStorage.getItem('auth_token')
        if (authToken) {
            user.state.auth_token = authToken
            request.request.defaults.headers.Authorization = authToken
        } else {
            if (to.name !== 'Login') {
                window.location.href = window.location.origin + '/#/login'
            }
        }
        next()
    }
}

// 浏览器刷新过关闭执行
function beforeUnload (e) {
    let confirmationMessage = '离开页面会丢失当前录入信息哦！';
    (e || window.event).returnValue = confirmationMessage // Gecko and Trident
    console.log('confirmationMessage', confirmationMessage)
    return confirmationMessage // Gecko and WebKit
}
