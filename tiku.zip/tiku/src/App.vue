<template>
    <div id="app">
        <router-view v-if="isRouterAlive"></router-view>
    </div>
</template>

<script>
export default {
    provide () {
        return {
            reload: this.reload
        }
    },
  data () {
    return {
        isRouterAlive: true
    }
  },
  mounted () {
      this.bindEvent()
  },
  methods: {
        reload: function () {
            this.isRouterAlive = false
            this.$nextTick(() => {
                this.isRouterAlive = true
            })
        },
        bindEvent () {
            global.vbus.$on('ajax_handle_error', (resData) => {
                // if (!!resData.config.noShowDefaultError) return
            })
            global.vbus.$on('request_error', (resData) => {
            })
            global.vbus.$on('response_error', (resData) => {
            })
            global.vbus.$on('scrollToTop', (resData) => {
            })
            // 接口反馈的错误信息都在这里弹出，除非设置了noShowDefaultError
            global.vbus.$on('global.$dialog.show', (msg) => {
                console.log('on error', msg)
                this.$message({type: 'error', message: msg, duration: 2000})
            })
        }
  }
}
</script>

<style lang="scss">
@import "assets/css/reset/reset.scss";
</style>

