// 用户权限相关路由

export default[
    {
        path: `/auth`,
        component: (resolve) => require([ '@/views/Wrapper/Wrapper' ], resolve),
        children: [ {
                path: `/auth/authManagement`,
                name: 'AuthManagement',
                component: (resolve) => require([ '@/views/Authorization/AuthManagement' ], resolve)
            },
            {
                path: `/auth/userAuthorization/:id`,
                name: 'UserAuthorization',
                component: (resolve) => require([ '@/views/Authorization/UserAuthorization' ], resolve)
            },
            {
                path: `/auth/editAuthorization`,
                name: 'EditAuthorization',
                component: (resolve) => require([ '@/views/Authorization/EditAuthorization' ], resolve)
            }
        ]
    }
]
