// 公共路由，登录，提示页等

export default [
    {
        path: '/',
        redirect: '/login'
    },
    {
        path: '/login',
        name: 'Login',
        component: (resolve) => require([ '@/views/Login/TalLogin' ], resolve)
    },
    {
        // 入口主页
        path: `/school`,
        name: 'School',
        component: (resolve) => require([ '@/views/Wrapper/SystemWrapper' ], resolve)
    }
]
