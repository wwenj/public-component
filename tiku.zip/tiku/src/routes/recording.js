// 题目录入相关路由

export default [
    {
        path: `/questionEntry`,
        name: 'QuestionEntry',
        component: (resolve) => require([ '@/views/Wrapper/Wrapper' ], resolve),
        children: [ {
            path: `/questionEntry/directEntry`,
            name: 'DirectEntry',
            component: (resolve) => require([ '@/views/Entry/Direct/DirectEntry' ], resolve)
        } ]
    },

    // 个人中心暂时放在这
    {
        path: `/center`,
        component: (resolve) => require([ '@/views/Wrapper/Wrapper' ], resolve),
        children: [ {
            path: `/center`,
            name: 'center',
            component: (resolve) => require([ '@/views/UserCenter/UserCenter' ], resolve)
        } ]
    }
]
