import common from './common' // 登录、公共路由等
import recording from './recording' // 题目录入路由
import compose from './compose' // 组卷路由
import permission from './permission' // 用户权限路由
import tag from './tag' // 打标签

export default [
    ...common,
    ...recording,
    ...compose,
    ...permission,
    ...tag
]
