// 组卷模块相关路由

export default [
    {
        path: `/composeTemplate`,
        name: 'ComposeTemplate',
        component: (resolve) => require([ '@/views/Compose/composeChoiceTemplate/ComposeChoiceTemplate' ], resolve)
    },
    {
        path: `/composeQuestions`,
        name: 'ComposeQuestions',
        component: (resolve) => require([ '@/views/Compose/composeChoiceQuestions/ComposeChoiceQuestions' ], resolve)
    },
    {
        path: `/composeLayout`,
        name: 'ComposeLayout',
        component: (resolve) => require([ '@/views/Compose/composeLayout/ComposeLayout' ], resolve)
    }
]
