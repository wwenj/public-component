// 打标签相关路由

export default [
    {
        path: `/tag`,
        component: (resolve) => require([ '@/views/Wrapper/Wrapper' ], resolve),
        children: [ {
            path: `/tag`,
            name: 'Tag',
            component: (resolve) => require([ '@/views/Tag/TalTag' ], resolve)
        } ]
    },
    {
        path: `/tagManagement`,
        component: (resolve) => require([ '@/views/Wrapper/Wrapper' ], resolve),
        children: [ {
                path: `/tagManagement/basicLabel`,
                name: 'BasicLabel',
                component: (resolve) => require([ '@/views/TagManagement/BasicLabel' ], resolve)
            },
            {
                path: `/tagManagement/labelSystem`,
                name: 'LabelSystem',
                component: (resolve) => require([ '@/views/TagManagement/LabelSystem' ], resolve)
            }
        ]
    }
]
