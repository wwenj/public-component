import login from './login'
import recording from './recording'
import questionTag from './questionTag'
export default {
    login,
    recording,
    questionTag
}
