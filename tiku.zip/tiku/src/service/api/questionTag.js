const version = ''
export default [
    // {
    //     name: 'tagPrev',
    //     method: 'GET',
    //     desc: '获取上一题',
    //     path: `${version}/tag/prev`,
    //     mockPath: `${version}/tag/prev`,
    //     mockEnable: false,
    //     noShowDefaultError: true,
    //     params: {
    //         qid: '',
    //         subject_id: '',
    //         grade_level_id: '1'
    //     }
    // },
    {
        name: 'tagNext',
        method: 'GET',
        desc: '获取下一题',
        path: `${version}/tag/next`,
        mockPath: `${version}/tag/next`,
        mockEnable: false,
        noShowDefaultError: true,
        params: {
            qid: '',
            subject_id: '',
            grade_level_id: '1',
            force: false
        }
    },
    {
        name: 'tagSubmit',
        method: 'POST',
        desc: '提交',
        path: `${version}/tag/submit_tag`,
        mockPath: `${version}/tag/submit_tag`,
        mockEnable: false,
        noShowDefaultError: true,
        params: {
            'qid': '', // 题目id
            'subject_id': '',
            'difficult': '',
            'paper_type': '', // 0->没选
            'tags': [ {
                'tid': '', // 标签id
                'primary': '' // 是否为主标签
            } ]
        }
    },
    {
        name: 'tagDimensions',
        method: 'GET',
        desc: '获取当前维度标签题目',
        path: `${version}/tag/dimensions`,
        mockPath: `${version}/tag/dimensions`,
        mockEnable: false,
        noShowDefaultError: true,
        params: {
            'system_id': '',
            'subject_id': '',
            'grade_level_id': ''
        }
    },
    {
        name: 'tagGetTree',
        method: 'POST',
        desc: '根据维度获取标签树',
        path: `${version}/tag/get_tree`,
        mockPath: `${version}/tag/get_tree`,
        mockEnable: false,
        noShowDefaultError: true,
        params: {
            'dimension': '',
            'qid': '',
            'subject_id': ''
        }
    },
    {
        name: 'tagSearchKeyword',
        method: 'POST',
        desc: '搜索标签',
        path: `${version}/tag/search_by_keyword`,
        mockPath: `${version}/tag/search_by_keyword`,
        mockEnable: false,
        noShowDefaultError: true,
        params: {
            'keyword': '',
            'qid': '',
            'subject_id': ''
        }
    },
    {
        name: 'tagQuestionReport',
        method: 'POST',
        desc: '打标签纠错',
        path: `${version}/question/report`,
        mockPath: `${version}/question/report`,
        mockEnable: false,
        noShowDefaultError: true,
        params: {
            'qid': '',
            'subject_id': '',
            'description': '',
            'report_type_id': '' // 3->题目录入错误  4->题目标签错误
          }
    },
    {
        name: 'tagLeave',
        method: 'GET',
        desc: '离开打标签页面',
        path: `${version}/tag/leave/`,
        mockPath: `${version}/tag/leave/`,
        mockEnable: false,
        noShowDefaultError: true,
        params: {}
    }
]
