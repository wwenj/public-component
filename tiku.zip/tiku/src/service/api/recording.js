// 题目录入模块相关接口   包括 题目录入和来源
const version = ''
export default[{
    name: 'addQuestion',
    method: 'POST',
    desc: '题目录入',
    path: `${version}/question/`,
    mockPath: `${version}/question/`,
    mockEnable: false,
    noShowDefaultError: false,
    params: {
        type_id: '',
        level_id: '',
        subject_id: '',
        source: [],
        body: {}
    }
}, {
    name: 'searchQuestion',
    method: 'GET',
    desc: '题目查重',
    path: `${version}/question/search/`,
    mockPath: `${version}/question/search/`,
    mockEnable: false,
    noShowDefaultError: true,
    params: {
        search_str: '',
        subject_id: '',
        level_id: '',
        type_id: ''
    }
}, {
    name: 'repeatSource',
    method: 'POST',
    desc: '确认与该题重复',
    path: `${version}/question/source/`,
    mockPath: `${version}/question/source/`,
    mockEnable: false,
    noShowDefaultError: true,
    params: {
        qid: '',
        subject_id: '',
        source: []
    }
}, {
    name: 'sourceType',
    method: 'GET',
    desc: '题目来源类型',
    path: `${version}/question/source/type/`,
    mockPath: `${version}/question/source/type/`,
    mockEnable: false,
    noShowDefaultError: false,
    params: {
        level_id: ''
    }
}, {
    name: 'sourceParams',
    method: 'GET',
    desc: '题目来源可选参数',
    path: `${version}/question/source/params/`,
    mockPath: `${version}/question/source/params/`,
    mockEnable: false,
    noShowDefaultError: false,
    params: {
        source_type_id: ''
    }
}, {
    name: 'sourceChapter',
    method: 'GET',
    desc: '根据课本获取章节信息',
    path: `${version}/base/chapters/`,
    mockPath: `${version}/base/chapters/`,
    mockEnable: false,
    noShowDefaultError: false,
    params: {
        subject_id: '',
        section_node_id: ''
    }
}, {
    name: 'sourceMaterials',
    method: 'GET',
    desc: '根据学科年部获取教材',
    path: `${version}/base/get_materials/`,
    mockPath: `${version}/base/get_materials/`,
    mockEnable: false,
    noShowDefaultError: false,
    params: {
        subject_id: '',
        grade_level_id: ''
    }
}, {
    name: 'searchSchool',
    method: 'GET',
    desc: '根据关键词搜索学校',
    path: `${version}/base/search_school/`,
    mockPath: `${version}/base/search_school/`,
    mockEnable: false,
    noShowDefaultError: false,
    params: {
        keyword: '',
        province_id: '',
        city_id: '',
        area_id: ''
    }
}, {
    name: 'getCities',
    method: 'GET',
    desc: '根据省份id获取城市列表',
    path: `${version}/base/cities/`,
    mockPath: `${version}/base/cities/`,
    mockEnable: false,
    noShowDefaultError: false,
    params: {
        province_id: ''
    }
}, {
    name: 'getAreas',
    method: 'GET',
    desc: '根据城市id获取区域信息',
    path: `${version}/base/areas/`,
    mockPath: `${version}/base/areas/`,
    mockEnable: false,
    noShowDefaultError: false,
    params: {
        city_id: ''
    }
}]
