const version = ''
export default [{
    name: 'login',
    method: 'POST',
    desc: '用户登录',
    path: `${version}/user/login`,
    mockPath: `${version}/user/login`,
    mockEnable: false,
    noShowDefaultError: true,
    params: {
        username: '',
        password: ''
    }
}, {
    name: 'sendVerificationCode',
    method: 'POST',
    desc: '用户更改密码第一步， 发送验证码',
    path: `${version}/user/send_verify_code/`,
    mockPath: `${version}user/send_verify_code/`,
    mockEnable: false,
    noShowDefaultError: true,
    params: {
        mobile: ''
    }
}, {
    name: 'checkVerificationCode',
    method: 'POST',
    desc: '用户更改密码第二步， 校验验证码',
    path: `${version}/user/check_verify_code/`,
    mockPath: `${version}user/check_verify_code/`,
    mockEnable: false,
    noShowDefaultError: true,
    params: {
        mobile: '',
        code: ''
    }
}, {
    name: 'changePassword',
    method: 'POST',
    desc: '用户更改密码第三步， 修改密码',
    path: `${version}/user/change_password/`,
    mockPath: `${version}user/change_password/`,
    mockEnable: false,
    noShowDefaultError: true,
    params: {
        mobile: '',
        check_pwd: '',
        n_pwd: ''
    }
}, {
    name: 'currentUserInfo',
    method: 'GET',
    desc: '当前用户的信息',
    path: `${version}/user/info`,
    mockPath: `${version}user/change_password/`,
    mockEnable: false,
    noShowDefaultError: false,
    params: {
        uid: ''
    }
}]
