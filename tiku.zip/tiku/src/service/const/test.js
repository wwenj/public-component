export default [{
    name: 'test',
    value: {
        label: 'Apple',
        value: 'apple'
    }
}, {
    name: 'test1',
    value: {
        label: 'Banana',
        value: 'banana'
    }
}]
