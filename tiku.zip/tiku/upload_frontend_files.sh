scp dist/index.html root@60.205.111.102:/data/www/school_fe/index.html
scp -r dist/static/ root@60.205.111.102:/data/www/school_fe/
