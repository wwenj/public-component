module.exports = {
    proxy: {
        '/apis': {    //将 60.205.111.102 印射为/apis
            target: 'https://60.205.111.102',  // 接口域名
            secure: true,  // 如果是https接口，需要配置这个参数
            changeOrigin: true,  //是否跨域
            pathRewrite: {
                '^/apis': '/'   //需要rewrite的,
            }
        }
    }
}