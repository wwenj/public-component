// https://eslint.org/docs/user-guide/configuring

module.exports = {
    root: true,
    parserOptions: {
        parser: 'babel-eslint'
    },
    env: {
        browser: true,
    },
    extends: [
        // https://github.com/vuejs/eslint-plugin-vue#priority-a-essential-error-prevention
        // consider switching to `plugin:vue/strongly-recommended` or `plugin:vue/recommended` for stricter rules.
        'plugin:vue/essential',
        // https://github.com/standard/standard/blob/master/docs/RULES-en.md
        'standard'
    ],
    // required to lint *.vue files
    plugins: [
        'vue'
    ],
    // add your custom rules here
    rules: {
        // "quotes": [0, "single"], //用双引号
        // "space-before-function-paren": ["off", "always"], //函数括号前不允许空格


        // allow async-await
        'generator-star-spacing': 'off',
        // allow debugger during development
        'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',


        // 关闭多余的空行检查
        'no-multiple-empty-lines': 'off',
        // 关闭缩进检查
        'indent': 'off',

        'eslint-disable-next-line': 'off',

        // // 两段代码之间加一个空行，默认会有缩进，这个时候就会产生这个警告
        // 'no-trailing-spaces': [1,
        //     {
        //         'skipBlankLines': true,
        //         'ignoreComments': true,
        //     }
        // ],



    }
}
